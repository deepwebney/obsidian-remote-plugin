export function isSelected(path: string, rules: Record<string, boolean>): boolean {
  let current = path;
  while (current) {
    if (Object.hasOwn(rules, current)) return rules[current];
    const slash = current.lastIndexOf("/");
    current = slash < 0 ? "" : current.slice(0, slash);
  }
  return false;
}

export function selectPath(rules: Record<string, boolean>, path: string, selected: boolean): Record<string, boolean> {
  const updated: Record<string, boolean> = Object.assign(Object.create(null), rules);
  for (const key of Object.keys(updated)) {
    if (key === path || key.startsWith(`${path}/`)) delete updated[key];
  }
  updated[path] = selected;
  return updated;
}

export function selectionState(path: string, rules: Record<string, boolean>): { checked: boolean; mixed: boolean } {
  const checked = isSelected(path, rules);
  return { checked, mixed: Object.entries(rules).some(([key, value]) => key.startsWith(`${path}/`) && value !== checked) };
}
