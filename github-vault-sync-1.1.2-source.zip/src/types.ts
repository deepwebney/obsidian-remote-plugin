export type Snapshot = Record<string, string>;
export type Mode = "sync" | "restore";

export interface Settings {
  owner: string;
  repo: string;
  branch: string;
  secretId: string;
  deviceName: string;
  includeConfig: boolean;
  includePluginCode: boolean;
  exclusions: string;
  propagateDeletes: boolean;
  autoSync: boolean;
  intervalMinutes: number;
  syncScope: "all" | "selected";
  selection: Record<string, boolean>;
  batchSize: number;
}

export interface SavedData {
  settings: Settings;
  baseline: Snapshot;
  target: string;
  lastSync: string;
  transfer?: TransferProgress;
}

export type ActionKind = "upload" | "download" | "delete-local" | "delete-remote" | "conflict";
export interface Action {
  kind: ActionKind;
  path: string;
  localSha?: string;
  remoteSha?: string;
  copyPath?: string;
}

export interface RemoteSnapshot {
  head: string;
  tree: string;
  files: Snapshot;
  sizes: Record<string, number>;
}

export interface PreparedSync {
  local: Snapshot;
  remote: RemoteSnapshot;
  actions: Action[];
  mode: Mode;
  runId: string;
}

export interface CommitState {
  baseHead: string;
  baseTree: string;
  changes: Record<string, string | null>;
  message: string;
  phase: "prepared" | "updating" | "confirmed";
  treeSha?: string;
  commitSha?: string;
}

export interface CommitRecovery {
  state: CommitState;
  save(): Promise<void>;
  check(): void;
}

export interface TransferProgress {
  target: string;
  uploaded: Record<string, number>;
  plan?: PreparedSync;
  nextIndex: number;
  batch?: { start: number; count: number; transaction: CommitState };
}

export interface LocalStore {
  scan(): Promise<Snapshot>;
  read(path: string): Promise<Uint8Array>;
  hash(path: string): Promise<string | undefined>;
  write(path: string, bytes: Uint8Array): Promise<void>;
  remove(path: string): Promise<void>;
  backup(path: string, bytes: Uint8Array, runId: string): Promise<void>;
  stage(path: string, bytes: Uint8Array, runId: string): Promise<void>;
  readStaged(path: string, runId: string): Promise<Uint8Array>;
  cleanupStage(runId: string): Promise<void>;
  stagedHash?(path: string, runId: string): Promise<string | undefined>;
  readBackup?(path: string, runId: string): Promise<Uint8Array>;
}

export interface RemoteStore {
  snapshot(): Promise<RemoteSnapshot>;
  download(sha: string): Promise<Uint8Array>;
  upload(bytes: Uint8Array): Promise<string>;
  commit(snapshot: RemoteSnapshot, changes: Record<string, string | null>, message: string, recovery?: CommitRecovery): Promise<string>;
  assertHead(expected: string): Promise<void>;
  verifyBlob?(sha: string, size: number): Promise<boolean>;
  reconcile?(state: CommitState): Promise<"confirmed" | "ready" | "moved">;
}

export const MAX_FILE_BYTES = 50 * 1024 * 1024;

export function defaults(): Settings {
  return {
    owner: "", repo: "", branch: "main",
    secretId: `github-vault-sync-${Math.random().toString(36).slice(2, 12)}`,
    deviceName: "我的设备", includeConfig: true, includePluginCode: false,
    exclusions: "node_modules/\n.DS_Store\nThumbs.db",
    propagateDeletes: false, autoSync: false, intervalMinutes: 10,
    syncScope: "all", selection: {}, batchSize: 20
  };
}

export function targetKey(settings: Settings, configDir: string): string {
  return JSON.stringify([settings.owner.toLowerCase(), settings.repo.toLowerCase(), settings.branch,
    configDir, settings.includeConfig, settings.includePluginCode, settings.exclusions, settings.propagateDeletes,
    settings.syncScope, settings.syncScope === "selected" ? Object.entries(settings.selection).sort(([left], [right]) => left.localeCompare(right)) : []]);
}

export function sameRepositoryTarget(left: string, right: string): boolean {
  try {
    const previous: unknown = JSON.parse(left);
    const next: unknown = JSON.parse(right);
    return Array.isArray(previous) && Array.isArray(next) && previous.length >= 3 && next.length >= 3 &&
      previous[0] === next[0] && previous[1] === next[1] && previous[2] === next[2];
  } catch { return false; }
}

export function migrateTarget(previous: string, settings: Settings, configDir: string): string {
  if (settings.syncScope !== "all") return previous;
  try {
    const old: unknown = JSON.parse(previous);
    const current = targetKey(settings, configDir);
    if (Array.isArray(old) && old.length === 7 && JSON.stringify(old) === JSON.stringify(JSON.parse(current).slice(0, 7))) return current;
  } catch { return previous; }
  return previous;
}
