import type { Settings } from "./types";
import { isSelected } from "./selection";

export const PRIVATE_DIR = ".github-vault-sync-local";
const CONFIG_FILES = new Set(["app.json", "appearance.json", "hotkeys.json", "core-plugins.json",
  "bookmarks.json", "daily-notes.json", "templates.json", "types.json", "graph.json"]);

export function assertSafePath(path: string): void {
  if (!path || path.startsWith("/") || /[\\\x00-\x1f\x7f:*?"<>|]/.test(path)) {
    throw new Error(`不支持或不安全的文件路径：${path}`);
  }
  for (const part of path.split("/")) {
    if (!part || part === "." || part === ".." || /[. ]$/.test(part) ||
        /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part)) {
      throw new Error(`文件名无法安全地跨设备同步：${path}`);
    }
  }
}

function matches(pattern: string, path: string): boolean {
  const clean = pattern.replace(/^\/+/, "");
  if (clean.endsWith("/")) {
    const folder = clean.slice(0, -1);
    return path === folder || path.startsWith(`${folder}/`) ||
      (!folder.includes("/") && path.split("/").includes(folder));
  }
  const expression = clean.split("*").map(part => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join(".*");
  return new RegExp(`^${expression}$`).test(path) ||
    (!clean.includes("/") && path.split("/").some(part => new RegExp(`^${expression}$`).test(part))) ||
    path.startsWith(`${clean}/`);
}

export class PathPolicy {
  constructor(readonly settings: Settings, readonly configDir: string) {}

  allows(path: string): boolean {
    if (!this.eligible(path)) return false;
    if (this.settings.syncScope !== "selected") return true;
    if (Object.hasOwn(this.settings.selection, path)) return this.settings.selection[path];
    return isSelected(path, this.settings.selection) || isSelected(path.replace(/\.conflict-[\w-]+(?=\.[^/.]+$|$)/, ""), this.settings.selection);
  }

  canDescend(path: string): boolean {
    return this.eligible(path) && (this.settings.syncScope !== "selected" || isSelected(path, this.settings.selection) ||
      Object.entries(this.settings.selection).some(([key, value]) => value && key.startsWith(`${path}/`)));
  }

  eligible(path: string): boolean {
    const parts = path.split("/");
    if (parts.some(part => /^(\.git|\.trash|\.github-vault-sync-local|\.ssh|\.gnupg|\.aws|\.azure)$/i.test(part))) return false;
    if (parts.some(part => /^\.env(?:\.|$)/i.test(part) || /\.(pem|key|p12|pfx)$/i.test(part) ||
      /^(secrets?\.json|credentials(?:\.json)?|id_rsa|id_ed25519)$/i.test(part))) return false;
    if (path === `${this.configDir}/plugins/github-vault-sync` || path.startsWith(`${this.configDir}/plugins/github-vault-sync/`)) return false;
    const patterns = this.settings.exclusions.split(/\r?\n/).map(value => value.trim()).filter(Boolean);
    if (patterns.some(pattern => matches(pattern, path))) return false;
    if (path === this.configDir) return this.settings.includeConfig;
    if (path.startsWith(`${this.configDir}/`)) {
      if (!this.settings.includeConfig) return false;
      const relative = path.slice(this.configDir.length + 1).replace(/\.conflict-[\w-]+(?=\.[^/.]+$|$)/, "");
      if (CONFIG_FILES.has(relative)) return true;
      if (relative === "snippets" || relative.startsWith("snippets/")) return true;
      if (relative === "themes" || relative.startsWith("themes/")) return true;
      if (this.settings.includePluginCode) {
        if (relative === "community-plugins.json" || relative === "plugins") return true;
        if (/^plugins\/[^/]+(?:\/(?:main\.js|manifest\.json|styles\.css))?$/.test(relative)) return true;
      }
      return false;
    }
    return true;
  }
}

export function assertCompatiblePaths(paths: Iterable<string>): void {
  const seen = new Map<string, string>();
  const directories = new Map<string, string>();
  for (const path of paths) {
    assertSafePath(path);
    const key = path.normalize("NFC").toLowerCase();
    const previous = seen.get(key);
    if (previous && previous !== path) throw new Error(`文件名大小写或 Unicode 冲突：${previous} / ${path}`);
    seen.set(key, path);
    const parts = path.split("/");
    parts.pop();
    while (parts.length) {
      const directory = parts.join("/");
      const directoryKey = directory.normalize("NFC").toLowerCase();
      const previousDirectory = directories.get(directoryKey);
      if (previousDirectory && previousDirectory !== directory) {
        throw new Error(`文件夹大小写或 Unicode 冲突：${previousDirectory} / ${directory}`);
      }
      directories.set(directoryKey, directory);
      parts.pop();
    }
  }
  for (const [key, path] of seen) {
    const parts = key.split("/");
    parts.pop();
    while (parts.length) {
      const parent = parts.join("/");
      if (seen.has(parent)) throw new Error(`文件和文件夹路径冲突：${seen.get(parent)} / ${path}。请先手动重命名。`);
      parts.pop();
    }
  }
}
