export class SyncStoppedError extends Error {
  constructor() {
    super("同步已停止，已确认的批次和上传进度已保留。下次可从断点继续。");
    this.name = "SyncStoppedError";
  }
}
