import { assertCompatiblePaths } from "./policy";
import type { Action, Mode, Snapshot } from "./types";

export function planSync(local: Snapshot, remote: Snapshot, baseline: Snapshot, mode: Mode,
  propagateDeletes: boolean, runId: string): Action[] {
  const paths = [...new Set([...Object.keys(local), ...Object.keys(remote), ...Object.keys(baseline)])].sort();
  assertCompatiblePaths([...Object.keys(local), ...Object.keys(remote)]);
  const occupied = new Set(paths.map(path => path.normalize("NFC").toLowerCase()));
  const actions: Action[] = [];
  for (const path of paths) {
    const localSha = Object.hasOwn(local, path) ? local[path] : undefined;
    const remoteSha = Object.hasOwn(remote, path) ? remote[path] : undefined;
    const baseSha = Object.hasOwn(baseline, path) ? baseline[path] : undefined;
    if (localSha === remoteSha) continue;
    let kind: Action["kind"];
    if (mode === "restore") {
      if (!remoteSha || (localSha && remoteSha === baseSha)) continue;
      kind = localSha && localSha !== baseSha ? "conflict" : "download";
    } else if (!baseSha) {
      kind = localSha && remoteSha ? "conflict" : localSha ? "upload" : "download";
    } else if (localSha === baseSha) {
      kind = remoteSha ? "download" : propagateDeletes ? "delete-local" : "upload";
    } else if (remoteSha === baseSha) {
      kind = localSha ? "upload" : propagateDeletes ? "delete-remote" : "download";
    } else {
      kind = localSha && remoteSha ? "conflict" : localSha ? "upload" : "download";
    }
    const action: Action = { kind, path, localSha, remoteSha };
    if (kind === "conflict") {
      const slash = path.lastIndexOf("/");
      const dot = path.lastIndexOf(".");
      const extensionIndex = dot > slash + 1 ? dot : path.length;
      const stem = path.slice(0, extensionIndex);
      const extension = path.slice(extensionIndex);
      let counter = 0;
      let copyPath: string;
      do {
        copyPath = `${stem}.conflict-${runId}-${++counter}${extension}`;
      } while (occupied.has(copyPath.normalize("NFC").toLowerCase()));
      occupied.add(copyPath.normalize("NFC").toLowerCase());
      action.copyPath = copyPath;
    }
    actions.push(action);
  }
  assertCompatiblePaths([...Object.keys(local), ...Object.keys(remote), ...actions.flatMap(action => action.copyPath ? [action.copyPath] : [])]);
  return actions;
}
