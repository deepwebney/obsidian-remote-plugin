import { Modal, Notice, Plugin, PluginSettingTab, Setting, requestUrl, type App } from "obsidian";
import { SyncEngine, type PreparedSync } from "./engine";
import { GitHub } from "./github";
import { GitHubApiError, redact } from "./api-error";
import { RequestControl, withRetry } from "./request-control";
import { SyncStoppedError } from "./cancellation";
import { FilePickerModal } from "./file-picker";
import { ObsidianStore } from "./local";
import { PathPolicy } from "./policy";
import { defaults, migrateTarget, sameRepositoryTarget, targetKey, type Mode, type SavedData, type Settings, type Snapshot } from "./types";

const LABELS = { upload: "上传", download: "下载", "delete-local": "删除本机", "delete-remote": "删除远程", conflict: "冲突：保留副本" };

class ConfirmSyncModal extends Modal {
  private resolve?: (confirmed: boolean) => void;
  private confirmed = false;
  constructor(app: App, private readonly plan: PreparedSync, private readonly publicRepo: boolean) { super(app); }

  ask(): Promise<boolean> {
    return new Promise(resolve => { this.resolve = resolve; this.open(); });
  }

  onOpen(): void {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: this.plan.mode === "restore" ? "从 GitHub 恢复：预览" : "GitHub 双向同步：预览" });
    if (this.publicRepo) contentEl.createEl("p", { text: "警告：这是公开仓库。上传内容将对所有人可见！建议取消并改用私有仓库。", cls: "gvs-warning" });
    contentEl.createEl("p", { text: "请暂停编辑笔记后确认。发生冲突时，原文件使用远程版本，本机版本另存为 .conflict-* 副本；已有文件被覆盖前会备份。" });
    const counts = new Map<string, number>();
    for (const action of this.plan.actions) counts.set(LABELS[action.kind], (counts.get(LABELS[action.kind]) ?? 0) + 1);
    contentEl.createEl("p", { text: [...counts].map(([label, count]) => `${label} ${count}`).join(" · ") });
    if (this.plan.actions.some(action => action.kind.startsWith("delete"))) {
      contentEl.createEl("p", { text: "本次包含删除，请仔细检查。离线设备中的旧内容可能在以后重新出现；删除后的历史版本仍可能保存在 GitHub 中。", cls: "gvs-warning" });
    }
    const list = contentEl.createDiv({ cls: "gvs-preview" });
    list.createEl("div", { text: this.plan.actions.map(action =>
      `${LABELS[action.kind]}  ${action.path}${action.copyPath ? ` → ${action.copyPath}` : ""}`).join("\n") });
    new Setting(contentEl)
      .addButton(button => button.setButtonText("取消").onClick(() => this.close()))
      .addButton(button => button.setButtonText("确认执行").setCta().onClick(() => { this.confirmed = true; this.close(); }));
  }

  onClose(): void {
    this.resolve?.(this.confirmed);
    this.contentEl.empty();
  }
}

export default class GitHubVaultSync extends Plugin {
  data!: SavedData;
  busy = false;
  lastDiagnostic = "";
  private readonly requests = new RequestControl();
  private status?: HTMLElement;
  private timer?: number;
  private stopped = false;
  private cancelRequested = false;
  private activeModal?: Modal;
  private persistence: Promise<void> = Promise.resolve();

  async onload(): Promise<void> {
    const stored = await this.loadData() as Partial<SavedData> | null;
    this.data = {
      settings: { ...defaults(), ...stored?.settings },
      baseline: Object.assign(Object.create(null), stored?.baseline ?? {}),
      target: stored?.target ?? "", lastSync: stored?.lastSync ?? "", transfer: stored?.transfer
    };
    if (!this.data.transfer) this.data.target = migrateTarget(this.data.target, this.data.settings, this.app.vault.configDir);
    this.status = this.addStatusBarItem();
    this.setStatus(this.data.transfer?.plan ? "有未完成任务，请手动继续" : "就绪");
    this.addRibbonIcon("cloud", "GitHub：预览并同步", () => { void this.run("sync"); });
    this.addRibbonIcon("square", "GitHub：停止当前同步", () => this.stopSync());
    this.addCommand({ id: "sync", name: "预览并双向同步", callback: () => { void this.run("sync"); } });
    this.addCommand({ id: "restore", name: "从 GitHub 恢复（仅下载）", callback: () => { void this.run("restore"); } });
    this.addCommand({ id: "stop", name: "停止同步并保留断点", callback: () => this.stopSync() });
    this.addCommand({ id: "resume", name: "继续上次同步", callback: () => { void this.run(this.data.transfer?.plan?.mode ?? "sync"); } });
    this.addSettingTab(new SyncSettingsTab(this.app, this));
    await this.persist();
    this.app.workspace.onLayoutReady(() => { if (!this.stopped) this.configureTimer(); });
  }

  onunload(): void {
    this.stopped = true;
    if (this.timer) window.clearInterval(this.timer);
    this.activeModal?.close();
  }

  persist(): Promise<void> {
    const snapshot = JSON.parse(JSON.stringify(this.data)) as SavedData;
    this.persistence = this.persistence.catch(() => {}).then(() => this.saveData(snapshot));
    return this.persistence;
  }

  setStatus(message: string): void { this.status?.setText(`GitHub：${message}`); }

  private checkActive(): void {
    if (this.stopped || this.cancelRequested) throw new SyncStoppedError();
  }

  private retry(error: unknown, attempt: number): Promise<boolean> {
    return this.requests.retry(error, attempt, () => this.checkActive(), message => this.setStatus(message));
  }

  stopSync(): void {
    if (!this.busy) { new Notice("当前没有正在运行的同步任务。"); return; }
    this.cancelRequested = true;
    this.data.settings.autoSync = false;
    this.configureTimer();
    this.activeModal?.close();
    this.setStatus("正在停止，等待当前请求结束");
    new Notice("停止已请求：当前请求返回后会保留断点并停止；已关闭定时同步。", 8000);
    void this.persist().catch(error => this.report(error));
  }

  client(settings = this.data.settings): GitHub {
    const token = this.app.secretStorage.getSecret(settings.secretId) ?? "";
    return new GitHub(settings, token, new PathPolicy(settings, this.app.vault.configDir), async (method, url, headers, body) => {
      this.checkActive();
      const response = await requestUrl({ url, method, headers, body, throw: false });
      let json: unknown = {};
      try { json = response.json; } catch { json = {}; }
      return { status: response.status, json, headers: response.headers, text: response.status >= 400 ? response.text : undefined };
    }, this.requests, () => this.checkActive());
  }

  configureTimer(): void {
    if (this.timer) window.clearInterval(this.timer);
    if (!this.data.settings.autoSync || this.stopped) return;
    const minutes = Math.max(5, this.data.settings.intervalMinutes || 10);
    this.timer = window.setInterval(() => { void this.run("sync", true); }, minutes * 60_000);
    this.registerInterval(this.timer);
  }

  async testConnection(): Promise<void> {
    if (this.busy) return;
    this.busy = true;
    this.cancelRequested = false;
    try {
      const client = this.client();
      const info = await client.info();
      const snapshot = await client.snapshot();
      new Notice(`连接成功：${info.full_name} / ${this.data.settings.branch}\n${info.private ? "私有仓库" : "警告：公开仓库"} · ${Object.keys(snapshot.files).length} 个可同步文件`, 8000);
    } catch (error) { this.report(error); }
    finally { this.busy = false; }
  }

  private report(error: unknown): void {
    if (error instanceof SyncStoppedError || this.cancelRequested) {
      if (error instanceof GitHubApiError) this.lastDiagnostic = error.details;
      this.setStatus(this.data.transfer?.batch?.transaction.phase === "updating" ? "已停止，下次先核对待确认提交" : "已停止，断点已保留");
      new Notice(new SyncStoppedError().message, 7000);
      return;
    }
    const token = this.app.secretStorage.getSecret(this.data.settings.secretId) ?? "";
    const summary = redact(error instanceof Error ? error.message : "未知错误", token);
    this.lastDiagnostic = redact(error instanceof GitHubApiError ? error.details : summary, token);
    const transfer = this.data.transfer;
    if (transfer?.plan) {
      this.lastDiagnostic += `\n任务断点：${transfer.nextIndex}/${transfer.plan.actions.length} 项\n已记录上传对象：${Object.keys(transfer.uploaded).length}`;
      if (transfer.batch) this.lastDiagnostic += `\n本批次：${transfer.batch.start + 1}–${transfer.batch.start + transfer.batch.count}\n提交状态：${transfer.batch.transaction.phase}`;
    }
    this.setStatus(this.requests.coolingDown ? "限流冷却中，请查看诊断" : "未完成，请查看诊断");
    new Notice(`GitHub 同步未完成：${summary}\n插件设置中可查看「最近一次诊断」。`, 15_000);
  }

  async run(mode: Mode, automatic = false): Promise<void> {
    if (this.busy || this.stopped) { if (!automatic) new Notice("已有同步任务正在进行。"); return; }
    if (automatic && this.requests.coolingDown) return;
    if (automatic && this.data.transfer?.plan) { this.setStatus("有未完成任务，请手动继续"); return; }
    this.busy = true;
    this.cancelRequested = false;
    try {
      const settings: Settings = { ...this.data.settings, selection: { ...this.data.settings.selection } };
      const target = targetKey(settings, this.app.vault.configDir);
      if (this.data.transfer?.plan && this.data.transfer.target !== target) throw new Error("同步范围已改变，请还原原设置并安全重新规划，不能把旧断点应用到新目标。");
      if (automatic && (!this.data.lastSync || this.data.target !== target)) {
        this.setStatus("请先手动同步新目标或范围"); return;
      }
      const baseline: Snapshot = this.data.target === target ? this.data.baseline : Object.create(null);
      const client = this.client(settings);
      const info = await withRetry(() => client.info(), (error, attempt) => this.retry(error, attempt), () => this.checkActive());
      if (automatic && !info.private) { this.setStatus("公开仓库需手动确认"); return; }
      const policy = new PathPolicy(settings, this.app.vault.configDir);
      const store = new ObsidianStore(this.app, policy, () => this.checkActive());
      const previous = this.data.transfer;
      const reusable = previous?.target === target ? previous : previous && !previous.plan && sameRepositoryTarget(previous.target, target) ?
        { target, uploaded: previous.uploaded, nextIndex: 0 } : undefined;
      const engine = new SyncEngine(store, client, message => this.setStatus(message), {
        target, state: reusable,
        batchSize: settings.batchSize, check: () => this.checkActive(),
        retry: (error, attempt) => this.retry(error, attempt),
        checkpoint: async (state, currentBaseline) => {
          this.data.transfer = state;
          this.data.baseline = currentBaseline;
          this.data.target = target;
          await this.persist();
        }
      });
      const plan = await engine.prepare(baseline, mode, settings.propagateDeletes);
      this.checkActive();
      for (const action of plan.actions) {
        if (action.copyPath && !policy.allows(action.copyPath)) {
          throw new Error(`冲突副本被排除规则阻止：${action.copyPath}。请调整规则或先手动解决该冲突。`);
        }
      }
      if (automatic && plan.actions.some(action => action.kind.startsWith("delete") || action.kind === "conflict")) {
        this.setStatus("有冲突或删除，请手动预览"); return;
      }
      if (!automatic && plan.actions.length) {
        const preview = { ...plan, actions: plan.actions.slice(this.data.transfer?.nextIndex ?? 0) };
        const modal = new ConfirmSyncModal(this.app, preview, !info.private);
        this.activeModal = modal;
        const confirmed = await modal.ask();
        this.activeModal = undefined;
        if (!confirmed) { this.setStatus("已取消"); return; }
      }
      this.checkActive();
      const nextBaseline = await engine.execute(plan, baseline, settings.deviceName);
      this.data.baseline = nextBaseline;
      this.data.target = target;
      this.data.lastSync = new Date().toISOString();
      await this.persist();
      this.setStatus(`已同步 ${new Date().toLocaleTimeString()}`);
      if (!automatic) new Notice(plan.actions.length ? `同步完成：处理 ${plan.actions.length} 项。若恢复了设置或其他插件，请重启 Obsidian。` : "本机与 GitHub 已一致，无需修改。", 7000);
    } catch (error) {
      if (!this.stopped) this.report(error);
    } finally { this.busy = false; }
  }

  async chooseFiles(): Promise<void> {
    if (this.busy || this.data.transfer?.plan) { new Notice("请先停止任务并安全重新规划，再修改同步范围。"); return; }
    this.busy = true;
    this.cancelRequested = false;
    try {
      const settings = { ...this.data.settings, syncScope: "all" as const };
      const store = new ObsidianStore(this.app, new PathPolicy(settings, this.app.vault.configDir), () => this.checkActive());
      const paths = await store.listPaths(true);
      this.checkActive();
      const modal = new FilePickerModal(this.app, this.data.settings, paths, async () => {
        try { return Object.keys((await this.client(settings).snapshot(true)).files); }
        catch (error) { this.report(error); throw error; }
      });
      this.activeModal = modal;
      const selection = await modal.ask();
      this.activeModal = undefined;
      if (selection) {
        this.checkActive();
        this.data.settings.syncScope = selection.scope;
        this.data.settings.selection = selection.rules;
        await this.persist();
        new Notice("选择已保存；下一次请手动预览同步。取消勾选不会删除文件。");
      }
    } catch (error) { if (!this.stopped) this.report(error); }
    finally { this.busy = false; }
  }

  async replan(): Promise<void> {
    if (this.busy) { new Notice("请先停止并等待当前任务结束。"); return; }
    if (!this.data.transfer) { new Notice("当前没有未完成任务。"); return; }
    this.busy = true;
    this.cancelRequested = false;
    try {
      const settings = this.data.settings;
      if (this.data.transfer.target !== targetKey(settings, this.app.vault.configDir)) throw new Error("请先还原原任务的仓库和选择范围，再核对未确认提交。");
      const engine = new SyncEngine(new ObsidianStore(this.app, new PathPolicy(settings, this.app.vault.configDir)), this.client(),
        message => this.setStatus(message), { state: this.data.transfer, check: () => this.checkActive(),
          checkpoint: async (state, baseline) => { this.data.transfer = state; this.data.baseline = baseline; await this.persist(); } });
      await engine.replan(this.data.baseline);
      new Notice("已核对旧批次。现在可修改勾选范围，再重新预览；已上传对象的校验缓存仍保留。", 9000);
      this.setStatus("可重新预览未完成部分");
    } catch (error) { this.report(error); }
    finally { this.busy = false; }
  }
}

class SyncSettingsTab extends PluginSettingTab {
  constructor(app: App, private readonly plugin: GitHubVaultSync) { super(app, plugin); }

  display(): void {
    const { containerEl } = this;
    const settings = this.plugin.data.settings;
    containerEl.empty();
    containerEl.createEl("h2", { text: "GitHub Vault Sync" });
    const transfer = this.plugin.data.transfer;
    const locked = this.plugin.busy || !!transfer?.plan;
    new Setting(containerEl).setName("任务控制").setDesc(transfer?.plan ?
      `已保存 ${transfer.nextIndex}/${transfer.plan.actions.length} 项；上传对象记录 ${Object.keys(transfer.uploaded).length} 个。` : "可停止当前任务；未完成的批次会保留断点。")
      .addButton(button => button.setButtonText("停止当前同步").onClick(() => this.plugin.stopSync()))
      .addButton(button => button.setButtonText("继续上次任务").onClick(() => this.plugin.run(this.plugin.data.transfer?.plan?.mode ?? "sync")))
      .addButton(button => button.setButtonText("安全重新规划").onClick(async () => { await this.plugin.replan(); this.display(); }));
    new Setting(containerEl).setName("文件与文件夹选择").setDesc(settings.syncScope === "all" ? "当前同步全部允许的文件。可改为仅同步勾选内容。" : "当前只同步勾选内容。安全排除规则仍优先。")
      .addButton(button => button.setButtonText("选择文件 / 文件夹").setDisabled(locked).onClick(async () => { await this.plugin.chooseFiles(); this.display(); }));
    new Setting(containerEl).setName("最近一次诊断").setDesc("仅保留在本次应用会话中，不写入同步文件。点击查看后可选中复制；发送前请检查，不要发送 Token。")
      .addButton(button => button.setButtonText("查看 / 刷新诊断").onClick(() => this.display()));
    if (this.plugin.lastDiagnostic) {
      const diagnostic = containerEl.createEl("textarea", { cls: "gvs-diagnostic" });
      diagnostic.readOnly = true;
      diagnostic.rows = 10;
      diagnostic.value = this.plugin.lastDiagnostic;
    }
    containerEl.createEl("p", { text: "先在 GitHub 新建专用私有仓库，勾选 Add a README。创建仅授权此仓库、Contents: Read and write 的 fine-grained Token。每台设备单独配置 Token。" });
    containerEl.createEl("p", { text: "同步笔记、附件和常用 Obsidian 设置；不会上传本插件、Token、插件 data.json、工作区布局、回收站和本机备份。GitHub 私有仓库不等同于端到端加密，请勿存放机密凭据。" });
    const save = async (): Promise<void> => { await this.plugin.persist(); this.plugin.configureTimer(); };
    const text = (name: string, description: string, key: "owner" | "repo" | "branch" | "deviceName", placeholder: string): void => {
      new Setting(containerEl).setName(name).setDesc(description).addText(input => input
        .setPlaceholder(placeholder).setValue(settings[key]).setDisabled(locked)
        .onChange(async value => { if (this.plugin.busy || this.plugin.data.transfer?.plan) return; settings[key] = value.trim(); await save(); }));
    };
    text("GitHub 用户名 / 组织名", "仓库地址中 github.com 后的第一段。", "owner", "your-name");
    text("仓库名", "只填名称，不要填写网址或 .git 后缀。请使用专用仓库。", "repo", "obsidian-vault");
    text("分支", "必须是已存在的分支；新仓库通常为 main。", "branch", "main");
    text("设备名称", "写入 GitHub 提交说明，方便区分设备。", "deviceName", "我的 MacBook");
    new Setting(containerEl).setName("GitHub Token").setDesc("写入 Obsidian SecretStorage，不写入插件 data.json，不显示已保存的 Token。清空输入不会删除已有 Token。")
      .addText(input => {
        input.inputEl.type = "password";
        input.inputEl.autocomplete = "off";
        input.setPlaceholder(this.app.secretStorage.getSecret(settings.secretId) ? "已保存（输入新值可替换）" : "github_pat_...")
          .setDisabled(this.plugin.busy);
        input.inputEl.addEventListener("change", () => {
          const token = input.getValue().trim();
          if (token) {
            this.app.secretStorage.setSecret(settings.secretId, token);
            input.setValue("").setPlaceholder("已保存");
            new Notice("Token 已保存在本机 SecretStorage。");
          }
        });
      })
      .addButton(button => button.setButtonText("清除 Token").setDisabled(this.plugin.busy).onClick(() => {
        this.app.secretStorage.setSecret(settings.secretId, ""); this.display();
      }));
    new Setting(containerEl).setName("测试连接").setDesc("验证 Token、仓库和分支能否读取；实际写入权限在提交时验证。")
      .addButton(button => button.setButtonText("测试连接").setDisabled(this.plugin.busy).onClick(() => this.plugin.testConnection()));
    const toggle = (name: string, description: string, key: "includeConfig" | "includePluginCode" | "propagateDeletes" | "autoSync"): void => {
      new Setting(containerEl).setName(name).setDesc(description).addToggle(input => input
        .setValue(settings[key]).setDisabled(key === "autoSync" ? this.plugin.busy : locked).onChange(async value => {
          if (this.plugin.busy || (key !== "autoSync" && this.plugin.data.transfer?.plan)) return;
          settings[key] = value; await save();
        }));
    };
    toggle("同步常用 Obsidian 设置", "包括外观、快捷键、书签、日记、模板、图谱、主题和 CSS 片段；其他配置不上传。", "includeConfig");
    toggle("同步其他插件代码（谨慎开启）", "包含其他插件 main.js / manifest.json / styles.css 和启用列表，但不包含其 data.json。远程代码可在重启后执行，只同步你信任的仓库。", "includePluginCode");
    toggle("传播删除（默认关闭）", "仅对已有同步基线的文件生效；自动同步遇到删除会暂停并要求手动确认。关闭时会从仍存在的一端补回文件。", "propagateDeletes");
    new Setting(containerEl).setName("额外排除规则").setDesc("每行一条，相对仓库根目录。目录用 folder/；* 匹配任意字符。不支持 .gitignore 的 !、? 或复杂语法。各设备建议保持一致。")
      .addTextArea(input => input.setValue(settings.exclusions).setPlaceholder("private/\n*.tmp").setDisabled(locked)
        .onChange(async value => { if (this.plugin.busy || this.plugin.data.transfer?.plan) return; settings.exclusions = value; await save(); }));
    new Setting(containerEl).setName("每批文件数").setDesc("默认 20，范围 1–100。这是保存进度的间隔，不是传输上限；一批完成后自动继续，直到全部完成。临时故障最多自动重试 3 次，等待时可停止。")
      .addText(input => input.setValue(String(settings.batchSize)).setDisabled(locked).onChange(async value => {
        if (this.plugin.busy || this.plugin.data.transfer?.plan) return;
        const count = Number(value);
        if (Number.isInteger(count) && count >= 1 && count <= 100) { settings.batchSize = count; await save(); }
      }));
    toggle("定时自动同步", "默认关闭，必须先手动同步一次。仅在 Obsidian 打开时运行；公开仓库、冲突和删除需要手动确认。", "autoSync");
    new Setting(containerEl).setName("同步间隔（分钟）").setDesc("最少 5 分钟。大量附件会增加 API 请求数和本机扫描开销。")
      .addText(input => input.setValue(String(settings.intervalMinutes)).setDisabled(this.plugin.busy).onChange(async value => {
        const minutes = Number(value);
        if (Number.isFinite(minutes) && minutes >= 5 && minutes <= 1440) { settings.intervalMinutes = minutes; await save(); }
      }));
    new Setting(containerEl).setName("同步与恢复").setDesc("新设备建议创建空 Vault，然后先点「仅下载恢复」。恢复不会提交任何内容到 GitHub。")
      .addButton(button => button.setButtonText("预览并双向同步").setCta().setDisabled(this.plugin.busy).onClick(() => this.plugin.run("sync")))
      .addButton(button => button.setButtonText("仅下载恢复").setDisabled(this.plugin.busy).onClick(() => this.plugin.run("restore")));
    containerEl.createEl("p", { text: `上次成功：${this.plugin.data.lastSync ? new Date(this.plugin.data.lastSync).toLocaleString() : "尚未同步"}` });
  }
}
