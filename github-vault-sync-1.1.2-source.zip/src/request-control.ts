import { GitHubApiError } from "./api-error";

export type Retry = (error: unknown, attempt: number) => Promise<boolean>;

export async function withRetry<Value>(operation: () => Promise<Value>, retry?: Retry,
  check: () => void = () => {}): Promise<Value> {
  for (let attempt = 0; ; attempt++) {
    check();
    try { return await operation(); }
    catch (error) {
      check();
      if (!await retry?.(error, attempt)) throw error;
    }
  }
}

export class RequestControl {
  private lastMutation = -Infinity;
  private rateError?: GitHubApiError;

  constructor(private readonly now: () => number = Date.now,
    private readonly sleep: (milliseconds: number) => Promise<void> = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds))) {}

  get coolingDown(): boolean { return !!this.rateError && this.rateError.retryAt > this.now(); }

  hold(error: GitHubApiError): void {
    if (error.retryAt > (this.rateError?.retryAt ?? 0)) this.rateError = error;
  }

  async retry(error: unknown, attempt: number, check: () => void = () => {},
    progress: (message: string) => void = () => {}): Promise<boolean> {
    check();
    if (!(error instanceof GitHubApiError) || !error.retryable) return false;
    const delay = Math.max(2000 * 2 ** attempt, error.retryAt - this.now(), (this.rateError?.retryAt ?? 0) - this.now());
    if (attempt >= 3 || delay > 300_000) {
      const reason = attempt >= 3 ? "自动重试 3 次后仍失败" : "GitHub 要求的冷却时间超过 5 分钟";
      const message = `${reason}，任务已停止；恢复后点击「继续上次任务」。${error.message}`;
      throw new GitHubApiError(message, `${message}\n原始诊断：\n${error.details}`, error.retryAt, error.status, false);
    }
    const deadline = this.now() + delay;
    let lastSeconds = -1;
    while (this.now() < deadline) {
      check();
      const remaining = deadline - this.now();
      const seconds = Math.ceil(remaining / 1000);
      if (seconds !== lastSeconds) {
        progress(`${error.retryAt > this.now() ? "GitHub 限流等待" : error.status ? `HTTP ${error.status} 暂时失败` : "网络暂时中断"}：${seconds} 秒后自动重试（${attempt + 1}/3），可停止同步`);
        lastSeconds = seconds;
      }
      await this.sleep(Math.min(250, remaining));
    }
    check();
    return true;
  }

  private checkCooldown(): void {
    if (this.coolingDown) throw this.rateError;
  }

  async before(method: string): Promise<void> {
    this.checkCooldown();
    if (!["POST", "PATCH", "PUT", "DELETE"].includes(method)) return;
    const delay = this.lastMutation + 1100 - this.now();
    if (delay > 0) await this.sleep(delay);
    this.checkCooldown();
    this.lastMutation = this.now();
  }
}
