import { gitHash } from "./hash";
import { planSync } from "./planner";
import { withRetry, type Retry } from "./request-control";
import type { Action, LocalStore, Mode, PreparedSync, RemoteStore, Snapshot, TransferProgress } from "./types";
export type { PreparedSync } from "./types";

export interface EngineOptions {
  target?: string;
  state?: TransferProgress;
  batchSize?: number;
  check?: () => void;
  retry?: Retry;
  checkpoint?: (state: TransferProgress | undefined, baseline: Snapshot) => Promise<void>;
}

export class SyncEngine {
  private state?: TransferProgress;
  private readonly verified = new Set<string>();

  constructor(private readonly local: LocalStore, private readonly remote: RemoteStore,
    private readonly progress: (message: string) => void = () => {}, private readonly options: EngineOptions = {}) {
    this.state = options.state;
  }

  private check(): void { this.options.check?.(); }

  async prepare(baseline: Snapshot, mode: Mode, deletes: boolean): Promise<PreparedSync> {
    this.check();
    if (this.state?.plan) {
      if (this.state.target !== (this.options.target ?? "") || this.state.plan.mode !== mode) {
        throw new Error("有不同目标或模式的未完成任务。请先恢复原任务或点击「安全重新规划」。");
      }
      this.progress(`恢复断点：已完成 ${this.state.nextIndex}/${this.state.plan.actions.length} 项`);
      return this.state.plan;
    }
    this.progress("扫描本地文件");
    const local = await this.local.scan();
    this.check();
    this.progress("读取 GitHub 文件树");
    const remote = await withRetry(() => this.remote.snapshot(), this.options.retry, () => this.check());
    this.check();
    const runId = `${new Date().toISOString().replace(/[:.]/g, "-")}-${Math.random().toString(36).slice(2, 7)}`;
    return { local, remote, mode, runId, actions: planSync(local, remote.files, baseline, mode, deletes, runId) };
  }

  private async save(baseline: Snapshot): Promise<void> { await this.options.checkpoint?.(this.state, baseline); }

  private async ensureUnchanged(path: string, expected?: string): Promise<void> {
    this.check();
    if (await this.local.hash(path) !== expected) {
      throw new Error(`本地文件发生变化：${path}。断点已保留；请暂停编辑，或点击「安全重新规划」。`);
    }
  }

  private async staged(path: string, runId: string, expected: string): Promise<Uint8Array> {
    this.check();
    const bytes = await this.local.readStaged(path, runId);
    if (!bytes || gitHash(bytes) !== expected) throw new Error(`暂存文件校验失败：${path}，未应用该文件。`);
    return bytes;
  }

  private async stageDownload(action: Action, runId: string): Promise<void> {
    this.check();
    if (await this.local.stagedHash?.(action.path, runId) === action.remoteSha) {
      this.progress(`复用已校验下载：${action.path}`);
      return;
    }
    const bytes = await this.remote.download(action.remoteSha!);
    if (gitHash(bytes) !== action.remoteSha) throw new Error(`远程文件校验失败：${action.path}`);
    this.check();
    await this.local.stage(action.path, bytes, runId);
  }

  private async upload(bytes: Uint8Array, baseline: Snapshot): Promise<string> {
    this.check();
    const sha = gitHash(bytes);
    if (this.verified.has(sha)) return sha;
    if (Object.hasOwn(this.state!.uploaded, sha) && this.remote.verifyBlob) {
      this.progress(`校验已上传对象 ${sha.slice(0, 10)}`);
      if (await this.remote.verifyBlob(sha, bytes.length)) {
        this.verified.add(sha);
        return sha;
      }
    }
    this.state!.uploaded[sha] = bytes.length;
    await this.save(baseline);
    this.check();
    if (await this.remote.upload(bytes) !== sha) throw new Error("上传文件校验失败，未提交该批次。");
    this.verified.add(sha);
    await this.save(baseline);
    return sha;
  }

  private changes(actions: Action[], mode: Mode): Record<string, string | null> {
    const changes: Record<string, string | null> = Object.create(null);
    if (mode === "restore") return changes;
    for (const action of actions) {
      if (action.kind === "upload" || action.kind === "conflict") changes[action.copyPath ?? action.path] = action.localSha!;
      if (action.kind === "delete-remote") changes[action.path] = null;
    }
    return changes;
  }

  private async prepareBatch(actions: Action[], plan: PreparedSync, baseline: Snapshot): Promise<void> {
    await this.remote.assertHead(plan.remote.head);
    for (const action of actions) {
      this.progress(`准备文件：${action.path}`);
      const remoteSha = Object.hasOwn(plan.remote.files, action.path) ? plan.remote.files[action.path] : undefined;
      if (remoteSha !== action.remoteSha) throw new Error(`远程文件已变化：${action.path}。请安全重新规划。`);
      await this.ensureUnchanged(action.path, action.localSha);
      if (action.copyPath) await this.ensureUnchanged(action.copyPath);
      if (action.kind === "download" || action.kind === "conflict") await this.stageDownload(action, plan.runId);
      if (action.localSha && action.kind !== "delete-remote") {
        const bytes = await this.local.read(action.path);
        if (gitHash(bytes) !== action.localSha) throw new Error(`文件已变化：${action.path}，请安全重新规划。`);
        this.check();
        if (action.kind !== "upload") await this.local.backup(action.path, bytes, plan.runId);
        if (action.kind === "conflict") await this.local.stage(action.copyPath!, bytes, plan.runId);
        if (plan.mode === "sync" && (action.kind === "upload" || action.kind === "conflict")) await this.upload(bytes, baseline);
      }
    }
    for (const action of actions) {
      await this.ensureUnchanged(action.path, action.localSha);
      if (action.copyPath) await this.ensureUnchanged(action.copyPath);
    }
  }

  private async apply(actions: Action[], plan: PreparedSync): Promise<void> {
    for (const action of actions) {
      this.check();
      this.progress(`应用文件：${action.path}`);
      if (action.kind === "conflict") {
        const copySha = await this.local.hash(action.copyPath!);
        if (copySha !== action.localSha) {
          if (copySha !== undefined) throw new Error(`冲突副本已被编辑：${action.copyPath}。请安全重新规划。`);
          if (this.local.stagedHash && await this.local.stagedHash(action.copyPath!, plan.runId) !== action.localSha) {
            this.check();
            const original = await this.local.hash(action.path) === action.localSha ? await this.local.read(action.path) :
              this.local.readBackup ? await this.local.readBackup(action.path, plan.runId) : await this.remote.download(action.localSha!);
            if (gitHash(original) !== action.localSha) throw new Error(`冲突原文备份校验失败：${action.path}`);
            await this.local.stage(action.copyPath!, original, plan.runId);
          }
          await this.local.write(action.copyPath!, await this.staged(action.copyPath!, plan.runId, action.localSha!));
        }
      }
      if (action.kind === "download" || action.kind === "conflict") {
        if (await this.local.hash(action.path) !== action.remoteSha) {
          await this.ensureUnchanged(action.path, action.localSha);
          if (this.local.stagedHash && await this.local.stagedHash(action.path, plan.runId) !== action.remoteSha) await this.stageDownload(action, plan.runId);
          await this.local.write(action.path, await this.staged(action.path, plan.runId, action.remoteSha!));
        }
      } else if (action.kind === "delete-local" && await this.local.hash(action.path) !== undefined) {
        await this.ensureUnchanged(action.path, action.localSha);
        await this.local.remove(action.path);
      }
    }
  }

  async execute(plan: PreparedSync, baseline: Snapshot, device: string): Promise<Snapshot> {
    if (!this.state?.plan) {
      this.state = { target: this.options.target ?? "", uploaded: this.state?.uploaded ?? Object.create(null), plan, nextIndex: 0 };
      await this.save(baseline);
    }
    const state = this.state;
    plan = state.plan!;
    const nextBaseline: Snapshot = Object.assign(Object.create(null), baseline);
    const batchSize = Math.max(1, Math.min(100, Math.floor(this.options.batchSize ?? 20)));
    while (state.nextIndex < plan.actions.length) {
      await withRetry(async () => {
        this.check();
        if (!state.batch) {
          const count = Math.min(batchSize, plan.actions.length - state.nextIndex);
          const actions = plan.actions.slice(state.nextIndex, state.nextIndex + count);
          state.batch = { start: state.nextIndex, count, transaction: {
            baseHead: plan.remote.head, baseTree: plan.remote.tree, changes: this.changes(actions, plan.mode), phase: "prepared",
            message: `Vault sync: ${device} [${plan.runId}:${state.nextIndex + 1}-${state.nextIndex + count}]`
          } };
          await this.save(nextBaseline);
        }
        const batch = state.batch;
        const actions = plan.actions.slice(batch.start, batch.start + batch.count);
        const transaction = batch.transaction;
        this.progress(`批次 ${batch.start + 1}–${batch.start + batch.count}/${plan.actions.length}`);
        if ((transaction.phase === "updating" || transaction.phase === "confirmed") && this.remote.reconcile && Object.keys(transaction.changes).length) {
          this.progress("核对上次分支更新结果");
          const outcome = await this.remote.reconcile(transaction);
          if (outcome === "moved") throw new Error("远程分支已变化，旧批次不会重放。请点击「安全重新规划」。");
          transaction.phase = outcome === "confirmed" ? "confirmed" : "prepared";
          await this.save(nextBaseline);
        }
        if (transaction.phase !== "confirmed") {
          await this.prepareBatch(actions, plan, nextBaseline);
          this.check();
          this.progress("提交本批次并记录确认结果");
          transaction.commitSha = plan.mode === "sync" ? await this.remote.commit(plan.remote, transaction.changes, transaction.message, {
            state: transaction, save: () => this.save(nextBaseline), check: () => this.check()
          }) : (await this.remote.assertHead(plan.remote.head), plan.remote.head);
          transaction.phase = "confirmed";
          await this.save(nextBaseline);
        }
        this.check();
        const remoteAfter = await this.remote.snapshot();
        for (const action of actions) {
          const expected = Object.hasOwn(transaction.changes, action.path) ? transaction.changes[action.path] ?? undefined : action.remoteSha;
          if (remoteAfter.files[action.path] !== expected || (plan.mode === "sync" && action.copyPath && remoteAfter.files[action.copyPath] !== action.localSha)) {
            throw new Error(`本批次已确认，但远程又发生变化：${action.path}。请安全重新规划，避免应用过期内容。`);
          }
        }
        await this.apply(actions, plan);
        this.check();
        for (const action of actions) {
          for (const path of [action.path, ...(action.copyPath ? [action.copyPath] : [])]) {
            const localSha = await this.local.hash(path);
            if (localSha === remoteAfter.files[path]) {
              if (localSha) nextBaseline[path] = localSha; else delete nextBaseline[path];
            } else if (action.kind === "upload" && path === action.path) nextBaseline[path] = action.localSha!;
          }
        }
        state.nextIndex += batch.count;
        state.batch = undefined;
        plan.remote = remoteAfter;
        await this.save(nextBaseline);
        this.progress(`已确认 ${state.nextIndex}/${plan.actions.length} 项，断点已保存；${state.nextIndex < plan.actions.length ? "自动继续下一批" : "正在完成最终校验"}`);
      }, this.options.retry, () => this.check());
    }
    this.check();
    this.progress("验证同步结果");
    const finalLocal = await this.local.scan();
    const finalRemote = await withRetry(() => this.remote.snapshot(), this.options.retry, () => this.check());
    for (const path of new Set([...Object.keys(nextBaseline), ...Object.keys(finalRemote.files), ...Object.keys(finalLocal)])) {
      if (finalLocal[path] === finalRemote.files[path]) {
        if (finalLocal[path]) nextBaseline[path] = finalLocal[path]; else delete nextBaseline[path];
      }
    }
    this.check();
    await this.local.cleanupStage(plan.runId);
    this.state = undefined;
    await this.save(nextBaseline);
    return nextBaseline;
  }

  async replan(baseline: Snapshot): Promise<Snapshot> {
    this.check();
    const state = this.state;
    if (!state) return baseline;
    const nextBaseline = Object.assign(Object.create(null), baseline) as Snapshot;
    const transaction = state.batch?.transaction;
    if (transaction && (transaction.phase === "updating" || transaction.phase === "confirmed") && Object.keys(transaction.changes).length) {
      if (!this.remote.reconcile) throw new Error("无法核对未确认提交，未清除断点。");
      const outcome = await this.remote.reconcile(transaction);
      if (outcome === "confirmed") {
        const actions = state.plan!.actions.slice(state.batch!.start, state.batch!.start + state.batch!.count);
        for (const action of actions) {
          if (action.kind === "upload") nextBaseline[action.path] = action.localSha!;
          if (action.kind === "delete-remote") delete nextBaseline[action.path];
        }
      }
    }
    state.plan = undefined;
    state.batch = undefined;
    state.nextIndex = 0;
    await this.options.checkpoint?.(state, nextBaseline);
    return nextBaseline;
  }
}
