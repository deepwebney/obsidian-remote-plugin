import { App, FileSystemAdapter, TFile } from "obsidian";
import type { promises as FilePromises } from "node:fs";
import { gitHash } from "./hash";
import { assertCompatiblePaths, assertSafePath, PathPolicy, PRIVATE_DIR } from "./policy";
import { MAX_FILE_BYTES, type LocalStore, type Snapshot } from "./types";

export class ObsidianStore implements LocalStore {
  private readonly adapter;
  private readonly fs?: typeof FilePromises;
  private readonly basePath?: string;

  constructor(private readonly app: App, private readonly policy: PathPolicy, private readonly check: () => void = () => {}) {
    this.adapter = app.vault.adapter;
    if (this.adapter instanceof FileSystemAdapter) {
      this.fs = (require("node:fs") as typeof import("node:fs")).promises;
      this.basePath = this.adapter.getBasePath();
    }
  }

  private async guard(path: string): Promise<void> {
    this.check();
    assertSafePath(path);
    if (!this.fs || !this.basePath) return;
    let current = this.basePath;
    for (const part of path.split("/")) {
      current += `/${part}`;
      try {
        const stat = await this.fs.lstat(current);
        if (stat.isSymbolicLink()) throw new Error(`不允许同步符号链接：${path}。请移除链接或加入排除列表。`);
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === "ENOENT") return;
        throw error;
      }
    }
  }

  async listPaths(includeFolders = false): Promise<string[]> {
    const files: string[] = [];
    const folders: string[] = [];
    const visit = async (folder: string): Promise<void> => {
      this.check();
      if (folder) await this.guard(folder);
      const listed = await this.adapter.list(folder);
      for (const path of listed.files) {
        if (!this.policy.allows(path)) continue;
        await this.guard(path);
        files.push(path);
      }
      for (const path of listed.folders) {
        if (this.policy.canDescend(path)) {
          folders.push(`${path}/`);
          await visit(path);
        }
      }
    };
    await visit("");
    assertCompatiblePaths(files);
    return includeFolders ? [...folders, ...files] : files;
  }

  async scan(): Promise<Snapshot> {
    const files: Snapshot = Object.create(null);
    for (const path of await this.listPaths()) {
      this.check();
      const sha = await this.hash(path);
      if (!sha) throw new Error(`扫描时文件消失：${path}，请重试。`);
      files[path] = sha;
    }
    return files;
  }

  async read(path: string): Promise<Uint8Array> {
    await this.guard(path);
    const stat = await this.adapter.stat(path);
    if (!stat || stat.type !== "file") throw new Error(`找不到文件：${path}`);
    if (stat.size > MAX_FILE_BYTES) throw new Error(`文件超过 50 MiB：${path}。请将其移出仓库或加入排除列表。`);
    const bytes = new Uint8Array(await this.adapter.readBinary(path));
    if (bytes.length > MAX_FILE_BYTES) throw new Error(`文件超过 50 MiB：${path}`);
    return bytes;
  }

  async hash(path: string): Promise<string | undefined> {
    await this.guard(path);
    const stat = await this.adapter.stat(path);
    if (!stat) return undefined;
    if (stat.type !== "file") throw new Error(`文件路径被文件夹占用：${path}`);
    return gitHash(await this.read(path));
  }

  private async mkdirParents(path: string): Promise<void> {
    const parts = path.split("/");
    parts.pop();
    let folder = "";
    for (const part of parts) {
      folder = folder ? `${folder}/${part}` : part;
      await this.guard(folder);
      if (!await this.adapter.exists(folder)) {
        if (this.isInternal(folder)) await this.adapter.mkdir(folder);
        else await this.app.vault.createFolder(folder);
      }
      else if ((await this.adapter.stat(folder))?.type !== "folder") throw new Error(`目标文件夹被文件占用：${folder}`);
    }
  }

  private buffer(bytes: Uint8Array): ArrayBuffer {
    return Uint8Array.from(bytes).buffer;
  }

  private isInternal(path: string): boolean {
    return path === this.policy.configDir || path.startsWith(`${this.policy.configDir}/`) ||
      path.split("/").some(part => part.startsWith("."));
  }

  async write(path: string, bytes: Uint8Array): Promise<void> {
    await this.guard(path);
    await this.mkdirParents(path);
    const file = this.app.vault.getAbstractFileByPath(path);
    if (file instanceof TFile) await this.app.vault.modifyBinary(file, this.buffer(bytes));
    else if (this.isInternal(path) || await this.adapter.exists(path)) {
      await this.adapter.writeBinary(path, this.buffer(bytes));
    } else {
      await this.app.vault.createBinary(path, this.buffer(bytes));
    }
    if (await this.hash(path) !== gitHash(bytes)) throw new Error(`写入后文件校验失败：${path}。旧版本位于本机备份目录。`);
  }

  async remove(path: string): Promise<void> {
    await this.guard(path);
    const file = this.app.vault.getAbstractFileByPath(path);
    if (file instanceof TFile) await this.app.fileManager.trashFile(file);
    else await this.adapter.remove(path);
  }

  private async writePrivate(path: string, bytes: Uint8Array): Promise<void> {
    await this.guard(path);
    await this.mkdirParents(path);
    await this.adapter.writeBinary(path, this.buffer(bytes));
    const saved = new Uint8Array(await this.adapter.readBinary(path));
    if (gitHash(saved) !== gitHash(bytes)) throw new Error("本机备份或暂存文件校验失败；已停止。");
  }

  async backup(path: string, bytes: Uint8Array, runId: string): Promise<void> {
    await this.writePrivate(`${PRIVATE_DIR}/backups/${runId}/${path}`, bytes);
  }

  async stage(path: string, bytes: Uint8Array, runId: string): Promise<void> {
    await this.writePrivate(`${PRIVATE_DIR}/staging/${runId}/${path}`, bytes);
  }

  async readStaged(path: string, runId: string): Promise<Uint8Array> {
    return this.read(`${PRIVATE_DIR}/staging/${runId}/${path}`);
  }

  async stagedHash(path: string, runId: string): Promise<string | undefined> {
    return this.hash(`${PRIVATE_DIR}/staging/${runId}/${path}`);
  }

  async readBackup(path: string, runId: string): Promise<Uint8Array> {
    return this.read(`${PRIVATE_DIR}/backups/${runId}/${path}`);
  }

  async cleanupStage(runId: string): Promise<void> {
    const path = `${PRIVATE_DIR}/staging/${runId}`;
    await this.guard(path);
    if (await this.adapter.exists(path)) await this.adapter.rmdir(path, true);
  }
}
