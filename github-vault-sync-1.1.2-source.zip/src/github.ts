import { fromBase64, gitHash, toBase64 } from "./hash";
import { assertCompatiblePaths, PathPolicy } from "./policy";
import { MAX_FILE_BYTES, type CommitRecovery, type CommitState, type RemoteSnapshot, type RemoteStore, type Settings, type Snapshot } from "./types";
import { describeApiError, GitHubApiError } from "./api-error";
import { RequestControl } from "./request-control";
import { SyncStoppedError } from "./cancellation";

export interface HttpResponse { status: number; json: unknown; headers: Record<string, string>; text?: string; }
export type Transport = (method: string, url: string, headers: Record<string, string>, body?: string) => Promise<HttpResponse>;
interface TreeEntry { path: string; type: string; mode: string; sha: string; size?: number; }

export class GitHub implements RemoteStore {
  private readonly root: string;
  constructor(private readonly settings: Settings, private readonly token: string,
    private readonly policy: PathPolicy, private readonly transport: Transport,
    private readonly requests = new RequestControl(), private readonly check: () => void = () => {}) {
    if (!/^[A-Za-z0-9-]+$/.test(settings.owner) || !/^[A-Za-z0-9_.-]+$/.test(settings.repo)) {
      throw new Error("请填写有效的 GitHub 用户名 / 组织名和仓库名（不是完整网址）。");
    }
    if (!settings.branch.trim() || /[\x00-\x20~^:?*\[\\]/.test(settings.branch) ||
      settings.branch.includes("..") || settings.branch.includes("@{") ||
      settings.branch.split("/").some(part => !part || part.startsWith(".") || part.endsWith(".") || part.endsWith(".lock"))) {
      throw new Error("请填写有效的分支名，例如 main。");
    }
    if (!token.trim()) throw new Error("请先在设置中填写 GitHub Token。");
    this.root = `https://api.github.com/repos/${encodeURIComponent(settings.owner)}/${encodeURIComponent(settings.repo)}`;
  }

  private async api<Result>(method: string, path: string, data?: unknown): Promise<Result> {
    this.check();
    await this.requests.before(method);
    this.check();
    let response: HttpResponse;
    try {
      response = await this.transport(method, `${this.root}${path}`, {
        Authorization: `Bearer ${this.token}`, Accept: "application/vnd.github+json",
        "Content-Type": "application/json", "X-GitHub-Api-Version": "2026-03-10",
        "User-Agent": "GitHub-Vault-Sync/1.1.2"
      }, data === undefined ? undefined : JSON.stringify(data));
    } catch (error) {
      if (error instanceof SyncStoppedError) throw error;
      const message = "无法连接 GitHub：网络连接中断或请求超时。";
      throw new GitHubApiError(message,
        `${message}\n发生时间：${new Date().toISOString()}\n请求方法：${method}\n接口：${path || "/"}\n上传与提交结果可能尚未确认；重试前会校验断点和远端。`, 0, 0, true);
    }
    if (response.status >= 200 && response.status < 300) return response.json as Result;
    const error = describeApiError(response, method, path, this.token);
    this.requests.hold(error);
    throw error;
  }

  private refPath(): string {
    return this.settings.branch.split("/").map(encodeURIComponent).join("/");
  }

  private async head(): Promise<string> {
    const result = await this.api<{ object: { sha: string } }>("GET", `/git/ref/heads/${this.refPath()}`);
    return result.object.sha;
  }

  async assertHead(expected: string): Promise<void> {
    if (await this.head() !== expected) throw new Error("远程分支已被其他设备更新，已安全停止。请重新同步。");
  }

  async info(): Promise<{ private: boolean; default_branch: string; full_name: string }> {
    return this.api("GET", "");
  }

  async snapshot(forSelection = false): Promise<RemoteSnapshot> {
    const head = await this.head();
    const commit = await this.api<{ tree: { sha: string } }>("GET", `/git/commits/${head}`);
    const result = await this.api<{ tree: TreeEntry[]; truncated: boolean }>("GET", `/git/trees/${commit.tree.sha}?recursive=1`);
    if (result.truncated) throw new Error("仓库文件树被 GitHub 截断。为避免漏同步或误删，已停止；请拆分仓库。");
    const files: Snapshot = Object.create(null);
    const sizes: Record<string, number> = Object.create(null);
    for (const entry of result.tree) {
      if (entry.type === "tree" || !this.policy.allows(entry.path)) continue;
      if (entry.type !== "blob" || !["100644", "100755"].includes(entry.mode)) {
        if (forSelection) continue;
        throw new Error(`暂不支持符号链接或子模块：${entry.path}`);
      }
      if (!forSelection && (typeof entry.size !== "number" || entry.size > MAX_FILE_BYTES)) throw new Error(`远程文件超过 50 MiB 或缺少大小信息：${entry.path}`);
      files[entry.path] = entry.sha;
      sizes[entry.path] = entry.size ?? 0;
    }
    assertCompatiblePaths(Object.keys(files));
    return { head, tree: commit.tree.sha, files, sizes };
  }

  async download(sha: string): Promise<Uint8Array> {
    const result = await this.api<{ content: string; encoding: string; size: number; sha: string }>("GET", `/git/blobs/${sha}`);
    if (result.encoding !== "base64" || result.size > MAX_FILE_BYTES) throw new Error("不支持的远程文件编码或大小。");
    const bytes = fromBase64(result.content);
    if (bytes.length !== result.size || gitHash(bytes) !== sha) throw new Error("下载文件校验失败，已停止同步。");
    return bytes;
  }

  async upload(bytes: Uint8Array): Promise<string> {
    if (bytes.length > MAX_FILE_BYTES) throw new Error("文件超过 50 MiB，无法同步。");
    const result = await this.api<{ sha: string }>("POST", "/git/blobs", { content: toBase64(bytes), encoding: "base64" });
    if (result.sha !== gitHash(bytes)) throw new Error("上传文件校验失败，已停止提交。");
    return result.sha;
  }

  async verifyBlob(sha: string, size: number): Promise<boolean> {
    try { return (await this.download(sha)).length === size; }
    catch (error) {
      if (error instanceof GitHubApiError && error.status === 404) return false;
      throw error;
    }
  }

  async reconcile(state: CommitState): Promise<"confirmed" | "ready" | "moved"> {
    const head = await this.head();
    if (state.commitSha && head === state.commitSha) return "confirmed";
    if (head === state.baseHead && state.phase !== "confirmed") return "ready";
    if (state.commitSha && state.commitSha !== state.baseHead) {
      const comparison = await this.api<{ status: string }>("GET", `/compare/${state.commitSha}...${head}?per_page=1`);
      if (comparison.status === "ahead" || comparison.status === "identical") return "confirmed";
    }
    return "moved";
  }

  async commit(snapshot: RemoteSnapshot, changes: Record<string, string | null>, message: string, recovery?: CommitRecovery): Promise<string> {
    if (!Object.keys(changes).length) {
      await this.assertHead(snapshot.head);
      return snapshot.head;
    }
    const state = recovery?.state ?? { baseHead: snapshot.head, baseTree: snapshot.tree, changes, message, phase: "prepared" } as CommitState;
    const save = async (): Promise<void> => { await recovery?.save(); };
    const outcome = await this.reconcile(state);
    if (outcome === "confirmed") {
      state.phase = "confirmed";
      await save();
      return state.commitSha!;
    }
    if (outcome === "moved") throw new Error("远程分支已更新；不会重放旧提交。请点击「安全重新规划」核对未完成部分。");
    if (!state.treeSha) {
      const tree = await this.api<{ sha: string }>("POST", "/git/trees", {
        base_tree: state.baseTree,
        tree: Object.entries(state.changes).map(([path, sha]) => ({ path, mode: "100644", type: "blob", sha }))
      });
      state.treeSha = tree.sha;
      await save();
    }
    recovery?.check();
    if (!state.commitSha) {
      const commit = await this.api<{ sha: string }>("POST", "/git/commits", {
        message: state.message, tree: state.treeSha, parents: [state.baseHead]
      });
      state.commitSha = commit.sha;
      await save();
    }
    recovery?.check();
    state.phase = "updating";
    await save();
    try {
      await this.api("PATCH", `/git/refs/heads/${this.refPath()}`, { sha: state.commitSha, force: false });
    } catch (error) {
      if (error instanceof SyncStoppedError) throw error;
      let result: "confirmed" | "ready" | "moved" | "unknown" = "unknown";
      try { result = await this.reconcile(state); } catch { result = "unknown"; }
      if (result !== "confirmed") {
        const explanation = result === "ready" ? "已核对：分支尚未更新，下次复用已创建的提交。" :
          result === "moved" ? "远程分支已变化，请安全重新规划。" : "提交结果尚未确认；下次先核对远端，不会盲目重复提交。";
        const original = error instanceof GitHubApiError ? error.details : error instanceof Error ? error.message : "未知网络错误";
        throw new GitHubApiError(explanation, `${explanation}\n待确认提交：${state.commitSha}\n${original}`,
          error instanceof GitHubApiError ? error.retryAt : 0, error instanceof GitHubApiError ? error.status : 0,
          result !== "moved" && error instanceof GitHubApiError && error.retryable);
      }
    }
    state.phase = "confirmed";
    await save();
    return state.commitSha;
  }
}
