export interface ErrorResponse {
  status: number;
  json: unknown;
  headers: Record<string, string>;
  text?: string;
}

export class GitHubApiError extends Error {
  constructor(message: string, readonly details: string, readonly retryAt = 0, readonly status = 0,
    readonly retryable = retryAt > 0 || [408, 500, 502, 503, 504].includes(status)) {
    super(message);
    this.name = "GitHubApiError";
  }
}

export function redact(value: string, token: string): string {
  return (token ? value.split(token).join("[已隐藏]") : value)
    .replace(/(?:github_pat_|gh[pousr]_)[A-Za-z0-9_]+/g, "[已隐藏]")
    .replace(/Bearer\s+[^\s"<>]+/gi, "Bearer [已隐藏]")
    .replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g, "");
}

function step(method: string, path: string): string {
  if (!path) return "读取仓库信息";
  if (path.startsWith("/compare/")) return "核对提交是否已进入远程历史";
  if (path.startsWith("/git/ref/")) return "读取分支";
  if (path.startsWith("/git/refs/")) return "更新分支";
  if (path.startsWith("/git/blobs")) return method === "GET" ? "下载文件" : "上传文件";
  if (path.startsWith("/git/trees")) return method === "GET" ? "读取文件树" : "创建文件树";
  if (path.startsWith("/git/commits")) return method === "GET" ? "读取提交" : "创建提交";
  return "访问 GitHub";
}

export function describeApiError(response: ErrorResponse, method: string, path: string, token: string, now = Date.now()): GitHubApiError {
  const headers = Object.fromEntries(Object.entries(response.headers).map(([name, value]) => [name.toLowerCase(), value]));
  const payload = response.json as { message?: unknown } | null;
  const rawMessage = typeof payload?.message === "string" ? payload.message : response.text ?? "";
  const message = redact(rawMessage.replace(/<[^>]*>/g, " "), token).trim().slice(0, 700);
  const limitedStatus = response.status === 403 || response.status === 429;
  const primaryLimit = limitedStatus && headers["x-ratelimit-remaining"]?.trim() === "0";
  const secondaryLimit = limitedStatus && /secondary rate limit|abuse detection/i.test(rawMessage);
  const rateLimited = primaryLimit || secondaryLimit || response.status === 429 ||
    (limitedStatus && /rate[ -]limit/i.test(rawMessage));
  let reason: string;
  let retryAt = 0;
  if (rateLimited) {
    const retryHeader = headers["retry-after"]?.trim();
    const seconds = retryHeader ? Number(retryHeader) : NaN;
    const retryTime = Number.isFinite(seconds) && seconds >= 0 ? now + seconds * 1000 : Date.parse(retryHeader ?? "");
    const resetTime = primaryLimit ? Number(headers["x-ratelimit-reset"]) * 1000 : NaN;
    const candidates = [retryTime, resetTime].filter(value => Number.isFinite(value) && value > now && value < 8.64e15);
    retryAt = candidates.length ? Math.max(...candidates) + 1000 : now + 60_000;
    reason = `${primaryLimit ? "GitHub API 请求额度已用尽" : secondaryLimit ? "GitHub 次级限流（请求过密）" : "GitHub 请求被限流"}。请在 ${new Date(retryAt).toLocaleString()} 后重试，不要连续点击同步。`;
  } else if (response.status === 401) {
    reason = "GitHub Token 无效或已过期，请重新设置。";
  } else if (response.status === 403 && /user.agent/i.test(rawMessage)) {
    reason = "GitHub 拒绝了 User-Agent 请求头。插件已发送应用标识，请检查网络代理是否移除了该请求头。";
  } else if (response.status === 403 && (/^required\b/i.test(headers["x-github-sso"] ?? "") || /SAML|single sign.on|\bSSO\b/i.test(rawMessage))) {
    reason = "组织 SSO / SAML 授权未完成。请为该 Token 完成组织授权，或联系组织管理员检查访问策略。";
  } else if (response.status === 403 && /IP.*(?:allow.?list|not permitted)|(?:allow.?list).*IP/i.test(rawMessage)) {
    reason = "当前网络出口 IP 不在组织允许列表中，请使用获准的网络或联系组织管理员。";
  } else if (response.status === 403 && /resource not accessible|permission|write access|access denied|must have.*push/i.test(rawMessage)) {
    reason = "当前 Token 或账户无权执行此操作。请核对目标仓库授权、Contents: Read and write，以及组织审批状态。";
  } else if (response.status === 403) {
    reason = "GitHub 拒绝访问，但未明确说明是权限还是访问策略问题。请查看「最近一次诊断」，不要仅凭 HTTP 403 判断为限流。";
  } else if (response.status === 404) {
    reason = "找不到仓库或分支，或 Token 无权访问。请检查目标授权；新仓库需先添加 README。";
  } else if (response.status === 409 || response.status === 422) {
    reason = "GitHub 拒绝提交：可能是其他设备更新、空仓库、分支保护或无效请求。请查看诊断后重新预览。";
  } else {
    reason = "GitHub 请求失败，请查看最近一次诊断。";
  }
  const summary = `${step(method, path)}失败（HTTP ${response.status}）：${reason}`;
  const lines = [summary, `发生时间：${new Date(now).toISOString()}`, `请求方法：${method}`,
    `GitHub 消息：${message || "未返回可用的错误信息"}`];
  for (const name of ["x-ratelimit-limit", "x-ratelimit-remaining", "x-ratelimit-reset", "retry-after", "x-accepted-github-permissions", "x-github-request-id"]) {
    if (headers[name]) lines.push(`${name}: ${redact(headers[name], token).slice(0, 300)}`);
  }
  if (primaryLimit && headers["x-ratelimit-limit"] === "60") {
    lines.push("提示：返回额度为 60，请检查认证是否生效，或代理是否移除了 Authorization 请求头；不能据此直接断言 Token 权限不足。");
  }
  return new GitHubApiError(summary, lines.join("\n"), retryAt, response.status);
}
