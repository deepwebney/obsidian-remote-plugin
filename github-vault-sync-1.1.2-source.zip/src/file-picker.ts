import { Modal, Notice, Setting, type App, type DropdownComponent } from "obsidian";
import { isSelected, selectPath, selectionState } from "./selection";
import { assertSafePath } from "./policy";
import type { Settings } from "./types";

interface TreeNode { path: string; children: Map<string, TreeNode>; file: boolean; }

export class FilePickerModal extends Modal {
  private rules: Record<string, boolean>;
  private syncScope: Settings["syncScope"];
  private scopeInput?: DropdownComponent;
  private readonly expanded = new Set<string>();
  private filter = "";
  private readonly paths = new Set<string>();
  private readonly folders = new Set<string>();
  private closed = false;
  private loading = false;
  private answer?: { scope: Settings["syncScope"]; rules: Record<string, boolean> };
  private resolve?: (value: typeof this.answer) => void;
  private rows?: HTMLElement;
  private selectionSummary?: HTMLElement;
  private readonly checkboxes = new Map<string, HTMLInputElement>();

  constructor(app: App, settings: Settings, paths: string[], private readonly loadRemote: () => Promise<string[]>) {
    super(app);
    this.rules = Object.assign(Object.create(null), settings.selection);
    this.syncScope = settings.syncScope;
    for (const path of [...paths, ...Object.keys(this.rules)]) this.addPath(path);
  }

  private addPath(path: string): void {
    const normalized = path.endsWith("/") ? path.slice(0, -1) : path;
    assertSafePath(normalized);
    if (path.endsWith("/")) this.folders.add(normalized);
    this.paths.add(normalized);
  }

  ask(): Promise<typeof this.answer> {
    return new Promise(resolve => { this.resolve = resolve; this.open(); });
  }

  onOpen(): void {
    this.contentEl.createEl("h2", { text: "选择同步文件与文件夹" });
    this.contentEl.createEl("p", { text: "勾选文件夹会包含未来新增文件；可取消其中的个别文件或子目录。全部模式下取消勾选会自动切换到自选模式。安全排除规则仍优先，取消勾选不会删除远程文件。" });
    new Setting(this.contentEl).setName("同步范围").addDropdown(input => {
      this.scopeInput = input;
      input.addOption("all", "全部允许的文件（保留安全排除）").addOption("selected", "仅同步勾选内容")
        .setValue(this.syncScope).onChange(value => { this.syncScope = value as Settings["syncScope"]; this.refreshSelection(); });
    });
    new Setting(this.contentEl).setName("载入 GitHub 文件列表").setDesc("只读取目录信息，不会上传或下载文件内容。")
      .addButton(button => button.setButtonText("载入远程列表").onClick(async () => {
        if (this.loading) return;
        this.loading = true;
        button.setDisabled(true).setButtonText("正在读取…");
        try {
          const remote = await this.loadRemote();
          if (!this.closed) {
            for (const path of remote) this.addPath(path);
            this.renderTree();
            new Notice(`已载入 ${remote.length} 个远程文件路径。`);
          }
        } catch (error) {
          if (!this.closed) new Notice(error instanceof Error ? error.message : "载入远程目录失败", 10000);
        } finally {
          this.loading = false;
          if (!this.closed) button.setDisabled(false).setButtonText("载入远程列表");
          else this.resolve?.(undefined);
        }
      }));
    new Setting(this.contentEl).setName("搜索路径").addText(input => input.setPlaceholder("文件或文件夹名称")
      .onChange(value => { this.filter = value.toLocaleLowerCase(); this.renderTree(); }));
    new Setting(this.contentEl).setName("批量选择").setDesc("只影响选择规则，不修改任何文件。")
      .addButton(button => button.setButtonText("全选当前根目录").onClick(() => {
        this.selectAllRoots();
        this.refreshSelection();
      }))
      .addButton(button => button.setButtonText("全部取消").onClick(() => {
        this.syncScope = "selected"; this.rules = Object.create(null); this.refreshSelection();
      }));
    this.rows = this.contentEl.createDiv({ cls: "gvs-file-tree" });
    this.renderTree();
    new Setting(this.contentEl)
      .addButton(button => button.setButtonText("取消").onClick(() => this.close()))
      .addButton(button => button.setButtonText("保存选择").setCta().onClick(() => {
        if (this.loading) { new Notice("请等待远程目录读取完成，或取消本次选择。"); return; }
        this.answer = { scope: this.syncScope, rules: this.rules }; this.close();
      }));
  }

  private selectAllRoots(): void {
    this.syncScope = "selected";
    this.rules = Object.create(null);
    for (const path of this.paths) this.rules[path.split("/")[0]] = true;
  }

  private refreshSelection(): void {
    const treeScroll = this.rows?.scrollTop ?? 0;
    const modalScroll = this.contentEl.scrollTop;
    this.scopeInput?.setValue(this.syncScope);
    if (this.selectionSummary) {
      this.selectionSummary.textContent = this.syncScope === "all" ? "当前：全部同步。可直接取消任意条目，其余已显示目录保持选中。" :
        `当前：仅同步勾选内容 · 列表内选中 ${[...this.paths].filter(path => isSelected(path, this.rules)).length} / ${this.paths.size} 个路径`;
    }
    for (const [path, checkbox] of this.checkboxes) {
      const state = selectionState(path, this.rules);
      checkbox.checked = this.syncScope === "all" || state.checked;
      checkbox.indeterminate = this.syncScope === "selected" && state.mixed;
      checkbox.disabled = false;
    }
    if (this.rows) this.rows.scrollTop = treeScroll;
    this.contentEl.scrollTop = modalScroll;
  }

  private renderTree(): void {
    if (!this.rows) return;
    const treeScroll = this.rows.scrollTop;
    const modalScroll = this.contentEl.scrollTop;
    this.rows.empty();
    this.checkboxes.clear();
    this.selectionSummary = this.rows.createEl("p");
    const root: TreeNode = { path: "", children: new Map(), file: false };
    for (const path of this.paths) {
      assertSafePath(path);
      let node = root;
      let prefix = "";
      for (const part of path.split("/")) {
        prefix = prefix ? `${prefix}/${part}` : part;
        if (!node.children.has(part)) node.children.set(part, { path: prefix, children: new Map(), file: false });
        node = node.children.get(part)!;
      }
      node.file = true;
    }
    const relevant = (node: TreeNode): boolean => !this.filter || node.path.toLocaleLowerCase().includes(this.filter) ||
      [...node.children.values()].some(relevant);
    const render = (parent: HTMLElement, node: TreeNode): void => {
      for (const [name, child] of [...node.children].sort(([left], [right]) => left.localeCompare(right))) {
        if (!relevant(child)) continue;
        const folder = child.children.size > 0 || this.folders.has(child.path);
        const wrapper = folder ? parent.createEl("details") : parent.createDiv();
        if (folder) {
          (wrapper as HTMLDetailsElement).open = !!this.filter || this.expanded.has(child.path);
          wrapper.addEventListener("toggle", () => {
            if (this.filter) return;
            if ((wrapper as HTMLDetailsElement).open) this.expanded.add(child.path);
            else this.expanded.delete(child.path);
          });
        }
        const row = folder ? wrapper.createEl("summary") : wrapper;
        const checkbox = row.createEl("input", { type: "checkbox" });
        checkbox.setAttribute("aria-label", child.path);
        this.checkboxes.set(child.path, checkbox);
        checkbox.addEventListener("click", event => event.stopPropagation());
        checkbox.addEventListener("change", () => {
          const selected = checkbox.checked;
          if (this.syncScope === "all") this.selectAllRoots();
          this.rules = selectPath(this.rules, child.path, selected);
          this.refreshSelection();
        });
        row.createSpan({ text: `${folder ? "📁 " : ""}${name}`, attr: { title: child.path } });
        if (folder) render(wrapper.createDiv({ cls: "gvs-tree-children" }), child);
      }
    };
    render(this.rows, root);
    this.refreshSelection();
    this.rows.scrollTop = treeScroll;
    this.contentEl.scrollTop = modalScroll;
  }

  onClose(): void {
    this.closed = true;
    if (!this.loading) this.resolve?.(this.answer);
    this.checkboxes.clear();
    this.contentEl.empty();
  }
}
