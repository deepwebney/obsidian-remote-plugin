import { sha1 } from "@noble/hashes/sha1";
import { bytesToHex } from "@noble/hashes/utils";

export function gitHash(bytes: Uint8Array): string {
  return bytesToHex(sha1.create().update(new TextEncoder().encode(`blob ${bytes.length}\0`)).update(bytes).digest());
}

export function toBase64(bytes: Uint8Array): string {
  const chunks: string[] = [];
  for (let offset = 0; offset < bytes.length; offset += 8192) {
    chunks.push(String.fromCharCode(...bytes.subarray(offset, offset + 8192)));
  }
  return btoa(chunks.join(""));
}

export function fromBase64(value: string): Uint8Array {
  const binary = atob(value.replace(/\s/g, ""));
  return Uint8Array.from(binary, character => character.charCodeAt(0));
}
