import assert from "node:assert/strict";
import test from "node:test";
import { isSelected, selectPath, selectionState } from "../src/selection";
import { PathPolicy } from "../src/policy";
import { defaults, migrateTarget, sameRepositoryTarget, targetKey } from "../src/types";

test("选中文件夹覆盖未来新文件，取消子项形成半选状态", () => {
  let rules = selectPath({}, "工作", true);
  assert(isSelected("工作/未来新增/笔记.md", rules));
  rules = selectPath(rules, "工作/私密", false);
  assert(!isSelected("工作/私密/a.md", rules));
  assert.deepEqual(selectionState("工作", rules), { checked: true, mixed: true });
  rules = selectPath(rules, "工作", true);
  assert.deepEqual(selectionState("工作", rules), { checked: true, mixed: false });
  assert.equal(Object.keys(rules).length, 1);
});

test("只选深层文件时可以遍历祖先目录，兄弟文件不被同步", () => {
  const policy = new PathPolicy({ ...defaults(), syncScope: "selected", selection: { "a/b/c.md": true } }, ".obsidian");
  assert(policy.canDescend("a")); assert(policy.canDescend("a/b"));
  assert(!policy.allows("a/b/d.md")); assert(policy.allows("a/b/c.md"));
  assert(!policy.canDescend("other"));
});

test("安全排除和额外排除始终优先于勾选", () => {
  const policy = new PathPolicy({ ...defaults(), syncScope: "selected", selection: {
    ".git": true, ".env": true, ".obsidian/plugins/github-vault-sync": true, "private": true
  }, exclusions: "private/" }, ".obsidian");
  for (const path of [".git/config", ".env", ".obsidian/plugins/github-vault-sync/data.json", "private/a.md"]) assert(!policy.allows(path));
});

test("单文件选中时自动包含其冲突副本，显式取消副本可覆盖", () => {
  const settings = { ...defaults(), syncScope: "selected" as const, selection: { "note.md": true } as Record<string, boolean> };
  const policy = new PathPolicy(settings, ".obsidian");
  assert(policy.allows("note.conflict-2026-test-1.md"));
  settings.selection["note.conflict-2026-test-1.md"] = false;
  assert(!policy.allows("note.conflict-2026-test-1.md"));
});

test("空勾选不同步任何文件，全部模式保留旧版行为", () => {
  assert(!new PathPolicy({ ...defaults(), syncScope: "selected" }, ".obsidian").allows("a.md"));
  assert(new PathPolicy(defaults(), ".obsidian").allows("a.md"));
});

test("选择和删除策略变化重置目标基线，规则插入顺序不影响目标", () => {
  const first = { ...defaults(), syncScope: "selected" as const, selection: { "a.md": true, "b.md": false } };
  assert.equal(targetKey(first, ".obsidian"), targetKey({ ...first, selection: { "b.md": false, "a.md": true } }, ".obsidian"));
  assert.notEqual(targetKey(first, ".obsidian"), targetKey({ ...first, propagateDeletes: true }, ".obsidian"));
  assert.notEqual(targetKey(first, ".obsidian"), targetKey({ ...first, selection: { "a.md": false } }, ".obsidian"));
});

test("升级时仅迁移匹配原范围的旧版目标标识", () => {
  const settings = defaults();
  const current = targetKey(settings, ".obsidian");
  const previous = JSON.stringify(JSON.parse(current).slice(0, 7));
  assert.equal(migrateTarget(previous, settings, ".obsidian"), current);
  assert.equal(migrateTarget(previous, { ...settings, repo: "changed" }, ".obsidian"), previous);
  assert.equal(migrateTarget(previous, { ...settings, syncScope: "selected" }, ".obsidian"), previous);
});

test("重新勾选后同仓库缓存可复用，但不跨仓库复用", () => {
  const settings = { ...defaults(), owner: "owner", repo: "vault" };
  const previous = targetKey(settings, ".obsidian");
  assert(sameRepositoryTarget(previous, targetKey({ ...settings, syncScope: "selected", selection: { "note.md": true } }, ".obsidian")));
  assert(!sameRepositoryTarget(previous, targetKey({ ...settings, repo: "different" }, ".obsidian")));
  assert(!sameRepositoryTarget("invalid", previous));
});
