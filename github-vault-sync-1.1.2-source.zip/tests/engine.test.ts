import assert from "node:assert/strict";
import test from "node:test";
import { SyncEngine } from "../src/engine";
import { gitHash } from "../src/hash";
import type { LocalStore, RemoteSnapshot, RemoteStore, Snapshot } from "../src/types";

const encode = (value: string): Uint8Array => new TextEncoder().encode(value);
const decode = (value?: Uint8Array): string => new TextDecoder().decode(value);

class MemoryLocal implements LocalStore {
  files = new Map<string, Uint8Array>();
  backups = new Map<string, Uint8Array>();
  staging = new Map<string, Uint8Array>();
  writes = 0;
  failWrite = false;
  constructor(files: Record<string, string> = {}) {
    for (const [path, value] of Object.entries(files)) this.files.set(path, encode(value));
  }
  async scan(): Promise<Snapshot> { return Object.fromEntries([...this.files].map(([path, bytes]) => [path, gitHash(bytes)])); }
  async read(path: string): Promise<Uint8Array> {
    const bytes = this.files.get(path);
    if (!bytes) throw new Error("not found");
    return bytes;
  }
  async hash(path: string): Promise<string | undefined> { const bytes = this.files.get(path); return bytes ? gitHash(bytes) : undefined; }
  async write(path: string, bytes: Uint8Array): Promise<void> {
    if (this.failWrite) throw new Error("disk full");
    this.files.set(path, bytes); this.writes++;
  }
  async remove(path: string): Promise<void> { this.files.delete(path); this.writes++; }
  async backup(path: string, bytes: Uint8Array, runId: string): Promise<void> { this.backups.set(`${runId}/${path}`, bytes); }
  async stage(path: string, bytes: Uint8Array): Promise<void> { this.staging.set(path, bytes); }
  async readStaged(path: string): Promise<Uint8Array> { return this.staging.get(path)!; }
  async cleanupStage(): Promise<void> { this.staging.clear(); }
}

class MemoryRemote implements RemoteStore {
  head = "head-0";
  files: Snapshot = Object.create(null);
  blobs = new Map<string, Uint8Array>();
  commitCount = 0;
  beforeCommit?: () => void;
  afterDownload?: () => void;
  failDownload = false;
  constructor(files: Record<string, string> = {}) {
    for (const [path, value] of Object.entries(files)) this.put(path, encode(value));
  }
  put(path: string, bytes: Uint8Array): void { const sha = gitHash(bytes); this.blobs.set(sha, bytes); this.files[path] = sha; }
  async snapshot(): Promise<RemoteSnapshot> {
    return { head: this.head, tree: "tree", files: { ...this.files }, sizes: Object.fromEntries(Object.entries(this.files).map(([path, sha]) => [path, this.blobs.get(sha)!.length])) };
  }
  async assertHead(expected: string): Promise<void> { assert.equal(this.head, expected, "remote moved"); }
  async download(sha: string): Promise<Uint8Array> {
    if (this.failDownload) throw new Error("offline");
    this.afterDownload?.();
    return this.blobs.get(sha)!;
  }
  async upload(bytes: Uint8Array): Promise<string> { const sha = gitHash(bytes); this.blobs.set(sha, bytes); return sha; }
  async commit(snapshot: RemoteSnapshot, changes: Record<string, string | null>): Promise<string> {
    this.beforeCommit?.();
    await this.assertHead(snapshot.head);
    if (!Object.keys(changes).length) return this.head;
    this.commitCount++;
    for (const [path, sha] of Object.entries(changes)) {
      if (sha === null) delete this.files[path]; else this.files[path] = sha;
    }
    return this.head = `head-${this.commitCount}`;
  }
}

test("两台设备上传、恢复、离线编辑冲突、再次同步完整流程", async () => {
  const remote = new MemoryRemote({ "README.md": "vault" });
  const first = new MemoryLocal({ "笔记.md": "version 1" });
  first.files.set("附件/photo.png", new Uint8Array([0, 255, 10, 128]));
  const firstEngine = new SyncEngine(first, remote);
  let firstBase = await firstEngine.execute(await firstEngine.prepare({}, "sync", false), {}, "Mac");
  const second = new MemoryLocal();
  const secondEngine = new SyncEngine(second, remote);
  let secondBase = await secondEngine.execute(await secondEngine.prepare({}, "restore", false), {}, "Windows");
  assert.deepEqual([...second.files].sort(), [...first.files].sort());
  assert.equal(remote.commitCount, 1);
  first.files.set("笔记.md", encode("Mac edit"));
  firstBase = await firstEngine.execute(await firstEngine.prepare(firstBase, "sync", false), firstBase, "Mac");
  second.files.set("笔记.md", encode("Windows edit"));
  const conflictPlan = await secondEngine.prepare(secondBase, "sync", false);
  secondBase = await secondEngine.execute(conflictPlan, secondBase, "Windows");
  const conflictPath = conflictPlan.actions.find(action => action.kind === "conflict")!.copyPath!;
  assert.equal(decode(second.files.get("笔记.md")), "Mac edit");
  assert.equal(decode(second.files.get(conflictPath)), "Windows edit");
  assert.equal(decode(remote.blobs.get(remote.files[conflictPath])), "Windows edit");
  assert.equal(decode([...second.backups.values()][0]), "Windows edit");
  firstBase = await firstEngine.execute(await firstEngine.prepare(firstBase, "sync", false), firstBase, "Mac");
  assert.deepEqual([...first.files].sort(), [...second.files].sort());
  assert.deepEqual((await secondEngine.prepare(secondBase, "sync", false)).actions, []);
  assert(Object.keys(firstBase).includes(conflictPath));
});

test("仅下载冲突保留本机副本但不写远程", async () => {
  const remote = new MemoryRemote({ "note.md": "remote" });
  const local = new MemoryLocal({ "note.md": "local", "only-local.md": "private" });
  const engine = new SyncEngine(local, remote);
  const plan = await engine.prepare({}, "restore", true);
  await engine.execute(plan, {}, "device");
  assert.equal(remote.commitCount, 0);
  assert.deepEqual(Object.keys(remote.files), ["note.md"]);
  assert.equal(decode(local.files.get(plan.actions[0].copyPath!)), "local");
  assert.equal(decode(local.files.get("note.md")), "remote");
  assert(local.files.has("only-local.md"));
});

test("本机在预览之后编辑：中止且不提交", async () => {
  const remote = new MemoryRemote({ "note.md": "remote" });
  const local = new MemoryLocal({ "note.md": "local" });
  const engine = new SyncEngine(local, remote);
  const plan = await engine.prepare({}, "sync", false);
  local.files.set("note.md", encode("newer edit"));
  await assert.rejects(engine.execute(plan, {}, "device"), /变化/);
  assert.equal(remote.commitCount, 0);
  assert.equal(local.writes, 0);
});

test("本机下载期间编辑：中止且不覆盖", async () => {
  const remote = new MemoryRemote({ "note.md": "remote" });
  const local = new MemoryLocal();
  const engine = new SyncEngine(local, remote);
  const plan = await engine.prepare({}, "sync", false);
  remote.afterDownload = () => local.files.set("note.md", encode("new note"));
  await assert.rejects(engine.execute(plan, {}, "device"), /变化/);
  assert.equal(decode(local.files.get("note.md")), "new note");
  assert.equal(local.writes, 0);
});

test("远程并发提交：不覆盖远程且不应用本机修改", async () => {
  const remote = new MemoryRemote({ "note.md": "remote" });
  const local = new MemoryLocal({ "note.md": "local" });
  const engine = new SyncEngine(local, remote);
  const plan = await engine.prepare({}, "sync", false);
  remote.beforeCommit = () => { remote.head = "other-device-commit"; };
  await assert.rejects(engine.execute(plan, {}, "device"), /remote moved/);
  assert.equal(local.writes, 0);
  assert.equal(remote.commitCount, 0);
  assert.equal(decode(local.files.get("note.md")), "local");
});

test("下载失败不会提交或修改本机文件", async () => {
  const remote = new MemoryRemote({ "note.md": "remote" });
  remote.failDownload = true;
  const local = new MemoryLocal({ "upload.md": "local" });
  const engine = new SyncEngine(local, remote);
  await assert.rejects(engine.execute(await engine.prepare({}, "sync", false), {}, "device"), /offline/);
  assert.equal(remote.commitCount, 0);
  assert.equal(local.writes, 0);
});

test("远程已提交后磁盘写入失败仍保留原文、备份和暂存", async () => {
  const remote = new MemoryRemote({ "note.md": "remote" });
  const local = new MemoryLocal({ "note.md": "local" });
  local.failWrite = true;
  const engine = new SyncEngine(local, remote);
  const plan = await engine.prepare({}, "sync", false);
  await assert.rejects(engine.execute(plan, {}, "device"), /disk full/);
  assert.equal(decode(local.files.get("note.md")), "local");
  assert.equal(decode([...local.backups.values()][0]), "local");
  assert.equal(decode(remote.blobs.get(remote.files[plan.actions[0].copyPath!])), "local");
  assert(local.staging.size > 0);
  local.failWrite = false;
  await engine.execute(await engine.prepare({}, "sync", false), {}, "device");
  assert.equal(decode(local.files.get("note.md")), "remote");
});

test("传播远程删除前保留本机备份", async () => {
  const local = new MemoryLocal({ "note.md": "old" });
  const baseline = await local.scan();
  const remote = new MemoryRemote();
  const engine = new SyncEngine(local, remote);
  const nextBase = await engine.execute(await engine.prepare(baseline, "sync", true), baseline, "device");
  assert(!local.files.has("note.md"));
  assert(!nextBase["note.md"]);
  assert.equal(decode([...local.backups.values()][0]), "old");
});

test("上传只产生一个提交；无变更同步不提交", async () => {
  const remote = new MemoryRemote();
  const local = new MemoryLocal({ "a.md": "a", "b.md": "b", "c.md": "c" });
  const engine = new SyncEngine(local, remote);
  const baseline = await engine.execute(await engine.prepare({}, "sync", false), {}, "device");
  assert.equal(remote.commitCount, 1);
  await engine.execute(await engine.prepare(baseline, "sync", false), baseline, "device");
  assert.equal(remote.commitCount, 1);
});
