import assert from "node:assert/strict";
import test from "node:test";
import { GitHubApiError } from "../src/api-error";
import { SyncStoppedError } from "../src/cancellation";
import { RequestControl } from "../src/request-control";

test("临时故障最多自动重试三次，指数退避且保留诊断", async () => {
  let clock = 0;
  const control = new RequestControl(() => clock, async delay => { clock += delay; });
  const error = new GitHubApiError("服务不可用", "request-id: test", 0, 503);
  for (let attempt = 0; attempt < 3; attempt++) assert(await control.retry(error, attempt));
  assert.equal(clock, 14000);
  await assert.rejects(control.retry(error, 3), failure => failure instanceof GitHubApiError &&
    failure.details.includes("request-id: test") && !failure.retryable);
});

test("短期限流等待冷却到期，不提前请求，并显示自动继续", async () => {
  let clock = 0;
  const messages: string[] = [];
  const control = new RequestControl(() => clock, async delay => { clock += delay; });
  const error = new GitHubApiError("限流", "retry-after", 60000, 429);
  control.hold(error);
  await control.retry(error, 0, undefined, message => messages.push(message));
  assert.equal(clock, 60000);
  await control.before("POST");
  assert(messages.some(message => /60 秒.*自动重试/.test(message)));
});

test("等待期间停止在 250ms 内检查，不开始下一次请求", async () => {
  let clock = 0;
  let stopped = false;
  const control = new RequestControl(() => clock, async delay => { clock += delay; stopped = true; });
  await assert.rejects(control.retry(new GitHubApiError("限流", "", 60000, 429), 0,
    () => { if (stopped) throw new SyncStoppedError(); }), SyncStoppedError);
  assert.equal(clock, 250);
});

test("超过五分钟冷却明确停止等待手动继续，不循环重试", async () => {
  const control = new RequestControl(() => 0, async () => { assert.fail("不应等待"); });
  await assert.rejects(control.retry(new GitHubApiError("主额度耗尽", "reset", 3600000, 403), 0),
    /超过 5 分钟.*继续上次任务/);
});

test("权限、校验、磁盘及用户停止等错误不自动重试", async () => {
  const control = new RequestControl();
  for (const error of [new GitHubApiError("权限不足", "", 0, 403), new GitHubApiError("无效请求", "", 0, 422),
    new Error("磁盘写满"), new SyncStoppedError()]) {
    assert.equal(await control.retry(error, 0), false);
  }
});
