import assert from "node:assert/strict";
import { after, before, test } from "node:test";
import { promises as fs } from "node:fs";
import { execFileSync } from "node:child_process";
import { join, resolve } from "node:path";
import { tmpdir } from "node:os";

let temporary: string;
let installer: string;
const files = ["main.js", "manifest.json", "styles.css"];
before(async () => {
  temporary = await fs.mkdtemp(join(tmpdir(), "gvs-install-tests-"));
  const release = join(temporary, "release");
  await fs.mkdir(join(release, "github-vault-sync"), { recursive: true });
  installer = join(release, "Install.command");
  await fs.copyFile(resolve("scripts/Install.command"), installer);
  for (const file of files) await fs.writeFile(join(release, "github-vault-sync", file), `new-${file}`);
});
after(async () => { await fs.rm(temporary, { recursive: true, force: true }); });

test("安装脚本：安装到含空格和中文的 Vault，保留所有笔记", async () => {
  const vault = join(temporary, "我的 Vault");
  await fs.mkdir(join(vault, ".obsidian"), { recursive: true });
  await fs.writeFile(join(vault, "note.md"), "keep-note");
  execFileSync("bash", [installer, vault]);
  for (const file of files) assert.equal(await fs.readFile(join(vault, ".obsidian/plugins/github-vault-sync", file), "utf8"), `new-${file}`);
  assert.equal(await fs.readFile(join(vault, "note.md"), "utf8"), "keep-note");
});

test("安装脚本：升级保留 data.json 并备份旧插件", async () => {
  const vault = join(temporary, "upgrade");
  const destination = join(vault, ".obsidian/plugins/github-vault-sync");
  await fs.mkdir(destination, { recursive: true });
  await fs.writeFile(join(destination, "data.json"), "keep-local-state");
  await fs.writeFile(join(destination, "main.js"), "old-code");
  execFileSync("bash", [installer, vault]);
  assert.equal(await fs.readFile(join(destination, "data.json"), "utf8"), "keep-local-state");
  const backupRoot = join(vault, ".github-vault-sync-local/install-backups");
  const backups = await fs.readdir(backupRoot);
  assert.equal(backups.length, 1);
  assert.equal(await fs.readFile(join(backupRoot, backups[0], "main.js"), "utf8"), "old-code");
});

test("安装脚本：支持自定义配置目录", async () => {
  const vault = join(temporary, "custom");
  await fs.mkdir(join(vault, ".my-config"), { recursive: true });
  execFileSync("bash", [installer, vault, ".my-config"]);
  assert.equal(await fs.readFile(join(vault, ".my-config/plugins/github-vault-sync/main.js"), "utf8"), "new-main.js");
});

test("安装脚本：拒绝未初始化的 Vault", async () => {
  const vault = join(temporary, "not-a-vault");
  await fs.mkdir(vault);
  assert.throws(() => execFileSync("bash", [installer, vault], { stdio: "pipe" }));
  assert.deepEqual(await fs.readdir(vault), []);
});

test("安装脚本：拒绝插件目录符号链接", async () => {
  const vault = join(temporary, "symlink");
  const outside = join(temporary, "external-plugin");
  await fs.mkdir(join(vault, ".obsidian/plugins"), { recursive: true });
  await fs.mkdir(outside);
  await fs.writeFile(join(outside, "main.js"), "untouched");
  await fs.symlink(outside, join(vault, ".obsidian/plugins/github-vault-sync"), "dir");
  assert.throws(() => execFileSync("bash", [installer, vault], { stdio: "pipe" }));
  assert.equal(await fs.readFile(join(outside, "main.js"), "utf8"), "untouched");
});
