import assert from "node:assert/strict";
import test from "node:test";
import { GitHub, type Transport } from "../src/github";
import { PathPolicy } from "../src/policy";
import { RequestControl } from "../src/request-control";
import { defaults, type CommitRecovery, type CommitState } from "../src/types";
import { SyncStoppedError } from "../src/cancellation";

function fixture() {
  const settings = { ...defaults(), owner: "owner", repo: "vault" };
  let head = "base";
  let failPatch: "none" | "before" | "after" = "none";
  let readsFail = false;
  let stopped = false;
  let stopAfterPatch = false;
  let clock = 0;
  let creates = 0;
  let patches = 0;
  const calls: string[] = [];
  const state: CommitState = { baseHead: "base", baseTree: "base-tree", changes: { "a.md": "blob" }, message: "unique-batch", phase: "prepared" };
  const saved: CommitState[] = [];
  const check = (): void => { if (stopped) throw new SyncStoppedError(); };
  const recovery: CommitRecovery = { state, check, save: async () => { saved.push(JSON.parse(JSON.stringify(state)) as CommitState); } };
  const transport: Transport = async (method, url, _headers, body) => {
    calls.push(`${method} ${url}`);
    if (url.includes("/git/ref/")) {
      if (readsFail) throw new Error("offline");
      return { status: 200, json: { object: { sha: head } }, headers: {} };
    }
    if (url.includes("/compare/")) return { status: 200, json: { status: head === "descendant" ? "ahead" : "diverged" }, headers: {} };
    if (url.endsWith("/git/trees")) return { status: 201, json: { sha: "new-tree" }, headers: {} };
    if (url.endsWith("/git/commits")) {
      creates++;
      return { status: 201, json: { sha: "new-commit" }, headers: {} };
    }
    if (method === "PATCH") {
      assert.equal(saved.at(-1)?.phase, "updating");
      assert.equal(saved.at(-1)?.commitSha, "new-commit");
      assert.equal(JSON.parse(body!).force, false);
      patches++;
      if (failPatch === "before") throw new Error("lost before server applied");
      head = "new-commit";
      if (stopAfterPatch) stopped = true;
      if (failPatch === "after") throw new Error("lost after server applied");
      return { status: 200, json: {}, headers: {} };
    }
    throw new Error(`unexpected ${url}`);
  };
  const github = new GitHub(settings, "token", new PathPolicy(settings, ".obsidian"), transport,
    new RequestControl(() => clock, async delay => { clock += delay; }), check);
  const commit = () => github.commit({ head: "base", tree: "base-tree", files: {}, sizes: {} }, state.changes, state.message, recovery);
  return { github, commit, state, saved, calls,
    get creates() { return creates; }, get patches() { return patches; },
    set failPatch(value: typeof failPatch) { failPatch = value; },
    set head(value: string) { head = value; }, set readsFail(value: boolean) { readsFail = value; },
    set stopped(value: boolean) { stopped = value; }, set stopAfterPatch(value: boolean) { stopAfterPatch = value; }
  };
}

test("真实 GitHub 客户端：PATCH 响应丢失后 GET 确认已成功", async () => {
  const mock = fixture(); mock.failPatch = "after";
  assert.equal(await mock.commit(), "new-commit");
  assert.equal(mock.state.phase, "confirmed");
  assert.equal(mock.creates, 1); assert.equal(mock.patches, 1);
  assert.match(mock.calls.at(-1)!, /GET .*\/git\/ref\//);
  await mock.commit();
  assert.equal(mock.creates, 1); assert.equal(mock.patches, 1);
});

test("真实 GitHub 客户端：分支未更新则下次复用 commit，不重复创建", async () => {
  const mock = fixture(); mock.failPatch = "before";
  await assert.rejects(mock.commit(), /分支尚未更新/);
  assert.equal(mock.state.phase, "updating");
  mock.failPatch = "none";
  await mock.commit();
  assert.equal(mock.creates, 1); assert.equal(mock.patches, 2);
});

test("真实 GitHub 客户端：已确认提交的后续提交用祖先关系核对", async () => {
  const mock = fixture(); await mock.commit();
  mock.head = "descendant";
  assert.equal(await mock.commit(), "new-commit");
  assert.equal(mock.creates, 1); assert.equal(mock.patches, 1);
  assert(mock.calls.some(call => call.includes("/compare/new-commit...descendant")));
});

test("真实 GitHub 客户端：远程分歧不重复 PATCH，已确认后回退也不重放", async () => {
  const mock = fixture(); await mock.commit();
  mock.head = "unrelated";
  await assert.rejects(mock.commit(), /不会重放/);
  mock.head = "base";
  await assert.rejects(mock.commit(), /不会重放/);
  assert.equal(mock.patches, 1);
});

test("真实 GitHub 客户端：无法读取远程时不尝试新的写请求", async () => {
  const mock = fixture(); mock.failPatch = "before";
  await assert.rejects(mock.commit());
  mock.readsFail = true;
  const patches = mock.patches;
  await assert.rejects(mock.commit(), /无法连接/);
  assert.equal(mock.patches, patches);
});

test("真实 GitHub 客户端：停止时仍记录已经返回的分支更新结果", async () => {
  const mock = fixture(); mock.stopAfterPatch = true;
  await mock.commit();
  assert.equal(mock.state.phase, "confirmed");
  assert.equal(mock.saved.at(-1)?.phase, "confirmed");
  await assert.rejects(mock.github.info(), /已停止/);
  mock.stopped = false;
  await mock.commit();
  assert.equal(mock.patches, 1);
});
