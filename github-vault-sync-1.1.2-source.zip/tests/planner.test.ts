import assert from "node:assert/strict";
import test from "node:test";
import { fromBase64, gitHash, toBase64 } from "../src/hash";
import { planSync } from "../src/planner";
import { assertCompatiblePaths, assertSafePath, PathPolicy } from "../src/policy";
import { defaults, type Mode, type Snapshot } from "../src/types";

const snapshot = (sha?: string): Snapshot => sha ? { "note.md": sha } : {};
const cases: [string, string | undefined, string | undefined, string | undefined, boolean, string | undefined][] = [
  ["初次上传", "local", undefined, undefined, false, "upload"],
  ["空设备恢复", undefined, "remote", undefined, true, "download"],
  ["首次同内容", "same", "same", undefined, false, undefined],
  ["首次冲突保留两份", "local", "remote", undefined, false, "conflict"],
  ["本机修改", "new", "old", "old", false, "upload"],
  ["远程修改", "old", "new", "old", false, "download"],
  ["双方相同修改", "new", "new", "old", false, undefined],
  ["双方不同修改", "local", "remote", "old", false, "conflict"],
  ["默认补回本机删除", undefined, "old", "old", false, "download"],
  ["默认补回远程删除", "old", undefined, "old", false, "upload"],
  ["确认传播本机删除", undefined, "old", "old", true, "delete-remote"],
  ["确认传播远程删除", "old", undefined, "old", true, "delete-local"],
  ["本机编辑优先于远程删除", "new", undefined, "old", true, "upload"],
  ["远程编辑优先于本机删除", undefined, "new", "old", true, "download"],
  ["双方删除", undefined, undefined, "old", true, undefined]
];
for (const [name, local, remote, baseline, deletes, expected] of cases) {
  test(name, () => assert.equal(planSync(snapshot(local), snapshot(remote), snapshot(baseline), "sync", deletes, "test")[0]?.kind, expected));
}

test("仅下载模式不会产生上传或删除动作", () => {
  for (const local of [undefined, "base", "local"]) {
    for (const remote of [undefined, "base", "remote"]) {
      for (const base of [undefined, "base"]) {
        const actions = planSync(snapshot(local), snapshot(remote), snapshot(base), "restore", true, "test");
        assert(actions.every(action => action.kind === "download" || action.kind === "conflict"));
      }
    }
  }
});

test("仅下载保留远端未变时的本机修改", () => {
  assert.deepEqual(planSync(snapshot("local"), snapshot("base"), snapshot("base"), "restore", false, "test"), []);
});

test("冲突副本保留扩展名并避开已有名称", () => {
  const actions = planSync({ "note.md": "local", "note.conflict-test-1.md": "existing" }, { "note.md": "remote" }, {}, "sync", false, "test");
  assert.equal(actions.find(action => action.kind === "conflict")?.copyPath, "note.conflict-test-2.md");
});

test("对象原型名称也能作为正常笔记文件", () => {
  for (const name of ["constructor", "toString", "__proto__"]) {
    assert.equal(planSync({ [name]: "new" }, {}, {}, "sync", false, "test")[0]?.kind, "upload");
  }
});

test("拒绝跨平台路径冲突", () => {
  for (const paths of [["Note.md", "note.md"], ["folder", "folder/note.md"], ["A/a.md", "a/b.md"], ["é.md", "e\u0301.md"]]) {
    assert.throws(() => assertCompatiblePaths(paths));
  }
});

test("拒绝目录穿越、Windows 保留名和非法字符", () => {
  for (const path of ["../a", "/a", "a/../b", "a\\b", "a//b", "a/CON.txt", "a:stream", "a. ", "a\0b"]) {
    assert.throws(() => assertSafePath(path), path);
  }
  assertSafePath("笔记/你好 👋.md");
});

test("同步配置但排除 Token、本插件、布局、其他插件数据及凭据", () => {
  const settings = { ...defaults(), includePluginCode: true };
  const policy = new PathPolicy(settings, ".obsidian");
  for (const path of [".obsidian/app.json", ".obsidian/snippets/a.css", ".obsidian/themes/Blue/theme.css", ".obsidian/plugins/other/main.js", "附件/a.png", ".obsidian/app.conflict-test-1.json"]) {
    assert(policy.allows(path), path);
  }
  for (const path of [".obsidian/plugins/github-vault-sync/data.json", ".obsidian/plugins/github-vault-sync/main.js", ".obsidian/plugins/other/data.json", ".obsidian/workspace.json", ".obsidian/workspace-mobile.json", ".obsidian/secret-storage.json", ".git/config", "a/.env.production", "private.pem", ".github-vault-sync-local/backups/a.md", "node_modules/test.txt"]) {
    assert(!policy.allows(path), path);
  }
});

test("自定义配置目录以及额外排除规则", () => {
  const policy = new PathPolicy({ ...defaults(), exclusions: "private/\n*.tmp\ncache" }, ".custom");
  assert(policy.allows(".custom/app.json"));
  for (const path of ["private/a.md", "nested/private/a.md", "a.tmp", "nested/a.tmp", "cache/a.md"]) assert(!policy.allows(path));
  assert(policy.allows("public/a.md"));
  assert(!new PathPolicy({ ...defaults(), includeConfig: false }, ".custom").allows(".custom/app.json"));
  assert(!new PathPolicy(defaults(), ".obsidian").allows(".obsidian/plugins/example/main.js"));
});

test("Git blob SHA-1 与二进制 base64 编解码", () => {
  assert.equal(gitHash(new Uint8Array()), "e69de29bb2d1d6434b8b29ae775ad8c2e48c5391");
  assert.equal(gitHash(new TextEncoder().encode("hello\n")), "ce013625030ba8dba906f756967f9e9ca394464a");
  const bytes = Uint8Array.from({ length: 40000 }, (_, index) => index % 256);
  assert.deepEqual(fromBase64(toBase64(bytes)), bytes);
});

test("三方矩阵：不同版本不得静默覆盖", () => {
  for (const mode of ["sync", "restore"] satisfies Mode[]) {
    for (const base of [undefined, "base"]) {
      const action = planSync(snapshot("left"), snapshot("right"), snapshot(base), mode, true, "run")[0];
      assert.equal(action.kind, "conflict");
      assert(action.copyPath);
    }
  }
});
