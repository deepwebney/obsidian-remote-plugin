import assert from "node:assert/strict";
import test from "node:test";
import { build } from "esbuild";
import { runInNewContext } from "node:vm";
import { resolve } from "node:path";

test("插件入口可加载、注册命令、保存本机状态且不保存 Token", async () => {
  const commands: string[] = [];
  const notices: string[] = [];
  const statuses: string[] = [];
  const secrets = new Map<string, string>();
  let saved: unknown;
  let requests = 0;
  let pendingRequest: Promise<{ status: number; json: unknown; text: string; headers: Record<string, string> }> | undefined;
  const app = {
    vault: { configDir: ".obsidian" },
    secretStorage: { getSecret: (id: string) => secrets.get(id) ?? null, setSecret: (id: string, value: string) => secrets.set(id, value) },
    workspace: { onLayoutReady: (callback: () => void) => callback() }
  };
  class MockPlugin {
    app = app;
    async loadData(): Promise<null> { return null; }
    async saveData(data: unknown): Promise<void> { saved = data; }
    addStatusBarItem(): { setText: (text: string) => void } { return { setText: text => { statuses.push(text); } }; }
    addRibbonIcon(): void {}
    addCommand(command: { id: string }): void { commands.push(command.id); }
    addSettingTab(): void {}
    registerInterval(): void {}
  }
  const obsidian = {
    Plugin: MockPlugin, Modal: class {}, PluginSettingTab: class {}, Setting: class {},
    FileSystemAdapter: class {}, TFile: class {},
    Notice: class { constructor(message: string) { notices.push(message); } },
    requestUrl: async () => {
      requests++;
      if (pendingRequest) return pendingRequest;
      return { status: 403, json: { message: "Resource not accessible by personal access token: test-secret-not-for-data-json" },
        text: "", headers: { "X-Accepted-GitHub-Permissions": "contents=read" } };
    }
  };
  const bundle = await build({ entryPoints: [resolve("src/main.ts")], bundle: true, write: false, platform: "browser", format: "cjs", external: ["obsidian", "node:fs"] });
  interface PluginShape {
    onload(): Promise<void>;
    onunload(): void;
    persist(): Promise<void>;
    run(mode: string, automatic?: boolean): Promise<void>;
    testConnection(): Promise<void>;
    stopSync(): void;
    data: { settings: { secretId: string; owner: string; repo: string; branch: string; autoSync: boolean }; transfer?: { plan: { mode: string }; nextIndex: number } };
    busy: boolean;
    lastDiagnostic: string;
  }
  const module = { exports: {} as { default: new () => PluginShape } };
  runInNewContext(bundle.outputFiles[0].text, {
    module, exports: module.exports, TextEncoder, Uint8Array, ArrayBuffer,
    window: { clearInterval: () => {} },
    require: (name: string) => { assert.equal(name, "obsidian"); return obsidian; }
  });
  const plugin = new module.exports.default();
  await plugin.onload();
  assert.deepEqual(commands, ["sync", "restore", "stop", "resume"]);
  secrets.set(plugin.data.settings.secretId, "test-secret-not-for-data-json");
  await plugin.persist();
  assert(!JSON.stringify(saved).includes("test-secret-not-for-data-json"));
  await plugin.run("sync");
  assert.equal(requests, 0);
  assert(notices.some(message => message.includes("用户名")));
  assert.equal(plugin.busy, false);
  assert.match(plugin.lastDiagnostic, /用户名/);
  Object.assign(plugin.data.settings, { owner: "owner", repo: "vault", branch: "main" });
  await Promise.all([plugin.testConnection(), plugin.testConnection()]);
  assert.equal(requests, 1);
  assert.equal(plugin.busy, false);
  assert.match(plugin.lastDiagnostic, /HTTP 403/);
  assert.match(plugin.lastDiagnostic, /contents=read/);
  assert(!plugin.lastDiagnostic.includes("test-secret-not-for-data-json"));
  await plugin.persist();
  assert(!JSON.stringify(saved).includes("HTTP 403"));
  let finishRequest!: (value: { status: number; json: unknown; text: string; headers: Record<string, string> }) => void;
  pendingRequest = new Promise(resolve => { finishRequest = resolve; });
  plugin.data.settings.autoSync = true;
  const running = plugin.testConnection();
  for (let attempt = 0; requests < 2 && attempt < 20; attempt++) await Promise.resolve();
  assert.equal(requests, 2);
  plugin.stopSync();
  assert.equal(plugin.data.settings.autoSync, false);
  assert.equal(plugin.busy, true);
  finishRequest({ status: 200, json: { full_name: "owner/vault", private: true }, text: "", headers: {} });
  await running;
  assert.equal(requests, 2);
  assert.equal(plugin.busy, false);
  assert(notices.some(message => message.includes("已停止")));
  plugin.data.transfer = { plan: { mode: "sync" }, nextIndex: 20 };
  plugin.busy = true;
  const statusBefore = statuses.at(-1);
  await plugin.run("sync", true);
  assert.equal(statuses.at(-1), statusBefore);
  assert.equal(requests, 2);
  plugin.busy = false;
  await plugin.run("sync", true);
  assert.match(statuses.at(-1)!, /有未完成任务，请手动继续/);
  assert.equal(requests, 2);
  plugin.onunload();
});
