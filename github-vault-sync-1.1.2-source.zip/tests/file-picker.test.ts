import assert from "node:assert/strict";
import { before, test } from "node:test";
import { runInNewContext } from "node:vm";
import { resolve } from "node:path";
import { build } from "esbuild";
import { defaults, type Settings } from "../src/types";

class Element {
  children: Element[] = [];
  attrs = new Map<string, string>();
  events = new Map<string, (() => void)[]>();
  checked = false;
  indeterminate = false;
  disabled = false;
  open = false;
  scrollTop = 0;
  className = "";
  textContent = "";
  text = "";
  constructor(readonly tag = "div") {}
  empty(): void { this.children = []; this.scrollTop = 0; }
  createEl(tag: string, options: { text?: string; cls?: string; attr?: Record<string, string> } = {}): Element {
    const child = new Element(tag);
    child.text = options.text ?? "";
    child.className = options.cls ?? "";
    for (const [name, value] of Object.entries(options.attr ?? {})) child.attrs.set(name, value);
    this.children.push(child); return child;
  }
  createDiv(options: { cls?: string } = {}): Element { return this.createEl("div", options); }
  createSpan(options: { text?: string; attr?: Record<string, string> }): Element { return this.createEl("span", options); }
  setAttribute(name: string, value: string): void { this.attrs.set(name, value); }
  addEventListener(name: string, callback: () => void): void { this.events.set(name, [...this.events.get(name) ?? [], callback]); }
  emit(name: string): void { for (const callback of this.events.get(name) ?? []) callback(); }
  all(): Element[] { return [this, ...this.children.flatMap(child => child.all())]; }
}

class Control {
  label = "";
  value = "";
  disabled = false;
  click: () => unknown = () => {};
  change: (value: string) => void = () => {};
  setButtonText(value: string): this { this.label = value; return this; }
  setCta(): this { return this; }
  setDisabled(value: boolean): this { this.disabled = value; return this; }
  setValue(value: string): this { this.value = value; return this; }
  setPlaceholder(): this { return this; }
  addOption(): this { return this; }
  onClick(callback: () => unknown): this { this.click = callback; return this; }
  onChange(callback: (value: string) => void): this { this.change = callback; return this; }
}

interface Picker {
  contentEl: Element;
  ask(): Promise<{ scope: string; rules: Record<string, boolean> } | undefined>;
  close(): void;
}
let PickerClass: new (app: unknown, settings: Settings, paths: string[], remote: () => Promise<string[]>) => Picker;
let controls: { buttons: Control[]; dropdowns: Control[]; texts: Control[] };

before(async () => {
  class Modal {
    contentEl = new Element();
    open(): void { (this as unknown as { onOpen(): void }).onOpen(); }
    close(): void { (this as unknown as { onClose(): void }).onClose(); }
  }
  class Setting {
    setName(): this { return this; }
    setDesc(): this { return this; }
    addButton(callback: (button: Control) => void): this { const button = new Control(); controls.buttons.push(button); callback(button); return this; }
    addDropdown(callback: (dropdown: Control) => void): this { const dropdown = new Control(); controls.dropdowns.push(dropdown); callback(dropdown); return this; }
    addText(callback: (text: Control) => void): this { const text = new Control(); controls.texts.push(text); callback(text); return this; }
  }
  const bundle = await build({ entryPoints: [resolve("src/file-picker.ts")], write: false, bundle: true, platform: "browser", format: "cjs", external: ["obsidian"] });
  const module = { exports: {} as { FilePickerModal: typeof PickerClass } };
  runInNewContext(bundle.outputFiles[0].text, { module, exports: module.exports,
    require: () => ({ Modal, Setting, Notice: class {} }) });
  PickerClass = module.exports.FilePickerModal;
});

function fixture(settings = defaults(), remote: () => Promise<string[]> = async () => []) {
  controls = { buttons: [], dropdowns: [], texts: [] };
  const picker = new PickerClass({}, settings, ["工作/a.md", "工作/私密/b.md", "日记.md", "空目录/"], remote);
  const answer = picker.ask();
  const checkbox = (path: string): Element => {
    const element = picker.contentEl.all().find(node => node.attrs.get("aria-label") === path);
    assert(element, path); return element;
  };
  const click = (label: string): unknown => { const button = controls.buttons.find(button => button.label === label); assert(button, label); return button.click(); };
  return { picker, answer, checkbox, click };
}

test("勾选界面：父目录全选、子目录取消、半选和保存", async () => {
  const view = fixture({ ...defaults(), syncScope: "selected" });
  view.checkbox("工作").checked = true; view.checkbox("工作").emit("change");
  assert(view.checkbox("工作/a.md").checked);
  view.checkbox("工作/私密").checked = false; view.checkbox("工作/私密").emit("change");
  assert(view.checkbox("工作").indeterminate);
  assert(!view.checkbox("工作/私密/b.md").checked);
  view.checkbox("空目录").checked = true; view.checkbox("空目录").emit("change");
  view.click("保存选择");
  const answer = await view.answer;
  assert.equal(answer?.scope, "selected");
  assert.equal(answer?.rules["工作"], true);
  assert.equal(answer?.rules["工作/私密"], false);
  assert.equal(answer?.rules["空目录"], true);
});

test("勾选界面：全选和全部取消同步更新范围下拉框", async () => {
  const view = fixture();
  assert(!view.checkbox("工作").disabled);
  view.click("全选当前根目录");
  assert.equal(controls.dropdowns[0].value, "selected");
  assert(!view.checkbox("工作").disabled);
  assert(view.checkbox("工作/a.md").checked);
  view.click("全部取消");
  assert(!view.checkbox("工作/a.md").checked);
  view.click("保存选择");
  assert.equal(Object.keys((await view.answer)!.rules).length, 0);
});

test("全部同步模式可直接取消单项，自动保留其余根目录的选择", async () => {
  const view = fixture();
  const checkbox = view.checkbox("工作/a.md");
  assert.equal(checkbox.disabled, false);
  assert.equal(checkbox.checked, true);
  checkbox.checked = false; checkbox.emit("change");
  assert.equal(controls.dropdowns[0].value, "selected");
  assert.equal(view.checkbox("工作/a.md").checked, false);
  assert.equal(view.checkbox("工作/私密/b.md").checked, true);
  assert.equal(view.checkbox("日记.md").checked, true);
  view.click("保存选择");
  const answer = await view.answer;
  assert.equal(answer?.rules["工作"], true);
  assert.equal(answer?.rules["工作/a.md"], false);
});

test("全选后取消勾选不重建目录，保留勾选框节点和滚动位置", async () => {
  const view = fixture();
  view.click("全选当前根目录");
  const tree = view.picker.contentEl.all().find(node => node.className === "gvs-file-tree")!;
  tree.scrollTop = 360;
  view.picker.contentEl.scrollTop = 120;
  const checkbox = view.checkbox("工作/私密/b.md");
  const root = view.checkbox("工作");
  const folder = tree.all().find(node => node.tag === "details" && node.children[0]?.children.some(child => child.attrs.get("aria-label") === "工作"))!;
  folder.open = true; folder.emit("toggle");
  checkbox.checked = false; checkbox.emit("change");
  assert.equal(view.checkbox("工作/私密/b.md"), checkbox);
  assert.equal(view.checkbox("工作"), root);
  assert.equal(tree.scrollTop, 360);
  assert.equal(view.picker.contentEl.scrollTop, 120);
  assert.equal(checkbox.checked, false);
  assert.equal(root.indeterminate, true);
  assert.equal(folder.open, true);
  assert(tree.all().includes(folder));
  checkbox.checked = true; checkbox.emit("change");
  assert.equal(view.checkbox("工作/私密/b.md"), checkbox);
  assert.equal(checkbox.checked, true);
  assert.equal(root.indeterminate, false);
  assert.equal(tree.scrollTop, 360);
  view.click("取消"); await view.answer;
});

test("批量全选、取消和范围切换只更新勾选状态，不改变树节点", async () => {
  const view = fixture();
  const tree = view.picker.contentEl.all().find(node => node.className === "gvs-file-tree")!;
  const checkbox = view.checkbox("工作/a.md");
  tree.scrollTop = 210;
  view.click("全部取消");
  assert.equal(view.checkbox("工作/a.md"), checkbox);
  assert.equal(checkbox.checked, false);
  view.click("全选当前根目录");
  assert.equal(view.checkbox("工作/a.md"), checkbox);
  assert.equal(checkbox.checked, true);
  controls.dropdowns[0].change("all");
  assert.equal(view.checkbox("工作/a.md"), checkbox);
  assert.equal(checkbox.disabled, false);
  assert.equal(tree.scrollTop, 210);
  view.click("取消"); await view.answer;
});

test("勾选界面：远程独有目录可读取并勾选，不写入内容", async () => {
  let reads = 0;
  const view = fixture({ ...defaults(), syncScope: "selected" }, async () => { reads++; return ["远程/恢复.md"]; });
  await view.click("载入远程列表");
  view.checkbox("远程").checked = true; view.checkbox("远程").emit("change");
  view.click("保存选择");
  assert.equal((await view.answer)?.rules["远程"], true);
  assert.equal(reads, 1);
});

test("勾选界面：搜索不改变规则，取消不修改原设置", async () => {
  const settings = { ...defaults(), syncScope: "selected" as const, selection: { "工作": true } };
  const view = fixture(settings);
  controls.texts[0].change("日记");
  assert(!view.picker.contentEl.all().some(node => node.attrs.get("aria-label") === "工作"));
  view.click("全部取消");
  view.click("取消");
  assert.equal(await view.answer, undefined);
  assert.equal(settings.selection["工作"], true);
});

test("关闭选择窗口时等待正在进行的远程读取收尾，避免后台请求链残留", async () => {
  let finish!: (paths: string[]) => void;
  const pending = new Promise<string[]>(resolve => { finish = resolve; });
  const view = fixture(defaults(), () => pending);
  const loading = view.click("载入远程列表");
  let answered = false;
  void view.answer.then(() => { answered = true; });
  view.click("取消");
  await Promise.resolve();
  assert.equal(answered, false);
  finish(["remote.md"]);
  await loading;
  assert.equal(await view.answer, undefined);
});
