import assert from "node:assert/strict";
import test from "node:test";
import { describeApiError, GitHubApiError, redact } from "../src/api-error";
import { RequestControl } from "../src/request-control";

const now = Date.parse("2026-10-23T00:00:00Z");

test("403 权限不足与限流分开诊断，并保留所需权限", () => {
  const error = describeApiError({ status: 403, json: { message: "Resource not accessible by personal access token" },
    headers: { "X-Accepted-GitHub-Permissions": "contents=write", "X-RateLimit-Remaining": "4900" } }, "POST", "/git/blobs", "token", now);
  assert.match(error.message, /上传文件失败.*HTTP 403/);
  assert.match(error.message, /无权/);
  assert.doesNotMatch(error.message, /限流/);
  assert.match(error.details, /contents=write/);
  assert.equal(error.retryAt, 0);
});

test("主限流支持不同大小写的响应头并报告恢复时间", () => {
  const reset = Math.floor(now / 1000) + 600;
  const error = describeApiError({ status: 403, json: { message: "API rate limit exceeded" }, headers: {
    "X-RateLimit-Remaining": "0", "X-RateLimit-Reset": String(reset), "X-RateLimit-Limit": "60", "X-GitHub-Request-Id": "ABCD:1234"
  } }, "GET", "", "token", now);
  assert.match(error.message, /请求额度已用尽/);
  assert.equal(error.retryAt, reset * 1000 + 1000);
  assert.match(error.details, /认证是否生效/);
  assert.match(error.details, /ABCD:1234/);
});

test("次级限流遵守 Retry-After，不使用尚未耗尽的主额度时间", () => {
  const error = describeApiError({ status: 403, json: { message: "You have exceeded a secondary rate limit" }, headers: {
    "Retry-After": "120", "X-RateLimit-Remaining": "4990", "X-RateLimit-Reset": String(now / 1000 + 3600)
  } }, "POST", "/git/trees", "token", now);
  assert.match(error.message, /次级限流/);
  assert.equal(error.retryAt, now + 121000);
});

test("主额度耗尽和 Retry-After 同时存在时等待较晚的期限", () => {
  const error = describeApiError({ status: 429, json: {}, headers: {
    "retry-after": "10", "x-ratelimit-remaining": "0", "x-ratelimit-reset": String(now / 1000 + 300)
  } }, "POST", "/git/blobs", "token", now);
  assert.equal(error.retryAt, now + 301000);
});

test("没有有效恢复响应头的 429 至少冷却一分钟", () => {
  for (const retryAfter of [undefined, "invalid", "-20", "Infinity"]) {
    const error = describeApiError({ status: 429, json: {}, headers: retryAfter ? { "retry-after": retryAfter } : {} }, "GET", "", "token", now);
    assert.equal(error.retryAt, now + 60000);
  }
});

test("Retry-After 的 HTTP 日期格式也可解析", () => {
  const error = describeApiError({ status: 429, json: {}, headers: { "retry-after": new Date(now + 180000).toUTCString() } }, "GET", "", "token", now);
  assert.equal(error.retryAt, now + 181000);
});

test("SSO、IP 允许列表和未知 403 不误报为 Token 权限不足", () => {
  const sso = describeApiError({ status: 403, json: {}, headers: { "X-GitHub-SSO": "required; url=https://private.invalid/?secret=value" } }, "GET", "", "token", now);
  assert.match(sso.message, /SSO/);
  assert.doesNotMatch(sso.details, /secret=value/);
  const blockedIp = describeApiError({ status: 403, json: { message: "Your IP address is not on the IP allow list" }, headers: {} }, "GET", "", "token", now);
  assert.match(blockedIp.message, /网络出口 IP/);
  const unknown = describeApiError({ status: 403, json: { message: "Request forbidden by policy" }, headers: {} }, "GET", "", "token", now);
  assert.match(unknown.message, /未明确/);
  assert.equal(unknown.retryAt, 0);
});

test("非 JSON 响应也可识别 User-Agent 缺失", () => {
  const error = describeApiError({ status: 403, json: {}, text: "<p>Please make sure your request has a User-Agent header</p>", headers: {} }, "GET", "", "token", now);
  assert.match(error.message, /User-Agent/);
  assert.doesNotMatch(error.details, /<p>/);
});

test("诊断脱敏且不复制任意响应头或 JSON 字段", () => {
  const secret = "my-secret-for-this-test";
  const error = describeApiError({ status: 403, json: {
    message: `${secret} github_pat_ABCDEF123 ghp_SECONDARY123 Bearer other-secret`, content: "private-note-content"
  }, headers: { Authorization: "Bearer excluded-secret", "x-github-request-id": secret } }, "GET", "", secret, now);
  for (const sensitive of [secret, "github_pat_ABCDEF123", "ghp_SECONDARY123", "other-secret", "private-note-content", "excluded-secret"]) {
    assert(!error.details.includes(sensitive));
  }
  assert.match(error.details, /已隐藏/);
  assert.equal(redact("plain text", ""), "plain text");
});

test("写请求间隔至少 1.1 秒，读取不额外延时", async () => {
  let clock = now;
  const waits: number[] = [];
  const requests = new RequestControl(() => clock, async milliseconds => { waits.push(milliseconds); clock += milliseconds; });
  await requests.before("POST");
  await requests.before("GET");
  assert.deepEqual(waits, []);
  clock += 100;
  await requests.before("PATCH");
  await requests.before("PUT");
  assert.deepEqual(waits, [1000, 1100]);
});

test("冷却中禁止发请求，到期后允许请求但不自动重放写操作", async () => {
  let clock = now;
  const requests = new RequestControl(() => clock);
  const error = new GitHubApiError("limited", "safe detail", now + 60000);
  requests.hold(error);
  assert(requests.coolingDown);
  await assert.rejects(requests.before("GET"), /limited/);
  await assert.rejects(requests.before("POST"), /limited/);
  clock = now + 60001;
  assert(!requests.coolingDown);
  await requests.before("GET");
});
