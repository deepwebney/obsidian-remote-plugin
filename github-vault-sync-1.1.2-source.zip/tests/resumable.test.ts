import assert from "node:assert/strict";
import test from "node:test";
import { SyncEngine } from "../src/engine";
import { SyncStoppedError } from "../src/cancellation";
import { GitHubApiError } from "../src/api-error";
import { RequestControl } from "../src/request-control";
import { GitHub, type HttpResponse } from "../src/github";
import { PathPolicy } from "../src/policy";
import { defaults } from "../src/types";
import { fromBase64, toBase64 } from "../src/hash";
import { gitHash } from "../src/hash";
import type { CommitRecovery, CommitState, LocalStore, RemoteSnapshot, RemoteStore, Snapshot, TransferProgress } from "../src/types";

const bytes = (text: string): Uint8Array => new TextEncoder().encode(text);
const text = (value?: Uint8Array): string => new TextDecoder().decode(value);
const clone = <Value>(value: Value): Value => JSON.parse(JSON.stringify(value)) as Value;

class Disk implements LocalStore {
  files = new Map<string, Uint8Array>();
  staged = new Map<string, Uint8Array>();
  backups = new Map<string, Uint8Array>();
  failWrite?: string;
  writes = 0;
  constructor(files: Record<string, string> = {}) { for (const [path, value] of Object.entries(files)) this.files.set(path, bytes(value)); }
  async scan(): Promise<Snapshot> { return Object.fromEntries([...this.files].map(([path, value]) => [path, gitHash(value)])); }
  async read(path: string): Promise<Uint8Array> { const value = this.files.get(path); if (!value) throw new Error("missing file"); return value; }
  async hash(path: string): Promise<string | undefined> { const value = this.files.get(path); return value ? gitHash(value) : undefined; }
  async write(path: string, value: Uint8Array): Promise<void> { if (this.failWrite === path) throw new Error("disk full"); this.files.set(path, value); this.writes++; }
  async remove(path: string): Promise<void> { this.files.delete(path); this.writes++; }
  async backup(path: string, value: Uint8Array, run: string): Promise<void> { this.backups.set(`${run}/${path}`, value); }
  async stage(path: string, value: Uint8Array, run: string): Promise<void> { this.staged.set(`${run}/${path}`, value); }
  async readStaged(path: string, run: string): Promise<Uint8Array> { const value = this.staged.get(`${run}/${path}`); if (!value) throw new Error("missing stage"); return value; }
  async stagedHash(path: string, run: string): Promise<string | undefined> { const value = this.staged.get(`${run}/${path}`); return value ? gitHash(value) : undefined; }
  async readBackup(path: string, run: string): Promise<Uint8Array> { const value = this.backups.get(`${run}/${path}`); if (!value) throw new Error("missing backup"); return value; }
  async cleanupStage(): Promise<void> { this.staged.clear(); }
}

class Server implements RemoteStore {
  head = "head-0";
  files: Snapshot = Object.create(null);
  blobs = new Map<string, Uint8Array>();
  uploads = 0;
  downloads = 0;
  checks = 0;
  commits = 0;
  reconciles = 0;
  afterUpload?: () => void;
  afterCommit?: () => void;
  loseCommitResponse = false;
  cannotRead = false;
  constructor(files: Record<string, string> = {}) {
    for (const [path, value] of Object.entries(files)) this.put(path, bytes(value));
  }
  put(path: string, value: Uint8Array): void { const sha = gitHash(value); this.blobs.set(sha, value); this.files[path] = sha; }
  async snapshot(): Promise<RemoteSnapshot> {
    if (this.cannotRead) throw new Error("offline");
    return { head: this.head, tree: "tree", files: { ...this.files }, sizes: {} };
  }
  async assertHead(head: string): Promise<void> { assert.equal(this.head, head, "remote moved"); }
  async upload(value: Uint8Array): Promise<string> {
    this.uploads++;
    const sha = gitHash(value); this.blobs.set(sha, value); this.afterUpload?.(); return sha;
  }
  async download(sha: string): Promise<Uint8Array> { this.downloads++; const value = this.blobs.get(sha); if (!value) throw new Error("missing blob"); return value; }
  async verifyBlob(sha: string, size: number): Promise<boolean> { this.checks++; return this.blobs.get(sha)?.length === size; }
  async reconcile(state: CommitState): Promise<"confirmed" | "ready" | "moved"> {
    this.reconciles++;
    if (this.cannotRead) throw new Error("offline");
    if (this.head === state.commitSha) return "confirmed";
    return this.head === state.baseHead && state.phase !== "confirmed" ? "ready" : "moved";
  }
  async commit(snapshot: RemoteSnapshot, changes: Record<string, string | null>, _message: string, recovery?: CommitRecovery): Promise<string> {
    await this.assertHead(snapshot.head);
    if (!Object.keys(changes).length) return this.head;
    const sha = `head-${this.commits + 1}`;
    if (recovery) { recovery.state.commitSha = sha; recovery.state.phase = "updating"; await recovery.save(); }
    this.commits++;
    for (const [path, value] of Object.entries(changes)) { if (value === null) delete this.files[path]; else this.files[path] = value; }
    this.head = sha;
    this.afterCommit?.();
    if (this.loseCommitResponse) { this.loseCommitResponse = false; throw new Error("lost PATCH response"); }
    if (recovery) { recovery.state.phase = "confirmed"; await recovery.save(); }
    return sha;
  }
}

class Session {
  state?: TransferProgress;
  baseline: Snapshot = {};
  stopped = false;
  onCheckpoint?: () => void;
  retry?: (error: unknown, attempt: number) => Promise<boolean>;
  constructor(readonly disk: Disk, readonly server: Server, readonly batchSize = 2) {}
  engine(): SyncEngine {
    return new SyncEngine(this.disk, this.server, () => {}, {
      target: "repo-and-scope", state: this.state ? clone(this.state) : undefined, batchSize: this.batchSize,
      retry: (error, attempt) => this.retry?.(error, attempt) ?? Promise.resolve(false),
      check: () => { if (this.stopped) throw new SyncStoppedError(); },
      checkpoint: async (state, baseline) => {
        this.state = state ? clone(state) : undefined;
        this.baseline = clone(baseline);
        this.onCheckpoint?.();
      }
    });
  }
  async run(mode: "sync" | "restore" = "sync"): Promise<void> {
    const engine = this.engine();
    await engine.execute(await engine.prepare(this.baseline, mode, false), this.baseline, "test-device");
  }
}

function enableRetries(session: Session): string[] {
  let clock = Date.now();
  const messages: string[] = [];
  const requests = new RequestControl(() => clock, async delay => { clock += delay; });
  session.retry = (error, attempt) => requests.retry(error, attempt,
    () => { if (session.stopped) throw new SyncStoppedError(); }, message => messages.push(message));
  return messages;
}

const manyFiles = (): Record<string, string> => Object.fromEntries(Array.from({ length: 45 }, (_, index) =>
  [`note-${String(index).padStart(2, "0")}.md`, `content-${index}`]));

test("45 个文件一次启动自动完成三批，不在第 20 或 40 项停止", async () => {
  const session = new Session(new Disk(manyFiles()), new Server(), 20);
  const completed = new Set<number>();
  session.onCheckpoint = () => { if (session.state) completed.add(session.state.nextIndex); };
  await session.run();
  assert.deepEqual([...completed], [0, 20, 40, 45]);
  assert.equal(session.server.commits, 3);
  assert.equal(session.server.uploads, 45);
  assert.equal(session.state, undefined);
});

test("第 20 项上传响应丢失：本次自动核验复用并连续完成全部批次", async () => {
  const session = new Session(new Disk(manyFiles()), new Server(), 20);
  const messages = enableRetries(session);
  let failed = false;
  session.server.afterUpload = () => {
    if (session.server.uploads === 20 && !failed) {
      failed = true;
      throw new GitHubApiError("网络中断", "lost blob response", 0, 503);
    }
  };
  await session.run();
  assert.equal(session.server.uploads, 45);
  assert.equal(session.server.checks, 1);
  assert.equal(session.server.commits, 3);
  assert.equal(session.state, undefined);
  assert(messages.some(message => message.includes("自动重试")));
});

test("每批提交后响应丢失：自动先核对远端，不重复提交且重试额度按批重置", async () => {
  const session = new Session(new Disk(manyFiles()), new Server(), 10);
  enableRetries(session);
  session.server.afterCommit = () => { throw new GitHubApiError("网络中断", "lost PATCH response", 0, 503); };
  await session.run();
  assert.equal(session.server.commits, 5);
  assert.equal(session.server.uploads, 45);
  assert.equal(session.state, undefined);
  assert(session.server.reconciles >= 5);
});

test("连续失败有限重试后保留前 20 项进度，手动继续不重复上传", async () => {
  const session = new Session(new Disk(manyFiles()), new Server(), 20);
  enableRetries(session);
  let attempts = 0;
  session.server.assertHead = async head => {
    assert.equal(session.server.head, head);
    if (session.server.commits === 1) {
      attempts++;
      throw new GitHubApiError("服务器暂不可用", "HTTP 503", 0, 503);
    }
  };
  await assert.rejects(session.run(), /自动重试.*3.*继续上次任务/);
  assert.equal(attempts, 4);
  assert.equal(session.state?.nextIndex, 20);
  assert.equal(session.server.uploads, 20);
  session.server.assertHead = async head => { assert.equal(session.server.head, head); };
  await session.run();
  assert.equal(session.server.uploads, 45);
  assert.equal(session.server.commits, 3);
});

test("权限错误不重试，已完成批次仍保留", async () => {
  const session = new Session(new Disk(manyFiles()), new Server(), 20);
  const messages = enableRetries(session);
  session.server.afterUpload = () => {
    if (session.server.uploads === 21) throw new GitHubApiError("无权访问", "contents=write", 0, 403);
  };
  await assert.rejects(session.run(), /无权访问/);
  assert.equal(messages.length, 0);
  assert.equal(session.state?.nextIndex, 20);
});

test("启用自动重试后主动停止仍立即结束，保留批次供手动继续", async () => {
  const session = new Session(new Disk(manyFiles()), new Server(), 20);
  const messages = enableRetries(session);
  session.onCheckpoint = () => { if (session.state?.nextIndex === 20) session.stopped = true; };
  await assert.rejects(session.run(), SyncStoppedError);
  assert.equal(session.server.uploads, 20);
  assert.equal(messages.length, 0);
  session.stopped = false;
  session.onCheckpoint = undefined;
  await session.run();
  assert.equal(session.server.uploads, 45);
});

test("等待重试时远端被其他设备修改，停止旧计划而不重复提交", async () => {
  const session = new Session(new Disk(manyFiles()), new Server(), 20);
  enableRetries(session);
  session.server.afterCommit = () => {
    session.server.head = "other-device";
    throw new GitHubApiError("响应丢失", "PATCH failed", 0, 503);
  };
  await assert.rejects(session.run(), /旧批次不会重放/);
  assert.equal(session.server.commits, 1);
  assert.equal(session.server.uploads, 20);
  assert(session.state?.batch);
});

test("最终校验短暂失败也自动恢复，不重传已完成批次", async () => {
  const session = new Session(new Disk(manyFiles()), new Server(), 20);
  enableRetries(session);
  const snapshot = session.server.snapshot.bind(session.server);
  let failed = false;
  session.server.snapshot = async () => {
    if (session.state?.nextIndex === 45 && !failed) {
      failed = true;
      throw new GitHubApiError("临时服务错误", "503", 0, 503);
    }
    return snapshot();
  };
  await session.run();
  assert(failed);
  assert.equal(session.server.commits, 3);
  assert.equal(session.server.uploads, 45);
  assert.equal(session.state, undefined);
});

test("真实 GitHub 客户端连续三批：blob 响应丢失、建树 503、分支响应丢失均安全自动恢复", async () => {
  const disk = new Disk(manyFiles());
  const settings = { ...defaults(), owner: "owner", repo: "vault" };
  const blobs = new Map<string, Uint8Array>();
  const trees = new Map<string, Snapshot>([["tree-0", {}]]);
  const commits = new Map<string, string>([["head-0", "tree-0"]]);
  const calls: string[] = [];
  let head = "head-0";
  let uploads = 0;
  let patches = 0;
  let treeFailed = false;
  let clock = Date.now();
  const control = new RequestControl(() => clock, async delay => { clock += delay; });
  const ok = (json: unknown): HttpResponse => ({ status: 200, json, headers: {} });
  const github = new GitHub(settings, "secret", new PathPolicy(settings, ".obsidian"), async (method, url, _headers, body) => {
    const path = new URL(url).pathname.replace("/repos/owner/vault", "");
    calls.push(`${method} ${path}`);
    if (path.startsWith("/git/ref/")) return ok({ object: { sha: head } });
    if (method === "GET" && path.startsWith("/git/commits/")) return ok({ tree: { sha: commits.get(path.split("/").at(-1)!) } });
    if (method === "GET" && path.startsWith("/git/trees/")) {
      const files = trees.get(path.split("/").at(-1)!)!;
      return ok({ truncated: false, tree: Object.entries(files).map(([path, sha]) =>
        ({ path, sha, type: "blob", mode: "100644", size: blobs.get(sha)!.length })) });
    }
    if (method === "GET" && path.startsWith("/git/blobs/")) {
      const sha = path.split("/").at(-1)!;
      const value = blobs.get(sha)!;
      return ok({ sha, content: toBase64(value), size: value.length, encoding: "base64" });
    }
    if (path === "/git/blobs") {
      const value = fromBase64((JSON.parse(body!) as { content: string }).content);
      const sha = gitHash(value);
      blobs.set(sha, value);
      uploads++;
      if (uploads === 20) throw new Error("blob accepted but response lost");
      return ok({ sha });
    }
    if (path === "/git/trees") {
      if (!treeFailed) {
        treeFailed = true;
        return { status: 503, json: { message: "temporarily unavailable" }, headers: {} };
      }
      const data = JSON.parse(body!) as { base_tree: string; tree: { path: string; sha: string }[] };
      const files = { ...trees.get(data.base_tree) };
      for (const entry of data.tree) files[entry.path] = entry.sha;
      const sha = `tree-${trees.size}`;
      trees.set(sha, files);
      return ok({ sha });
    }
    if (path === "/git/commits") {
      const data = JSON.parse(body!) as { tree: string; parents: string[] };
      assert.deepEqual(data.parents, [head]);
      const sha = `head-${commits.size}`;
      commits.set(sha, data.tree);
      return ok({ sha });
    }
    if (method === "PATCH") {
      const data = JSON.parse(body!) as { sha: string; force: boolean };
      assert.equal(data.force, false);
      head = data.sha;
      patches++;
      if (patches === 1) throw new Error("branch updated but response lost");
      return ok({});
    }
    throw new Error(`unexpected request: ${method} ${path}`);
  }, control);
  let saved: TransferProgress | undefined;
  const completed = new Set<number>();
  const engine = new SyncEngine(disk, github, () => {}, {
    batchSize: 20, retry: (error, attempt) => control.retry(error, attempt),
    checkpoint: async state => { saved = state ? clone(state) : undefined; if (saved) completed.add(saved.nextIndex); }
  });
  await engine.execute(await engine.prepare({}, "sync", false), {}, "test-device");
  assert.deepEqual([...completed], [0, 20, 40, 45]);
  assert.equal(uploads, 45);
  assert.equal(patches, 3);
  assert.equal(commits.size, 4);
  assert.equal(Object.keys(trees.get(commits.get(head)!)!).length, 45);
  assert.equal(saved, undefined);
  const firstPatch = calls.findIndex(call => call.startsWith("PATCH"));
  assert.match(calls[firstPatch + 1], /^GET \/git\/ref\//);
  assert(calls.some(call => call.startsWith("GET /git/blobs/")));
});

test("分批提交完成一批即持久化；重启后不重复已完成批次", async () => {
  const session = new Session(new Disk({ "a.md": "a", "b.md": "b", "c.md": "c", "d.md": "d", "e.md": "e" }), new Server());
  session.onCheckpoint = () => { if (session.state?.nextIndex === 2) session.stopped = true; };
  await assert.rejects(session.run(), /已停止/);
  assert.equal(session.server.commits, 1);
  assert.equal(session.server.uploads, 2);
  assert.equal(session.state?.nextIndex, 2);
  assert.equal(Object.keys(session.baseline).length, 2);
  session.stopped = false; session.onCheckpoint = undefined;
  await session.run();
  assert.equal(session.server.commits, 3);
  assert.equal(session.server.uploads, 5);
  assert.equal(session.state, undefined);
});

test("上传后停止，下一次校验并复用 GitHub blob", async () => {
  const session = new Session(new Disk({ "a.md": "a", "b.md": "b" }), new Server());
  session.server.afterUpload = () => { session.stopped = true; };
  await assert.rejects(session.run(), /已停止/);
  assert.equal(session.server.uploads, 1);
  assert.equal(session.server.commits, 0);
  assert.equal(Object.keys(session.state!.uploaded).length, 1);
  session.stopped = false; session.server.afterUpload = undefined;
  await session.run();
  assert.equal(session.server.checks, 1);
  assert.equal(session.server.uploads, 2);
});

test("上传返回丢失也保存了候选 SHA，下次验证存在后跳过上传", async () => {
  const session = new Session(new Disk({ "a.md": "a" }), new Server());
  session.server.afterUpload = () => { throw new Error("lost blob response"); };
  await assert.rejects(session.run(), /lost blob/);
  session.server.afterUpload = undefined;
  await session.run();
  assert.equal(session.server.uploads, 1);
  assert.equal(session.server.checks, 1);
});

test("缓存对象已被清理时只重新上传缺失对象", async () => {
  const session = new Session(new Disk({ "a.md": "a", "b.md": "b" }), new Server());
  session.server.afterUpload = () => { if (session.server.uploads === 2) session.stopped = true; };
  await assert.rejects(session.run(), /已停止/);
  session.server.blobs.delete(gitHash(bytes("b")));
  session.stopped = false; session.server.afterUpload = undefined;
  await session.run();
  assert.equal(session.server.checks, 2);
  assert.equal(session.server.uploads, 3);
});

test("PATCH 已成功但响应丢失，恢复先核对，不重复提交", async () => {
  const session = new Session(new Disk({ "a.md": "a" }), new Server());
  session.server.loseCommitResponse = true;
  await assert.rejects(session.run(), /lost PATCH/);
  assert.equal(session.state?.batch?.transaction.phase, "updating");
  await session.run();
  assert(session.server.reconciles >= 1);
  assert.equal(session.server.commits, 1);
  assert.equal(session.server.uploads, 1);
});

test("停止发生在分支更新过程中：保存确认结果，下次不重复提交", async () => {
  const session = new Session(new Disk({ "a.md": "a" }), new Server());
  session.server.afterCommit = () => { session.stopped = true; };
  await assert.rejects(session.run(), /已停止/);
  assert.equal(session.state?.batch?.transaction.phase, "confirmed");
  session.server.afterCommit = undefined; session.stopped = false;
  await session.run();
  assert.equal(session.server.commits, 1);
});

test("本地应用中断后复用已下载文件，并保留原始冲突备份", async () => {
  const session = new Session(new Disk({ "a.md": "local" }), new Server({ "a.md": "remote" }));
  session.disk.failWrite = "a.md";
  await assert.rejects(session.run(), /disk full/);
  const copy = session.state!.plan!.actions[0].copyPath!;
  assert.equal(text(session.disk.files.get(copy)), "local");
  assert.equal(text([...session.disk.backups.values()][0]), "local");
  session.disk.failWrite = undefined;
  await session.run();
  assert.equal(session.server.downloads, 1);
  assert.equal(session.server.commits, 1);
  assert.equal(text(session.disk.files.get("a.md")), "remote");
  assert.equal([...session.disk.files.keys()].filter(path => path.includes(".conflict-")).length, 1);
});

test("仅下载恢复也按批保存进度，恢复不写远程", async () => {
  const session = new Session(new Disk(), new Server({ "a.md": "a", "b.md": "b", "c.md": "c" }));
  session.onCheckpoint = () => { if (session.state?.nextIndex === 2) session.stopped = true; };
  await assert.rejects(session.run("restore"), /已停止/);
  session.onCheckpoint = undefined; session.stopped = false;
  await session.run("restore");
  assert.equal(session.server.commits, 0);
  assert.equal(session.server.downloads, 3);
  assert.equal(session.disk.files.size, 3);
});

test("中断后本机独立修改：拒绝旧计划，安全重规划保留新内容", async () => {
  const session = new Session(new Disk({ "a.md": "old", "b.md": "b" }), new Server());
  session.server.afterUpload = () => { session.stopped = true; };
  await assert.rejects(session.run(), /已停止/);
  session.server.afterUpload = undefined; session.stopped = false;
  session.disk.files.set("a.md", bytes("edited-after-stop"));
  await assert.rejects(session.run(), /安全重新规划/);
  await session.engine().replan(session.baseline);
  assert(!session.state?.plan);
  assert(Object.keys(session.state!.uploaded).length > 0);
  await session.run();
  assert.equal(text(session.server.blobs.get(session.server.files["a.md"])), "edited-after-stop");
});

test("无法核对不确定提交时不得清除断点或写远程", async () => {
  const session = new Session(new Disk({ "a.md": "a" }), new Server());
  session.server.loseCommitResponse = true;
  await assert.rejects(session.run(), /lost PATCH/);
  const before = clone(session.state);
  session.server.cannotRead = true;
  await assert.rejects(session.engine().replan(session.baseline), /offline/);
  assert.deepEqual(session.state, before);
  assert.equal(session.server.commits, 1);
});

test("远程又有修改时，不应用已过期的下载内容", async () => {
  const session = new Session(new Disk({ "a.md": "local" }), new Server({ "a.md": "remote" }));
  session.server.afterCommit = () => { session.server.put("a.md", bytes("new-remote")); };
  await assert.rejects(session.run(), /远程又发生变化/);
  assert.equal(text(session.disk.files.get("a.md")), "local");
  assert(session.state?.batch);
});

test("已确认批次的下载暂存损坏可重新获取，不重复上传提交", async () => {
  const session = new Session(new Disk({ "a.md": "local" }), new Server({ "a.md": "remote" }));
  session.disk.failWrite = "a.md";
  await assert.rejects(session.run(), /disk full/);
  session.disk.staged.clear();
  session.disk.failWrite = undefined;
  await session.run();
  assert.equal(session.server.commits, 1);
  assert.equal(session.server.downloads, 2);
  assert.equal(text(session.disk.files.get("a.md")), "remote");
});

test("新内容相同的不同文件在批次内仅上传一个 blob", async () => {
  const session = new Session(new Disk({ "a.md": "same", "b.md": "same" }), new Server());
  await session.run();
  assert.equal(session.server.uploads, 1);
  assert.equal(Object.keys(session.server.files).length, 2);
});

test("确认远程提交后 checkpoint 失败，重启仍从 write-ahead 日志恢复", async () => {
  const session = new Session(new Disk({ "a.md": "a" }), new Server());
  let failed = false;
  session.onCheckpoint = () => {
    if (!failed && session.state?.batch?.transaction.phase === "confirmed") {
      failed = true;
      session.state.batch.transaction.phase = "updating";
      throw new Error("save failed");
    }
  };
  await assert.rejects(session.run(), /save failed/);
  session.onCheckpoint = undefined;
  await session.run();
  assert.equal(session.server.commits, 1);
  assert.equal(session.server.uploads, 1);
});

test("JSON 断点恢复支持 constructor 等正常文件名", async () => {
  const session = new Session(new Disk({ constructor: "note" }), new Server());
  session.server.afterUpload = () => { session.stopped = true; };
  await assert.rejects(session.run(), /已停止/);
  session.server.afterUpload = undefined; session.stopped = false;
  await session.run();
  assert.equal(session.server.uploads, 1);
  assert.equal(session.server.files.constructor, gitHash(bytes("note")));
});
