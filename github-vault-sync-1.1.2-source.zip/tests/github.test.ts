import assert from "node:assert/strict";
import test from "node:test";
import { GitHub, type HttpResponse, type Transport } from "../src/github";
import { gitHash, toBase64 } from "../src/hash";
import { PathPolicy } from "../src/policy";
import { defaults, MAX_FILE_BYTES } from "../src/types";
import { RequestControl } from "../src/request-control";

const settings = { ...defaults(), owner: "test-owner", repo: "vault", branch: "sync/notes" };
const ok = (json: unknown): HttpResponse => ({ status: 200, json, headers: {} });
const client = (transport: Transport): GitHub => new GitHub(settings, "secret-test-token", new PathPolicy(settings, ".obsidian"), transport);
const entry = (path = "note.md"): Record<string, unknown> => ({ path, type: "blob", mode: "100644", sha: "blob-sha", size: 12 });
const snapshotTransport = (entries: unknown[], truncated = false): Transport => async (_, url) => {
  if (url.includes("/git/ref/")) return ok({ object: { sha: "head" } });
  if (url.includes("/git/commits/")) return ok({ tree: { sha: "tree" } });
  return ok({ tree: entries, truncated });
};

test("读取分支、文件树并过滤本机私有数据", async () => {
  const remote = await client(snapshotTransport([entry(), entry(".obsidian/plugins/github-vault-sync/data.json"), entry(".env"), entry(".obsidian/app.json")])).snapshot();
  assert.deepEqual(Object.keys(remote.files), ["note.md", ".obsidian/app.json"]);
  assert.equal(remote.head, "head");
});

test("拒绝截断的 GitHub 文件树", async () => {
  await assert.rejects(client(snapshotTransport([entry()], true)).snapshot(), /截断/);
});

test("拒绝符号链接、子模块、超大文件、不安全路径", async () => {
  for (const malformed of [{ ...entry(), mode: "120000" }, { ...entry(), type: "commit", mode: "160000" },
    { ...entry(), size: MAX_FILE_BYTES + 1 }, entry("../outside.md"), { ...entry(), size: undefined }]) {
    await assert.rejects(client(snapshotTransport([malformed])).snapshot());
  }
});

test("GitHub 提交使用 base_tree、单父提交和 force:false", async () => {
  const calls: { method: string; url: string; body: Record<string, unknown> }[] = [];
  const github = client(async (method, url, headers, body) => {
    assert.equal(headers.Authorization, "Bearer secret-test-token");
    assert.equal(headers["User-Agent"], "GitHub-Vault-Sync/1.1.2");
    calls.push({ method, url, body: body ? JSON.parse(body) : {} });
    if (url.includes("/git/ref/")) return ok({ object: { sha: "head" } });
    if (url.endsWith("/git/trees")) return ok({ sha: "new-tree" });
    if (url.endsWith("/git/commits")) return ok({ sha: "new-commit" });
    return ok({});
  });
  await github.commit({ head: "head", tree: "existing-tree", files: {}, sizes: {} }, { "note.md": "sha", "deleted.md": null }, "sync");
  assert.equal(calls[1].body.base_tree, "existing-tree");
  assert.deepEqual(calls[2].body.parents, ["head"]);
  assert.deepEqual(calls[3].body, { sha: "new-commit", force: false });
  assert(calls[3].url.endsWith("/git/refs/heads/sync/notes"));
  assert.equal(calls.filter(call => call.method === "PATCH").length, 1);
});

test("分支在提交前已变化时禁止写请求", async () => {
  const methods: string[] = [];
  const github = client(async method => { methods.push(method); return ok({ object: { sha: "moved" } }); });
  await assert.rejects(github.commit({ head: "old", tree: "tree", files: {}, sizes: {} }, { "a.md": "sha" }, "test"), /更新/);
  assert.deepEqual(methods, ["GET"]);
});

test("下载和上传均校验 Git blob SHA", async () => {
  const bytes = new Uint8Array([0, 1, 255, 200]);
  const sha = gitHash(bytes);
  const github = client(async method => method === "GET" ? ok({ sha, size: bytes.length, encoding: "base64", content: toBase64(bytes) }) : ok({ sha }));
  assert.deepEqual(await github.download(sha), bytes);
  assert.equal(await github.upload(bytes), sha);
  await assert.rejects(github.download("wrong-sha"), /校验失败/);
  await assert.rejects(client(async () => ok({ sha: "wrong" })).upload(bytes), /校验失败/);
});

test("错误消息不泄露 Token 或 GitHub 响应正文", async () => {
  for (const status of [401, 403, 404, 409, 422, 429, 500]) {
    const github = client(async () => ({ status, json: { message: "secret-test-token" }, headers: {} }));
    await assert.rejects(github.info(), error => error instanceof Error && !error.message.includes("secret-test-token"));
  }
  await assert.rejects(client(async () => { throw new Error("secret-test-token"); }).info(), /无法连接 GitHub/);
});

test("拒绝网址注入和无效分支名", () => {
  for (const overrides of [{ owner: "../../evil" }, { repo: "repo?x=1" }, { branch: "../main" }, { branch: "main.lock" }, { branch: "main/" }]) {
    assert.throws(() => new GitHub({ ...settings, ...overrides }, "token", new PathPolicy(settings, ".obsidian"), async () => ok({})));
  }
});

test("限流后新建 API 客户端仍沿用冷却状态，不重复请求", async () => {
  let requests = 0;
  const control = new RequestControl();
  const transport: Transport = async () => {
    requests++;
    return { status: 429, json: { message: "Too many requests" }, headers: { "retry-after": "60" } };
  };
  for (let attempt = 0; attempt < 2; attempt++) {
    const github = new GitHub(settings, "secret-test-token", new PathPolicy(settings, ".obsidian"), transport, control);
    await assert.rejects(github.info(), /限流/);
  }
  assert.equal(requests, 1);
});

test("选择文件时只列路径，超大文件不妨碍选择其他文件", async () => {
  const github = client(snapshotTransport([{ ...entry("large.bin"), size: MAX_FILE_BYTES + 1 }, entry("note.md")]));
  assert.deepEqual(Object.keys((await github.snapshot(true)).files), ["large.bin", "note.md"]);
  await assert.rejects(github.snapshot(), /超过 50 MiB/);
});
