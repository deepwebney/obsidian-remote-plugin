import assert from "node:assert/strict";
import { after, before, test } from "node:test";
import { promises as fs, existsSync, statSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { createRequire } from "node:module";
import { runInNewContext } from "node:vm";
import { build } from "esbuild";
import { PathPolicy, PRIVATE_DIR } from "../src/policy";
import { defaults, type LocalStore } from "../src/types";

class MockFile { constructor(readonly path: string) {} }
class MockAdapter {
  constructor(readonly root: string) {}
  getBasePath(): string { return this.root; }
  async exists(path: string): Promise<boolean> { return existsSync(join(this.root, path)); }
  async stat(path: string): Promise<{ type: string; size: number } | null> {
    try { const stat = await fs.stat(join(this.root, path)); return { type: stat.isDirectory() ? "folder" : "file", size: stat.size }; }
    catch (error) { if ((error as NodeJS.ErrnoException).code === "ENOENT") return null; throw error; }
  }
  async list(folder: string): Promise<{ files: string[]; folders: string[] }> {
    const files: string[] = [];
    const folders: string[] = [];
    for (const name of await fs.readdir(join(this.root, folder))) {
      const path = folder ? `${folder}/${name}` : name;
      ((await this.stat(path))?.type === "folder" ? folders : files).push(path);
    }
    return { files, folders };
  }
  async readBinary(path: string): Promise<ArrayBuffer> { return Uint8Array.from(await fs.readFile(join(this.root, path))).buffer; }
  async writeBinary(path: string, bytes: ArrayBuffer): Promise<void> { await fs.writeFile(join(this.root, path), new Uint8Array(bytes)); }
  async mkdir(path: string): Promise<void> { await fs.mkdir(join(this.root, path)); }
  async remove(path: string): Promise<void> { await fs.unlink(join(this.root, path)); }
  async rmdir(path: string, recursive: boolean): Promise<void> { await fs.rm(join(this.root, path), { recursive }); }
}

let temporary: string;
let Store: new (app: unknown, policy: PathPolicy) => LocalStore;
before(async () => {
  temporary = await fs.mkdtemp(join(tmpdir(), "gvs-local-tests-"));
  const bundle = await build({ entryPoints: [resolve("src/local.ts")], write: false, bundle: true, format: "cjs", platform: "node", external: ["obsidian"] });
  const module = { exports: {} as { ObsidianStore: typeof Store } };
  const require = createRequire(import.meta.url);
  runInNewContext(bundle.outputFiles[0].text, {
    module, exports: module.exports, TextEncoder, Uint8Array, ArrayBuffer,
    require: (name: string) => name === "obsidian" ? { FileSystemAdapter: MockAdapter, TFile: MockFile } : require(name)
  });
  Store = module.exports.ObsidianStore;
});
after(async () => { await fs.rm(temporary, { recursive: true, force: true }); });

async function fixture(): Promise<{ store: LocalStore; root: string; calls: string[] }> {
  const root = await fs.mkdtemp(join(temporary, "vault-"));
  await fs.mkdir(join(root, ".obsidian"));
  const adapter = new MockAdapter(root);
  const calls: string[] = [];
  const app = {
    vault: {
      adapter,
      getAbstractFileByPath: (path: string) => !path.split("/").some(part => part.startsWith(".")) &&
        existsSync(join(root, path)) && statSync(join(root, path)).isFile() ? new MockFile(path) : null,
      createFolder: async (path: string) => { calls.push(`folder:${path}`); await adapter.mkdir(path); },
      createBinary: async (path: string, bytes: ArrayBuffer) => { calls.push(`create:${path}`); await adapter.writeBinary(path, bytes); },
      modifyBinary: async (file: MockFile, bytes: ArrayBuffer) => { calls.push(`modify:${file.path}`); await adapter.writeBinary(file.path, bytes); }
    },
    fileManager: { trashFile: async (file: MockFile) => { calls.push(`trash:${file.path}`); await adapter.remove(file.path); } }
  };
  return { root, calls, store: new Store(app, new PathPolicy(defaults(), ".obsidian")) };
}

test("真实文件系统：中文嵌套文件夹、二进制和现有文件更新", async () => {
  const { store, root, calls } = await fixture();
  const bytes = new Uint8Array([0, 255, 10, 20]);
  await store.write("笔记/附件/picture.png", bytes);
  assert.deepEqual(new Uint8Array(await fs.readFile(join(root, "笔记/附件/picture.png"))), bytes);
  assert.deepEqual(calls, ["folder:笔记", "folder:笔记/附件", "create:笔记/附件/picture.png"]);
  await store.write("笔记/附件/picture.png", new Uint8Array([42]));
  assert(calls.includes("modify:笔记/附件/picture.png"));
  await store.remove("笔记/附件/picture.png");
  assert(calls.includes("trash:笔记/附件/picture.png"));
});

test("真实文件系统：扫描不读取秘密、本插件和本机备份", async () => {
  const { store, root } = await fixture();
  await fs.writeFile(join(root, "note.md"), "hello");
  await fs.writeFile(join(root, ".env"), "token=never-upload");
  await fs.writeFile(join(root, ".obsidian/app.json"), "{}");
  await fs.mkdir(join(root, ".obsidian/plugins/github-vault-sync"), { recursive: true });
  await fs.writeFile(join(root, ".obsidian/plugins/github-vault-sync/data.json"), "local-state");
  await store.backup("note.md", new TextEncoder().encode("backup"), "test");
  assert.deepEqual(Object.keys(await store.scan()).sort(), [".obsidian/app.json", "note.md"]);
});

test("真实文件系统：备份、暂存、清理与隐藏配置", async () => {
  const { store, root, calls } = await fixture();
  const bytes = new TextEncoder().encode("safe backup");
  await store.backup("note.md", bytes, "run");
  await store.stage("note.md", bytes, "run");
  assert.deepEqual(await store.readStaged("note.md", "run"), bytes);
  await store.cleanupStage("run");
  assert(!existsSync(join(root, PRIVATE_DIR, "staging/run")));
  assert(existsSync(join(root, PRIVATE_DIR, "backups/run/note.md")));
  await store.write(".obsidian/app.json", new TextEncoder().encode("{}"));
  assert(!calls.some(call => call.includes(".obsidian")));
});

test("真实文件系统：拒绝符号链接读取和写入逃逸", async () => {
  const { store, root } = await fixture();
  const outside = await fs.mkdtemp(join(temporary, "outside-"));
  await fs.writeFile(join(outside, "private.md"), "secret");
  await fs.symlink(outside, join(root, "linked"), "dir");
  await assert.rejects(store.scan(), /符号链接/);
  await assert.rejects(store.read("linked/private.md"), /符号链接/);
  await assert.rejects(store.write("linked/private.md", new Uint8Array()), /符号链接/);
  assert.equal(await fs.readFile(join(outside, "private.md"), "utf8"), "secret");
});

test("真实文件系统：拒绝穿越路径和目录占用", async () => {
  const { store, root } = await fixture();
  await assert.rejects(store.write("../escape.md", new Uint8Array()));
  await fs.mkdir(join(root, "folder"));
  await assert.rejects(store.hash("folder"), /文件夹占用/);
});
