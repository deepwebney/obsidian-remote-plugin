param(
    [string]$VaultPath,
    [string]$ConfigDir = '.obsidian'
)
$ErrorActionPreference = 'Stop'
$Payload = Join-Path $PSScriptRoot 'github-vault-sync'
if (-not (Test-Path -LiteralPath (Join-Path $Payload 'main.js') -PathType Leaf)) {
    $Payload = Split-Path $PSScriptRoot -Parent
}
$Files = @('main.js', 'manifest.json', 'styles.css')
foreach ($File in $Files) {
    if (-not (Test-Path -LiteralPath (Join-Path $Payload $File) -PathType Leaf)) {
        throw "Missing plugin file: $File"
    }
}
if ([string]::IsNullOrWhiteSpace($VaultPath)) {
    Add-Type -AssemblyName System.Windows.Forms
    $Dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    $Dialog.Description = 'Close Obsidian, then select your VAULT folder (not .obsidian)'
    if ($Dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
    $VaultPath = $Dialog.SelectedPath
}
if (-not (Test-Path -LiteralPath $VaultPath -PathType Container)) { throw 'Vault folder does not exist.' }
if ($ConfigDir -in @('', '.', '..') -or $ConfigDir.IndexOfAny([char[]]'\/') -ge 0) {
    throw 'Config directory must be a single folder name.'
}
$VaultPath = (Resolve-Path -LiteralPath $VaultPath).Path
$ConfigRoot = Join-Path $VaultPath $ConfigDir
if (-not (Test-Path -LiteralPath $ConfigRoot -PathType Container)) {
    throw "No $ConfigDir folder found. Open this vault in Obsidian once, then close it and retry."
}
$Plugins = Join-Path $ConfigRoot 'plugins'
$Destination = Join-Path $Plugins 'github-vault-sync'
$PrivateDir = Join-Path $VaultPath '.github-vault-sync-local'
$BackupRoot = Join-Path $PrivateDir 'install-backups'
foreach ($PathToCheck in @($ConfigRoot, $Plugins, $Destination, $PrivateDir, $BackupRoot)) {
    if (Test-Path -LiteralPath $PathToCheck) {
        if ((Get-Item -LiteralPath $PathToCheck -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
            throw "Refusing to install through a symbolic link or junction: $PathToCheck"
        }
    }
}
foreach ($File in $Files) {
    $Target = Join-Path $Destination $File
    if (Test-Path -LiteralPath $Target) {
        $Item = Get-Item -LiteralPath $Target -Force
        if ($Item.PSIsContainer -or ($Item.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
            throw "Unsafe existing plugin file: $Target"
        }
    }
}
if (Test-Path -LiteralPath $Destination) {
    $Backup = Join-Path $BackupRoot ((Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $Backup -Force | Out-Null
    foreach ($File in $Files) {
        $Existing = Join-Path $Destination $File
        if (Test-Path -LiteralPath $Existing -PathType Leaf) { Copy-Item -LiteralPath $Existing -Destination (Join-Path $Backup $File) }
    }
}
New-Item -ItemType Directory -Path $Destination -Force | Out-Null
foreach ($File in $Files) {
    $Source = Join-Path $Payload $File
    $Target = Join-Path $Destination $File
    Copy-Item -LiteralPath $Source -Destination $Target -Force
    if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash) {
        throw "File verification failed: $File"
    }
}
Write-Host "Installed successfully: $Destination"
Write-Host 'Open Obsidian > Settings > Community plugins, then enable GitHub Vault Sync.'
Write-Host 'Existing plugin settings and all vault notes were preserved.'
