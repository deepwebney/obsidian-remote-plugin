@echo off
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0Install-Windows.ps1" %*
if errorlevel 1 echo Installation failed. Read the error above before retrying.
pause
