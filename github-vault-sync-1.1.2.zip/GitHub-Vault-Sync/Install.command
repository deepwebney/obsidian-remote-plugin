#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd -P)"
PAYLOAD="$SCRIPT_DIR/github-vault-sync"
if [ ! -f "$PAYLOAD/main.js" ]; then PAYLOAD="$SCRIPT_DIR/.."; fi
for FILE in main.js manifest.json styles.css; do
  if [ ! -f "$PAYLOAD/$FILE" ]; then printf 'Missing plugin file: %s\n' "$FILE" >&2; exit 1; fi
done

VAULT="${1:-}"
CONFIG_DIR="${2:-.obsidian}"
if [ -z "$VAULT" ]; then
  printf 'Please close Obsidian before installing. Select the VAULT folder, not the .obsidian folder.\n'
  if command -v osascript >/dev/null 2>&1; then
    VAULT="$(osascript -e 'POSIX path of (choose folder with prompt "Select your Obsidian VAULT folder (close Obsidian first)")')"
  else
    read -r -p 'Vault folder path: ' VAULT
  fi
fi
if [ ! -d "$VAULT" ]; then printf 'Vault folder does not exist.\n' >&2; exit 1; fi
case "$CONFIG_DIR" in
  ''|.|..|*/*|*\\*) printf 'Config directory must be a single folder name.\n' >&2; exit 1 ;;
esac
VAULT="$(cd "$VAULT" && pwd -P)"
CONFIG_ROOT="$VAULT/$CONFIG_DIR"
if [ ! -d "$CONFIG_ROOT" ]; then
  printf 'No %s folder found. Open this vault in Obsidian once first, then close it and try again.\n' "$CONFIG_DIR" >&2
  exit 1
fi
DEST="$CONFIG_ROOT/plugins/github-vault-sync"
BACKUPS="$VAULT/.github-vault-sync-local"
for PATH_TO_CHECK in "$CONFIG_ROOT" "$CONFIG_ROOT/plugins" "$DEST" "$BACKUPS" "$BACKUPS/install-backups"; do
  if [ -L "$PATH_TO_CHECK" ]; then printf 'Refusing to install through a symbolic link: %s\n' "$PATH_TO_CHECK" >&2; exit 1; fi
done
for FILE in main.js manifest.json styles.css; do
  if [ -L "$DEST/$FILE" ] || [ -d "$DEST/$FILE" ]; then printf 'Unsafe existing plugin file: %s\n' "$DEST/$FILE" >&2; exit 1; fi
done
if [ -d "$DEST" ]; then
  mkdir -p "$BACKUPS/install-backups"
  BACKUP="$(mktemp -d "$BACKUPS/install-backups/install-$(date +%Y%m%d-%H%M%S)-XXXXXX")"
  for FILE in main.js manifest.json styles.css; do
    if [ -f "$DEST/$FILE" ]; then cp "$DEST/$FILE" "$BACKUP/$FILE"; fi
  done
fi
mkdir -p "$DEST"
for FILE in main.js manifest.json styles.css; do
  cp "$PAYLOAD/$FILE" "$DEST/$FILE"
  cmp -s "$PAYLOAD/$FILE" "$DEST/$FILE"
done
printf '\nInstalled successfully: %s\n' "$DEST"
printf 'Open Obsidian > Settings > Community plugins, then enable GitHub Vault Sync.\n'
printf 'Existing plugin settings and all vault notes were preserved.\n'
if [ "$#" -eq 0 ]; then read -r -p 'Press Enter to close...' _; fi
