"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => GitHubVaultSync
});
module.exports = __toCommonJS(main_exports);
var import_obsidian3 = require("obsidian");

// node_modules/@noble/hashes/esm/utils.js
function isBytes(a) {
  return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
function abytes(b, ...lengths) {
  if (!isBytes(b))
    throw new Error("Uint8Array expected");
  if (lengths.length > 0 && !lengths.includes(b.length))
    throw new Error("Uint8Array expected of length " + lengths + ", got length=" + b.length);
}
function aexists(instance, checkFinished = true) {
  if (instance.destroyed)
    throw new Error("Hash instance has been destroyed");
  if (checkFinished && instance.finished)
    throw new Error("Hash#digest() has already been called");
}
function aoutput(out, instance) {
  abytes(out);
  const min = instance.outputLen;
  if (out.length < min) {
    throw new Error("digestInto() expects output buffer of length at least " + min);
  }
}
function clean(...arrays) {
  for (let i = 0; i < arrays.length; i++) {
    arrays[i].fill(0);
  }
}
function createView(arr) {
  return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
function rotl(word, shift) {
  return word << shift | word >>> 32 - shift >>> 0;
}
var hasHexBuiltin = /* @__PURE__ */ (() => (
  // @ts-ignore
  typeof Uint8Array.from([]).toHex === "function" && typeof Uint8Array.fromHex === "function"
))();
var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
function bytesToHex(bytes) {
  abytes(bytes);
  if (hasHexBuiltin)
    return bytes.toHex();
  let hex = "";
  for (let i = 0; i < bytes.length; i++) {
    hex += hexes[bytes[i]];
  }
  return hex;
}
function utf8ToBytes(str) {
  if (typeof str !== "string")
    throw new Error("string expected");
  return new Uint8Array(new TextEncoder().encode(str));
}
function toBytes(data) {
  if (typeof data === "string")
    data = utf8ToBytes(data);
  abytes(data);
  return data;
}
var Hash = class {
};
function createHasher(hashCons) {
  const hashC = (msg) => hashCons().update(toBytes(msg)).digest();
  const tmp = hashCons();
  hashC.outputLen = tmp.outputLen;
  hashC.blockLen = tmp.blockLen;
  hashC.create = () => hashCons();
  return hashC;
}

// node_modules/@noble/hashes/esm/_md.js
function setBigUint64(view, byteOffset, value, isLE) {
  if (typeof view.setBigUint64 === "function")
    return view.setBigUint64(byteOffset, value, isLE);
  const _32n = BigInt(32);
  const _u32_max = BigInt(4294967295);
  const wh = Number(value >> _32n & _u32_max);
  const wl = Number(value & _u32_max);
  const h = isLE ? 4 : 0;
  const l = isLE ? 0 : 4;
  view.setUint32(byteOffset + h, wh, isLE);
  view.setUint32(byteOffset + l, wl, isLE);
}
function Chi(a, b, c) {
  return a & b ^ ~a & c;
}
function Maj(a, b, c) {
  return a & b ^ a & c ^ b & c;
}
var HashMD = class extends Hash {
  constructor(blockLen, outputLen, padOffset, isLE) {
    super();
    this.finished = false;
    this.length = 0;
    this.pos = 0;
    this.destroyed = false;
    this.blockLen = blockLen;
    this.outputLen = outputLen;
    this.padOffset = padOffset;
    this.isLE = isLE;
    this.buffer = new Uint8Array(blockLen);
    this.view = createView(this.buffer);
  }
  update(data) {
    aexists(this);
    data = toBytes(data);
    abytes(data);
    const { view, buffer, blockLen } = this;
    const len = data.length;
    for (let pos = 0; pos < len; ) {
      const take = Math.min(blockLen - this.pos, len - pos);
      if (take === blockLen) {
        const dataView = createView(data);
        for (; blockLen <= len - pos; pos += blockLen)
          this.process(dataView, pos);
        continue;
      }
      buffer.set(data.subarray(pos, pos + take), this.pos);
      this.pos += take;
      pos += take;
      if (this.pos === blockLen) {
        this.process(view, 0);
        this.pos = 0;
      }
    }
    this.length += data.length;
    this.roundClean();
    return this;
  }
  digestInto(out) {
    aexists(this);
    aoutput(out, this);
    this.finished = true;
    const { buffer, view, blockLen, isLE } = this;
    let { pos } = this;
    buffer[pos++] = 128;
    clean(this.buffer.subarray(pos));
    if (this.padOffset > blockLen - pos) {
      this.process(view, 0);
      pos = 0;
    }
    for (let i = pos; i < blockLen; i++)
      buffer[i] = 0;
    setBigUint64(view, blockLen - 8, BigInt(this.length * 8), isLE);
    this.process(view, 0);
    const oview = createView(out);
    const len = this.outputLen;
    if (len % 4)
      throw new Error("_sha2: outputLen should be aligned to 32bit");
    const outLen = len / 4;
    const state = this.get();
    if (outLen > state.length)
      throw new Error("_sha2: outputLen bigger than state");
    for (let i = 0; i < outLen; i++)
      oview.setUint32(4 * i, state[i], isLE);
  }
  digest() {
    const { buffer, outputLen } = this;
    this.digestInto(buffer);
    const res = buffer.slice(0, outputLen);
    this.destroy();
    return res;
  }
  _cloneInto(to) {
    to || (to = new this.constructor());
    to.set(...this.get());
    const { blockLen, buffer, length, finished, destroyed, pos } = this;
    to.destroyed = destroyed;
    to.finished = finished;
    to.length = length;
    to.pos = pos;
    if (length % blockLen)
      to.buffer.set(buffer);
    return to;
  }
  clone() {
    return this._cloneInto();
  }
};

// node_modules/@noble/hashes/esm/legacy.js
var SHA1_IV = /* @__PURE__ */ Uint32Array.from([
  1732584193,
  4023233417,
  2562383102,
  271733878,
  3285377520
]);
var SHA1_W = /* @__PURE__ */ new Uint32Array(80);
var SHA1 = class extends HashMD {
  constructor() {
    super(64, 20, 8, false);
    this.A = SHA1_IV[0] | 0;
    this.B = SHA1_IV[1] | 0;
    this.C = SHA1_IV[2] | 0;
    this.D = SHA1_IV[3] | 0;
    this.E = SHA1_IV[4] | 0;
  }
  get() {
    const { A, B, C, D, E } = this;
    return [A, B, C, D, E];
  }
  set(A, B, C, D, E) {
    this.A = A | 0;
    this.B = B | 0;
    this.C = C | 0;
    this.D = D | 0;
    this.E = E | 0;
  }
  process(view, offset) {
    for (let i = 0; i < 16; i++, offset += 4)
      SHA1_W[i] = view.getUint32(offset, false);
    for (let i = 16; i < 80; i++)
      SHA1_W[i] = rotl(SHA1_W[i - 3] ^ SHA1_W[i - 8] ^ SHA1_W[i - 14] ^ SHA1_W[i - 16], 1);
    let { A, B, C, D, E } = this;
    for (let i = 0; i < 80; i++) {
      let F, K;
      if (i < 20) {
        F = Chi(B, C, D);
        K = 1518500249;
      } else if (i < 40) {
        F = B ^ C ^ D;
        K = 1859775393;
      } else if (i < 60) {
        F = Maj(B, C, D);
        K = 2400959708;
      } else {
        F = B ^ C ^ D;
        K = 3395469782;
      }
      const T = rotl(A, 5) + F + E + K + SHA1_W[i] | 0;
      E = D;
      D = C;
      C = rotl(B, 30);
      B = A;
      A = T;
    }
    A = A + this.A | 0;
    B = B + this.B | 0;
    C = C + this.C | 0;
    D = D + this.D | 0;
    E = E + this.E | 0;
    this.set(A, B, C, D, E);
  }
  roundClean() {
    clean(SHA1_W);
  }
  destroy() {
    this.set(0, 0, 0, 0, 0);
    clean(this.buffer);
  }
};
var sha1 = /* @__PURE__ */ createHasher(() => new SHA1());

// node_modules/@noble/hashes/esm/sha1.js
var sha12 = sha1;

// src/hash.ts
function gitHash(bytes) {
  return bytesToHex(sha12.create().update(new TextEncoder().encode(`blob ${bytes.length}\0`)).update(bytes).digest());
}
function toBase64(bytes) {
  const chunks = [];
  for (let offset = 0; offset < bytes.length; offset += 8192) {
    chunks.push(String.fromCharCode(...bytes.subarray(offset, offset + 8192)));
  }
  return btoa(chunks.join(""));
}
function fromBase64(value) {
  const binary = atob(value.replace(/\s/g, ""));
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

// src/selection.ts
function isSelected(path, rules) {
  let current = path;
  while (current) {
    if (Object.hasOwn(rules, current)) return rules[current];
    const slash = current.lastIndexOf("/");
    current = slash < 0 ? "" : current.slice(0, slash);
  }
  return false;
}
function selectPath(rules, path, selected) {
  const updated = Object.assign(/* @__PURE__ */ Object.create(null), rules);
  for (const key of Object.keys(updated)) {
    if (key === path || key.startsWith(`${path}/`)) delete updated[key];
  }
  updated[path] = selected;
  return updated;
}
function selectionState(path, rules) {
  const checked = isSelected(path, rules);
  return { checked, mixed: Object.entries(rules).some(([key, value]) => key.startsWith(`${path}/`) && value !== checked) };
}

// src/policy.ts
var PRIVATE_DIR = ".github-vault-sync-local";
var CONFIG_FILES = /* @__PURE__ */ new Set([
  "app.json",
  "appearance.json",
  "hotkeys.json",
  "core-plugins.json",
  "bookmarks.json",
  "daily-notes.json",
  "templates.json",
  "types.json",
  "graph.json"
]);
function assertSafePath(path) {
  if (!path || path.startsWith("/") || /[\\\x00-\x1f\x7f:*?"<>|]/.test(path)) {
    throw new Error(`\u4E0D\u652F\u6301\u6216\u4E0D\u5B89\u5168\u7684\u6587\u4EF6\u8DEF\u5F84\uFF1A${path}`);
  }
  for (const part of path.split("/")) {
    if (!part || part === "." || part === ".." || /[. ]$/.test(part) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part)) {
      throw new Error(`\u6587\u4EF6\u540D\u65E0\u6CD5\u5B89\u5168\u5730\u8DE8\u8BBE\u5907\u540C\u6B65\uFF1A${path}`);
    }
  }
}
function matches(pattern, path) {
  const clean2 = pattern.replace(/^\/+/, "");
  if (clean2.endsWith("/")) {
    const folder = clean2.slice(0, -1);
    return path === folder || path.startsWith(`${folder}/`) || !folder.includes("/") && path.split("/").includes(folder);
  }
  const expression = clean2.split("*").map((part) => part.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join(".*");
  return new RegExp(`^${expression}$`).test(path) || !clean2.includes("/") && path.split("/").some((part) => new RegExp(`^${expression}$`).test(part)) || path.startsWith(`${clean2}/`);
}
var PathPolicy = class {
  constructor(settings, configDir) {
    this.settings = settings;
    this.configDir = configDir;
  }
  settings;
  configDir;
  allows(path) {
    if (!this.eligible(path)) return false;
    if (this.settings.syncScope !== "selected") return true;
    if (Object.hasOwn(this.settings.selection, path)) return this.settings.selection[path];
    return isSelected(path, this.settings.selection) || isSelected(path.replace(/\.conflict-[\w-]+(?=\.[^/.]+$|$)/, ""), this.settings.selection);
  }
  canDescend(path) {
    return this.eligible(path) && (this.settings.syncScope !== "selected" || isSelected(path, this.settings.selection) || Object.entries(this.settings.selection).some(([key, value]) => value && key.startsWith(`${path}/`)));
  }
  eligible(path) {
    const parts = path.split("/");
    if (parts.some((part) => /^(\.git|\.trash|\.github-vault-sync-local|\.ssh|\.gnupg|\.aws|\.azure)$/i.test(part))) return false;
    if (parts.some((part) => /^\.env(?:\.|$)/i.test(part) || /\.(pem|key|p12|pfx)$/i.test(part) || /^(secrets?\.json|credentials(?:\.json)?|id_rsa|id_ed25519)$/i.test(part))) return false;
    if (path === `${this.configDir}/plugins/github-vault-sync` || path.startsWith(`${this.configDir}/plugins/github-vault-sync/`)) return false;
    const patterns = this.settings.exclusions.split(/\r?\n/).map((value) => value.trim()).filter(Boolean);
    if (patterns.some((pattern) => matches(pattern, path))) return false;
    if (path === this.configDir) return this.settings.includeConfig;
    if (path.startsWith(`${this.configDir}/`)) {
      if (!this.settings.includeConfig) return false;
      const relative = path.slice(this.configDir.length + 1).replace(/\.conflict-[\w-]+(?=\.[^/.]+$|$)/, "");
      if (CONFIG_FILES.has(relative)) return true;
      if (relative === "snippets" || relative.startsWith("snippets/")) return true;
      if (relative === "themes" || relative.startsWith("themes/")) return true;
      if (this.settings.includePluginCode) {
        if (relative === "community-plugins.json" || relative === "plugins") return true;
        if (/^plugins\/[^/]+(?:\/(?:main\.js|manifest\.json|styles\.css))?$/.test(relative)) return true;
      }
      return false;
    }
    return true;
  }
};
function assertCompatiblePaths(paths) {
  const seen = /* @__PURE__ */ new Map();
  const directories = /* @__PURE__ */ new Map();
  for (const path of paths) {
    assertSafePath(path);
    const key = path.normalize("NFC").toLowerCase();
    const previous = seen.get(key);
    if (previous && previous !== path) throw new Error(`\u6587\u4EF6\u540D\u5927\u5C0F\u5199\u6216 Unicode \u51B2\u7A81\uFF1A${previous} / ${path}`);
    seen.set(key, path);
    const parts = path.split("/");
    parts.pop();
    while (parts.length) {
      const directory = parts.join("/");
      const directoryKey = directory.normalize("NFC").toLowerCase();
      const previousDirectory = directories.get(directoryKey);
      if (previousDirectory && previousDirectory !== directory) {
        throw new Error(`\u6587\u4EF6\u5939\u5927\u5C0F\u5199\u6216 Unicode \u51B2\u7A81\uFF1A${previousDirectory} / ${directory}`);
      }
      directories.set(directoryKey, directory);
      parts.pop();
    }
  }
  for (const [key, path] of seen) {
    const parts = key.split("/");
    parts.pop();
    while (parts.length) {
      const parent = parts.join("/");
      if (seen.has(parent)) throw new Error(`\u6587\u4EF6\u548C\u6587\u4EF6\u5939\u8DEF\u5F84\u51B2\u7A81\uFF1A${seen.get(parent)} / ${path}\u3002\u8BF7\u5148\u624B\u52A8\u91CD\u547D\u540D\u3002`);
      parts.pop();
    }
  }
}

// src/planner.ts
function planSync(local, remote, baseline, mode, propagateDeletes, runId) {
  const paths = [.../* @__PURE__ */ new Set([...Object.keys(local), ...Object.keys(remote), ...Object.keys(baseline)])].sort();
  assertCompatiblePaths([...Object.keys(local), ...Object.keys(remote)]);
  const occupied = new Set(paths.map((path) => path.normalize("NFC").toLowerCase()));
  const actions = [];
  for (const path of paths) {
    const localSha = Object.hasOwn(local, path) ? local[path] : void 0;
    const remoteSha = Object.hasOwn(remote, path) ? remote[path] : void 0;
    const baseSha = Object.hasOwn(baseline, path) ? baseline[path] : void 0;
    if (localSha === remoteSha) continue;
    let kind;
    if (mode === "restore") {
      if (!remoteSha || localSha && remoteSha === baseSha) continue;
      kind = localSha && localSha !== baseSha ? "conflict" : "download";
    } else if (!baseSha) {
      kind = localSha && remoteSha ? "conflict" : localSha ? "upload" : "download";
    } else if (localSha === baseSha) {
      kind = remoteSha ? "download" : propagateDeletes ? "delete-local" : "upload";
    } else if (remoteSha === baseSha) {
      kind = localSha ? "upload" : propagateDeletes ? "delete-remote" : "download";
    } else {
      kind = localSha && remoteSha ? "conflict" : localSha ? "upload" : "download";
    }
    const action = { kind, path, localSha, remoteSha };
    if (kind === "conflict") {
      const slash = path.lastIndexOf("/");
      const dot = path.lastIndexOf(".");
      const extensionIndex = dot > slash + 1 ? dot : path.length;
      const stem = path.slice(0, extensionIndex);
      const extension = path.slice(extensionIndex);
      let counter = 0;
      let copyPath;
      do {
        copyPath = `${stem}.conflict-${runId}-${++counter}${extension}`;
      } while (occupied.has(copyPath.normalize("NFC").toLowerCase()));
      occupied.add(copyPath.normalize("NFC").toLowerCase());
      action.copyPath = copyPath;
    }
    actions.push(action);
  }
  assertCompatiblePaths([...Object.keys(local), ...Object.keys(remote), ...actions.flatMap((action) => action.copyPath ? [action.copyPath] : [])]);
  return actions;
}

// src/api-error.ts
var GitHubApiError = class extends Error {
  constructor(message, details, retryAt = 0, status = 0, retryable = retryAt > 0 || [408, 500, 502, 503, 504].includes(status)) {
    super(message);
    this.details = details;
    this.retryAt = retryAt;
    this.status = status;
    this.retryable = retryable;
    this.name = "GitHubApiError";
  }
  details;
  retryAt;
  status;
  retryable;
};
function redact(value, token) {
  return (token ? value.split(token).join("[\u5DF2\u9690\u85CF]") : value).replace(/(?:github_pat_|gh[pousr]_)[A-Za-z0-9_]+/g, "[\u5DF2\u9690\u85CF]").replace(/Bearer\s+[^\s"<>]+/gi, "Bearer [\u5DF2\u9690\u85CF]").replace(/[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]/g, "");
}
function step(method, path) {
  if (!path) return "\u8BFB\u53D6\u4ED3\u5E93\u4FE1\u606F";
  if (path.startsWith("/compare/")) return "\u6838\u5BF9\u63D0\u4EA4\u662F\u5426\u5DF2\u8FDB\u5165\u8FDC\u7A0B\u5386\u53F2";
  if (path.startsWith("/git/ref/")) return "\u8BFB\u53D6\u5206\u652F";
  if (path.startsWith("/git/refs/")) return "\u66F4\u65B0\u5206\u652F";
  if (path.startsWith("/git/blobs")) return method === "GET" ? "\u4E0B\u8F7D\u6587\u4EF6" : "\u4E0A\u4F20\u6587\u4EF6";
  if (path.startsWith("/git/trees")) return method === "GET" ? "\u8BFB\u53D6\u6587\u4EF6\u6811" : "\u521B\u5EFA\u6587\u4EF6\u6811";
  if (path.startsWith("/git/commits")) return method === "GET" ? "\u8BFB\u53D6\u63D0\u4EA4" : "\u521B\u5EFA\u63D0\u4EA4";
  return "\u8BBF\u95EE GitHub";
}
function describeApiError(response, method, path, token, now = Date.now()) {
  const headers = Object.fromEntries(Object.entries(response.headers).map(([name, value]) => [name.toLowerCase(), value]));
  const payload = response.json;
  const rawMessage = typeof payload?.message === "string" ? payload.message : response.text ?? "";
  const message = redact(rawMessage.replace(/<[^>]*>/g, " "), token).trim().slice(0, 700);
  const limitedStatus = response.status === 403 || response.status === 429;
  const primaryLimit = limitedStatus && headers["x-ratelimit-remaining"]?.trim() === "0";
  const secondaryLimit = limitedStatus && /secondary rate limit|abuse detection/i.test(rawMessage);
  const rateLimited = primaryLimit || secondaryLimit || response.status === 429 || limitedStatus && /rate[ -]limit/i.test(rawMessage);
  let reason;
  let retryAt = 0;
  if (rateLimited) {
    const retryHeader = headers["retry-after"]?.trim();
    const seconds = retryHeader ? Number(retryHeader) : NaN;
    const retryTime = Number.isFinite(seconds) && seconds >= 0 ? now + seconds * 1e3 : Date.parse(retryHeader ?? "");
    const resetTime = primaryLimit ? Number(headers["x-ratelimit-reset"]) * 1e3 : NaN;
    const candidates = [retryTime, resetTime].filter((value) => Number.isFinite(value) && value > now && value < 864e13);
    retryAt = candidates.length ? Math.max(...candidates) + 1e3 : now + 6e4;
    reason = `${primaryLimit ? "GitHub API \u8BF7\u6C42\u989D\u5EA6\u5DF2\u7528\u5C3D" : secondaryLimit ? "GitHub \u6B21\u7EA7\u9650\u6D41\uFF08\u8BF7\u6C42\u8FC7\u5BC6\uFF09" : "GitHub \u8BF7\u6C42\u88AB\u9650\u6D41"}\u3002\u8BF7\u5728 ${new Date(retryAt).toLocaleString()} \u540E\u91CD\u8BD5\uFF0C\u4E0D\u8981\u8FDE\u7EED\u70B9\u51FB\u540C\u6B65\u3002`;
  } else if (response.status === 401) {
    reason = "GitHub Token \u65E0\u6548\u6216\u5DF2\u8FC7\u671F\uFF0C\u8BF7\u91CD\u65B0\u8BBE\u7F6E\u3002";
  } else if (response.status === 403 && /user.agent/i.test(rawMessage)) {
    reason = "GitHub \u62D2\u7EDD\u4E86 User-Agent \u8BF7\u6C42\u5934\u3002\u63D2\u4EF6\u5DF2\u53D1\u9001\u5E94\u7528\u6807\u8BC6\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u4EE3\u7406\u662F\u5426\u79FB\u9664\u4E86\u8BE5\u8BF7\u6C42\u5934\u3002";
  } else if (response.status === 403 && (/^required\b/i.test(headers["x-github-sso"] ?? "") || /SAML|single sign.on|\bSSO\b/i.test(rawMessage))) {
    reason = "\u7EC4\u7EC7 SSO / SAML \u6388\u6743\u672A\u5B8C\u6210\u3002\u8BF7\u4E3A\u8BE5 Token \u5B8C\u6210\u7EC4\u7EC7\u6388\u6743\uFF0C\u6216\u8054\u7CFB\u7EC4\u7EC7\u7BA1\u7406\u5458\u68C0\u67E5\u8BBF\u95EE\u7B56\u7565\u3002";
  } else if (response.status === 403 && /IP.*(?:allow.?list|not permitted)|(?:allow.?list).*IP/i.test(rawMessage)) {
    reason = "\u5F53\u524D\u7F51\u7EDC\u51FA\u53E3 IP \u4E0D\u5728\u7EC4\u7EC7\u5141\u8BB8\u5217\u8868\u4E2D\uFF0C\u8BF7\u4F7F\u7528\u83B7\u51C6\u7684\u7F51\u7EDC\u6216\u8054\u7CFB\u7EC4\u7EC7\u7BA1\u7406\u5458\u3002";
  } else if (response.status === 403 && /resource not accessible|permission|write access|access denied|must have.*push/i.test(rawMessage)) {
    reason = "\u5F53\u524D Token \u6216\u8D26\u6237\u65E0\u6743\u6267\u884C\u6B64\u64CD\u4F5C\u3002\u8BF7\u6838\u5BF9\u76EE\u6807\u4ED3\u5E93\u6388\u6743\u3001Contents: Read and write\uFF0C\u4EE5\u53CA\u7EC4\u7EC7\u5BA1\u6279\u72B6\u6001\u3002";
  } else if (response.status === 403) {
    reason = "GitHub \u62D2\u7EDD\u8BBF\u95EE\uFF0C\u4F46\u672A\u660E\u786E\u8BF4\u660E\u662F\u6743\u9650\u8FD8\u662F\u8BBF\u95EE\u7B56\u7565\u95EE\u9898\u3002\u8BF7\u67E5\u770B\u300C\u6700\u8FD1\u4E00\u6B21\u8BCA\u65AD\u300D\uFF0C\u4E0D\u8981\u4EC5\u51ED HTTP 403 \u5224\u65AD\u4E3A\u9650\u6D41\u3002";
  } else if (response.status === 404) {
    reason = "\u627E\u4E0D\u5230\u4ED3\u5E93\u6216\u5206\u652F\uFF0C\u6216 Token \u65E0\u6743\u8BBF\u95EE\u3002\u8BF7\u68C0\u67E5\u76EE\u6807\u6388\u6743\uFF1B\u65B0\u4ED3\u5E93\u9700\u5148\u6DFB\u52A0 README\u3002";
  } else if (response.status === 409 || response.status === 422) {
    reason = "GitHub \u62D2\u7EDD\u63D0\u4EA4\uFF1A\u53EF\u80FD\u662F\u5176\u4ED6\u8BBE\u5907\u66F4\u65B0\u3001\u7A7A\u4ED3\u5E93\u3001\u5206\u652F\u4FDD\u62A4\u6216\u65E0\u6548\u8BF7\u6C42\u3002\u8BF7\u67E5\u770B\u8BCA\u65AD\u540E\u91CD\u65B0\u9884\u89C8\u3002";
  } else {
    reason = "GitHub \u8BF7\u6C42\u5931\u8D25\uFF0C\u8BF7\u67E5\u770B\u6700\u8FD1\u4E00\u6B21\u8BCA\u65AD\u3002";
  }
  const summary = `${step(method, path)}\u5931\u8D25\uFF08HTTP ${response.status}\uFF09\uFF1A${reason}`;
  const lines = [
    summary,
    `\u53D1\u751F\u65F6\u95F4\uFF1A${new Date(now).toISOString()}`,
    `\u8BF7\u6C42\u65B9\u6CD5\uFF1A${method}`,
    `GitHub \u6D88\u606F\uFF1A${message || "\u672A\u8FD4\u56DE\u53EF\u7528\u7684\u9519\u8BEF\u4FE1\u606F"}`
  ];
  for (const name of ["x-ratelimit-limit", "x-ratelimit-remaining", "x-ratelimit-reset", "retry-after", "x-accepted-github-permissions", "x-github-request-id"]) {
    if (headers[name]) lines.push(`${name}: ${redact(headers[name], token).slice(0, 300)}`);
  }
  if (primaryLimit && headers["x-ratelimit-limit"] === "60") {
    lines.push("\u63D0\u793A\uFF1A\u8FD4\u56DE\u989D\u5EA6\u4E3A 60\uFF0C\u8BF7\u68C0\u67E5\u8BA4\u8BC1\u662F\u5426\u751F\u6548\uFF0C\u6216\u4EE3\u7406\u662F\u5426\u79FB\u9664\u4E86 Authorization \u8BF7\u6C42\u5934\uFF1B\u4E0D\u80FD\u636E\u6B64\u76F4\u63A5\u65AD\u8A00 Token \u6743\u9650\u4E0D\u8DB3\u3002");
  }
  return new GitHubApiError(summary, lines.join("\n"), retryAt, response.status);
}

// src/request-control.ts
async function withRetry(operation, retry, check = () => {
}) {
  for (let attempt = 0; ; attempt++) {
    check();
    try {
      return await operation();
    } catch (error) {
      check();
      if (!await retry?.(error, attempt)) throw error;
    }
  }
}
var RequestControl = class {
  constructor(now = Date.now, sleep = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds))) {
    this.now = now;
    this.sleep = sleep;
  }
  now;
  sleep;
  lastMutation = -Infinity;
  rateError;
  get coolingDown() {
    return !!this.rateError && this.rateError.retryAt > this.now();
  }
  hold(error) {
    if (error.retryAt > (this.rateError?.retryAt ?? 0)) this.rateError = error;
  }
  async retry(error, attempt, check = () => {
  }, progress = () => {
  }) {
    check();
    if (!(error instanceof GitHubApiError) || !error.retryable) return false;
    const delay = Math.max(2e3 * 2 ** attempt, error.retryAt - this.now(), (this.rateError?.retryAt ?? 0) - this.now());
    if (attempt >= 3 || delay > 3e5) {
      const reason = attempt >= 3 ? "\u81EA\u52A8\u91CD\u8BD5 3 \u6B21\u540E\u4ECD\u5931\u8D25" : "GitHub \u8981\u6C42\u7684\u51B7\u5374\u65F6\u95F4\u8D85\u8FC7 5 \u5206\u949F";
      const message = `${reason}\uFF0C\u4EFB\u52A1\u5DF2\u505C\u6B62\uFF1B\u6062\u590D\u540E\u70B9\u51FB\u300C\u7EE7\u7EED\u4E0A\u6B21\u4EFB\u52A1\u300D\u3002${error.message}`;
      throw new GitHubApiError(message, `${message}
\u539F\u59CB\u8BCA\u65AD\uFF1A
${error.details}`, error.retryAt, error.status, false);
    }
    const deadline = this.now() + delay;
    let lastSeconds = -1;
    while (this.now() < deadline) {
      check();
      const remaining = deadline - this.now();
      const seconds = Math.ceil(remaining / 1e3);
      if (seconds !== lastSeconds) {
        progress(`${error.retryAt > this.now() ? "GitHub \u9650\u6D41\u7B49\u5F85" : error.status ? `HTTP ${error.status} \u6682\u65F6\u5931\u8D25` : "\u7F51\u7EDC\u6682\u65F6\u4E2D\u65AD"}\uFF1A${seconds} \u79D2\u540E\u81EA\u52A8\u91CD\u8BD5\uFF08${attempt + 1}/3\uFF09\uFF0C\u53EF\u505C\u6B62\u540C\u6B65`);
        lastSeconds = seconds;
      }
      await this.sleep(Math.min(250, remaining));
    }
    check();
    return true;
  }
  checkCooldown() {
    if (this.coolingDown) throw this.rateError;
  }
  async before(method) {
    this.checkCooldown();
    if (!["POST", "PATCH", "PUT", "DELETE"].includes(method)) return;
    const delay = this.lastMutation + 1100 - this.now();
    if (delay > 0) await this.sleep(delay);
    this.checkCooldown();
    this.lastMutation = this.now();
  }
};

// src/engine.ts
var SyncEngine = class {
  constructor(local, remote, progress = () => {
  }, options = {}) {
    this.local = local;
    this.remote = remote;
    this.progress = progress;
    this.options = options;
    this.state = options.state;
  }
  local;
  remote;
  progress;
  options;
  state;
  verified = /* @__PURE__ */ new Set();
  check() {
    this.options.check?.();
  }
  async prepare(baseline, mode, deletes) {
    this.check();
    if (this.state?.plan) {
      if (this.state.target !== (this.options.target ?? "") || this.state.plan.mode !== mode) {
        throw new Error("\u6709\u4E0D\u540C\u76EE\u6807\u6216\u6A21\u5F0F\u7684\u672A\u5B8C\u6210\u4EFB\u52A1\u3002\u8BF7\u5148\u6062\u590D\u539F\u4EFB\u52A1\u6216\u70B9\u51FB\u300C\u5B89\u5168\u91CD\u65B0\u89C4\u5212\u300D\u3002");
      }
      this.progress(`\u6062\u590D\u65AD\u70B9\uFF1A\u5DF2\u5B8C\u6210 ${this.state.nextIndex}/${this.state.plan.actions.length} \u9879`);
      return this.state.plan;
    }
    this.progress("\u626B\u63CF\u672C\u5730\u6587\u4EF6");
    const local = await this.local.scan();
    this.check();
    this.progress("\u8BFB\u53D6 GitHub \u6587\u4EF6\u6811");
    const remote = await withRetry(() => this.remote.snapshot(), this.options.retry, () => this.check());
    this.check();
    const runId = `${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}-${Math.random().toString(36).slice(2, 7)}`;
    return { local, remote, mode, runId, actions: planSync(local, remote.files, baseline, mode, deletes, runId) };
  }
  async save(baseline) {
    await this.options.checkpoint?.(this.state, baseline);
  }
  async ensureUnchanged(path, expected) {
    this.check();
    if (await this.local.hash(path) !== expected) {
      throw new Error(`\u672C\u5730\u6587\u4EF6\u53D1\u751F\u53D8\u5316\uFF1A${path}\u3002\u65AD\u70B9\u5DF2\u4FDD\u7559\uFF1B\u8BF7\u6682\u505C\u7F16\u8F91\uFF0C\u6216\u70B9\u51FB\u300C\u5B89\u5168\u91CD\u65B0\u89C4\u5212\u300D\u3002`);
    }
  }
  async staged(path, runId, expected) {
    this.check();
    const bytes = await this.local.readStaged(path, runId);
    if (!bytes || gitHash(bytes) !== expected) throw new Error(`\u6682\u5B58\u6587\u4EF6\u6821\u9A8C\u5931\u8D25\uFF1A${path}\uFF0C\u672A\u5E94\u7528\u8BE5\u6587\u4EF6\u3002`);
    return bytes;
  }
  async stageDownload(action, runId) {
    this.check();
    if (await this.local.stagedHash?.(action.path, runId) === action.remoteSha) {
      this.progress(`\u590D\u7528\u5DF2\u6821\u9A8C\u4E0B\u8F7D\uFF1A${action.path}`);
      return;
    }
    const bytes = await this.remote.download(action.remoteSha);
    if (gitHash(bytes) !== action.remoteSha) throw new Error(`\u8FDC\u7A0B\u6587\u4EF6\u6821\u9A8C\u5931\u8D25\uFF1A${action.path}`);
    this.check();
    await this.local.stage(action.path, bytes, runId);
  }
  async upload(bytes, baseline) {
    this.check();
    const sha = gitHash(bytes);
    if (this.verified.has(sha)) return sha;
    if (Object.hasOwn(this.state.uploaded, sha) && this.remote.verifyBlob) {
      this.progress(`\u6821\u9A8C\u5DF2\u4E0A\u4F20\u5BF9\u8C61 ${sha.slice(0, 10)}`);
      if (await this.remote.verifyBlob(sha, bytes.length)) {
        this.verified.add(sha);
        return sha;
      }
    }
    this.state.uploaded[sha] = bytes.length;
    await this.save(baseline);
    this.check();
    if (await this.remote.upload(bytes) !== sha) throw new Error("\u4E0A\u4F20\u6587\u4EF6\u6821\u9A8C\u5931\u8D25\uFF0C\u672A\u63D0\u4EA4\u8BE5\u6279\u6B21\u3002");
    this.verified.add(sha);
    await this.save(baseline);
    return sha;
  }
  changes(actions, mode) {
    const changes = /* @__PURE__ */ Object.create(null);
    if (mode === "restore") return changes;
    for (const action of actions) {
      if (action.kind === "upload" || action.kind === "conflict") changes[action.copyPath ?? action.path] = action.localSha;
      if (action.kind === "delete-remote") changes[action.path] = null;
    }
    return changes;
  }
  async prepareBatch(actions, plan, baseline) {
    await this.remote.assertHead(plan.remote.head);
    for (const action of actions) {
      this.progress(`\u51C6\u5907\u6587\u4EF6\uFF1A${action.path}`);
      const remoteSha = Object.hasOwn(plan.remote.files, action.path) ? plan.remote.files[action.path] : void 0;
      if (remoteSha !== action.remoteSha) throw new Error(`\u8FDC\u7A0B\u6587\u4EF6\u5DF2\u53D8\u5316\uFF1A${action.path}\u3002\u8BF7\u5B89\u5168\u91CD\u65B0\u89C4\u5212\u3002`);
      await this.ensureUnchanged(action.path, action.localSha);
      if (action.copyPath) await this.ensureUnchanged(action.copyPath);
      if (action.kind === "download" || action.kind === "conflict") await this.stageDownload(action, plan.runId);
      if (action.localSha && action.kind !== "delete-remote") {
        const bytes = await this.local.read(action.path);
        if (gitHash(bytes) !== action.localSha) throw new Error(`\u6587\u4EF6\u5DF2\u53D8\u5316\uFF1A${action.path}\uFF0C\u8BF7\u5B89\u5168\u91CD\u65B0\u89C4\u5212\u3002`);
        this.check();
        if (action.kind !== "upload") await this.local.backup(action.path, bytes, plan.runId);
        if (action.kind === "conflict") await this.local.stage(action.copyPath, bytes, plan.runId);
        if (plan.mode === "sync" && (action.kind === "upload" || action.kind === "conflict")) await this.upload(bytes, baseline);
      }
    }
    for (const action of actions) {
      await this.ensureUnchanged(action.path, action.localSha);
      if (action.copyPath) await this.ensureUnchanged(action.copyPath);
    }
  }
  async apply(actions, plan) {
    for (const action of actions) {
      this.check();
      this.progress(`\u5E94\u7528\u6587\u4EF6\uFF1A${action.path}`);
      if (action.kind === "conflict") {
        const copySha = await this.local.hash(action.copyPath);
        if (copySha !== action.localSha) {
          if (copySha !== void 0) throw new Error(`\u51B2\u7A81\u526F\u672C\u5DF2\u88AB\u7F16\u8F91\uFF1A${action.copyPath}\u3002\u8BF7\u5B89\u5168\u91CD\u65B0\u89C4\u5212\u3002`);
          if (this.local.stagedHash && await this.local.stagedHash(action.copyPath, plan.runId) !== action.localSha) {
            this.check();
            const original = await this.local.hash(action.path) === action.localSha ? await this.local.read(action.path) : this.local.readBackup ? await this.local.readBackup(action.path, plan.runId) : await this.remote.download(action.localSha);
            if (gitHash(original) !== action.localSha) throw new Error(`\u51B2\u7A81\u539F\u6587\u5907\u4EFD\u6821\u9A8C\u5931\u8D25\uFF1A${action.path}`);
            await this.local.stage(action.copyPath, original, plan.runId);
          }
          await this.local.write(action.copyPath, await this.staged(action.copyPath, plan.runId, action.localSha));
        }
      }
      if (action.kind === "download" || action.kind === "conflict") {
        if (await this.local.hash(action.path) !== action.remoteSha) {
          await this.ensureUnchanged(action.path, action.localSha);
          if (this.local.stagedHash && await this.local.stagedHash(action.path, plan.runId) !== action.remoteSha) await this.stageDownload(action, plan.runId);
          await this.local.write(action.path, await this.staged(action.path, plan.runId, action.remoteSha));
        }
      } else if (action.kind === "delete-local" && await this.local.hash(action.path) !== void 0) {
        await this.ensureUnchanged(action.path, action.localSha);
        await this.local.remove(action.path);
      }
    }
  }
  async execute(plan, baseline, device) {
    if (!this.state?.plan) {
      this.state = { target: this.options.target ?? "", uploaded: this.state?.uploaded ?? /* @__PURE__ */ Object.create(null), plan, nextIndex: 0 };
      await this.save(baseline);
    }
    const state = this.state;
    plan = state.plan;
    const nextBaseline = Object.assign(/* @__PURE__ */ Object.create(null), baseline);
    const batchSize = Math.max(1, Math.min(100, Math.floor(this.options.batchSize ?? 20)));
    while (state.nextIndex < plan.actions.length) {
      await withRetry(async () => {
        this.check();
        if (!state.batch) {
          const count = Math.min(batchSize, plan.actions.length - state.nextIndex);
          const actions2 = plan.actions.slice(state.nextIndex, state.nextIndex + count);
          state.batch = { start: state.nextIndex, count, transaction: {
            baseHead: plan.remote.head,
            baseTree: plan.remote.tree,
            changes: this.changes(actions2, plan.mode),
            phase: "prepared",
            message: `Vault sync: ${device} [${plan.runId}:${state.nextIndex + 1}-${state.nextIndex + count}]`
          } };
          await this.save(nextBaseline);
        }
        const batch = state.batch;
        const actions = plan.actions.slice(batch.start, batch.start + batch.count);
        const transaction = batch.transaction;
        this.progress(`\u6279\u6B21 ${batch.start + 1}\u2013${batch.start + batch.count}/${plan.actions.length}`);
        if ((transaction.phase === "updating" || transaction.phase === "confirmed") && this.remote.reconcile && Object.keys(transaction.changes).length) {
          this.progress("\u6838\u5BF9\u4E0A\u6B21\u5206\u652F\u66F4\u65B0\u7ED3\u679C");
          const outcome = await this.remote.reconcile(transaction);
          if (outcome === "moved") throw new Error("\u8FDC\u7A0B\u5206\u652F\u5DF2\u53D8\u5316\uFF0C\u65E7\u6279\u6B21\u4E0D\u4F1A\u91CD\u653E\u3002\u8BF7\u70B9\u51FB\u300C\u5B89\u5168\u91CD\u65B0\u89C4\u5212\u300D\u3002");
          transaction.phase = outcome === "confirmed" ? "confirmed" : "prepared";
          await this.save(nextBaseline);
        }
        if (transaction.phase !== "confirmed") {
          await this.prepareBatch(actions, plan, nextBaseline);
          this.check();
          this.progress("\u63D0\u4EA4\u672C\u6279\u6B21\u5E76\u8BB0\u5F55\u786E\u8BA4\u7ED3\u679C");
          transaction.commitSha = plan.mode === "sync" ? await this.remote.commit(plan.remote, transaction.changes, transaction.message, {
            state: transaction,
            save: () => this.save(nextBaseline),
            check: () => this.check()
          }) : (await this.remote.assertHead(plan.remote.head), plan.remote.head);
          transaction.phase = "confirmed";
          await this.save(nextBaseline);
        }
        this.check();
        const remoteAfter = await this.remote.snapshot();
        for (const action of actions) {
          const expected = Object.hasOwn(transaction.changes, action.path) ? transaction.changes[action.path] ?? void 0 : action.remoteSha;
          if (remoteAfter.files[action.path] !== expected || plan.mode === "sync" && action.copyPath && remoteAfter.files[action.copyPath] !== action.localSha) {
            throw new Error(`\u672C\u6279\u6B21\u5DF2\u786E\u8BA4\uFF0C\u4F46\u8FDC\u7A0B\u53C8\u53D1\u751F\u53D8\u5316\uFF1A${action.path}\u3002\u8BF7\u5B89\u5168\u91CD\u65B0\u89C4\u5212\uFF0C\u907F\u514D\u5E94\u7528\u8FC7\u671F\u5185\u5BB9\u3002`);
          }
        }
        await this.apply(actions, plan);
        this.check();
        for (const action of actions) {
          for (const path of [action.path, ...action.copyPath ? [action.copyPath] : []]) {
            const localSha = await this.local.hash(path);
            if (localSha === remoteAfter.files[path]) {
              if (localSha) nextBaseline[path] = localSha;
              else delete nextBaseline[path];
            } else if (action.kind === "upload" && path === action.path) nextBaseline[path] = action.localSha;
          }
        }
        state.nextIndex += batch.count;
        state.batch = void 0;
        plan.remote = remoteAfter;
        await this.save(nextBaseline);
        this.progress(`\u5DF2\u786E\u8BA4 ${state.nextIndex}/${plan.actions.length} \u9879\uFF0C\u65AD\u70B9\u5DF2\u4FDD\u5B58\uFF1B${state.nextIndex < plan.actions.length ? "\u81EA\u52A8\u7EE7\u7EED\u4E0B\u4E00\u6279" : "\u6B63\u5728\u5B8C\u6210\u6700\u7EC8\u6821\u9A8C"}`);
      }, this.options.retry, () => this.check());
    }
    this.check();
    this.progress("\u9A8C\u8BC1\u540C\u6B65\u7ED3\u679C");
    const finalLocal = await this.local.scan();
    const finalRemote = await withRetry(() => this.remote.snapshot(), this.options.retry, () => this.check());
    for (const path of /* @__PURE__ */ new Set([...Object.keys(nextBaseline), ...Object.keys(finalRemote.files), ...Object.keys(finalLocal)])) {
      if (finalLocal[path] === finalRemote.files[path]) {
        if (finalLocal[path]) nextBaseline[path] = finalLocal[path];
        else delete nextBaseline[path];
      }
    }
    this.check();
    await this.local.cleanupStage(plan.runId);
    this.state = void 0;
    await this.save(nextBaseline);
    return nextBaseline;
  }
  async replan(baseline) {
    this.check();
    const state = this.state;
    if (!state) return baseline;
    const nextBaseline = Object.assign(/* @__PURE__ */ Object.create(null), baseline);
    const transaction = state.batch?.transaction;
    if (transaction && (transaction.phase === "updating" || transaction.phase === "confirmed") && Object.keys(transaction.changes).length) {
      if (!this.remote.reconcile) throw new Error("\u65E0\u6CD5\u6838\u5BF9\u672A\u786E\u8BA4\u63D0\u4EA4\uFF0C\u672A\u6E05\u9664\u65AD\u70B9\u3002");
      const outcome = await this.remote.reconcile(transaction);
      if (outcome === "confirmed") {
        const actions = state.plan.actions.slice(state.batch.start, state.batch.start + state.batch.count);
        for (const action of actions) {
          if (action.kind === "upload") nextBaseline[action.path] = action.localSha;
          if (action.kind === "delete-remote") delete nextBaseline[action.path];
        }
      }
    }
    state.plan = void 0;
    state.batch = void 0;
    state.nextIndex = 0;
    await this.options.checkpoint?.(state, nextBaseline);
    return nextBaseline;
  }
};

// src/types.ts
var MAX_FILE_BYTES = 50 * 1024 * 1024;
function defaults() {
  return {
    owner: "",
    repo: "",
    branch: "main",
    secretId: `github-vault-sync-${Math.random().toString(36).slice(2, 12)}`,
    deviceName: "\u6211\u7684\u8BBE\u5907",
    includeConfig: true,
    includePluginCode: false,
    exclusions: "node_modules/\n.DS_Store\nThumbs.db",
    propagateDeletes: false,
    autoSync: false,
    intervalMinutes: 10,
    syncScope: "all",
    selection: {},
    batchSize: 20
  };
}
function targetKey(settings, configDir) {
  return JSON.stringify([
    settings.owner.toLowerCase(),
    settings.repo.toLowerCase(),
    settings.branch,
    configDir,
    settings.includeConfig,
    settings.includePluginCode,
    settings.exclusions,
    settings.propagateDeletes,
    settings.syncScope,
    settings.syncScope === "selected" ? Object.entries(settings.selection).sort(([left], [right]) => left.localeCompare(right)) : []
  ]);
}
function sameRepositoryTarget(left, right) {
  try {
    const previous = JSON.parse(left);
    const next = JSON.parse(right);
    return Array.isArray(previous) && Array.isArray(next) && previous.length >= 3 && next.length >= 3 && previous[0] === next[0] && previous[1] === next[1] && previous[2] === next[2];
  } catch {
    return false;
  }
}
function migrateTarget(previous, settings, configDir) {
  if (settings.syncScope !== "all") return previous;
  try {
    const old = JSON.parse(previous);
    const current = targetKey(settings, configDir);
    if (Array.isArray(old) && old.length === 7 && JSON.stringify(old) === JSON.stringify(JSON.parse(current).slice(0, 7))) return current;
  } catch {
    return previous;
  }
  return previous;
}

// src/cancellation.ts
var SyncStoppedError = class extends Error {
  constructor() {
    super("\u540C\u6B65\u5DF2\u505C\u6B62\uFF0C\u5DF2\u786E\u8BA4\u7684\u6279\u6B21\u548C\u4E0A\u4F20\u8FDB\u5EA6\u5DF2\u4FDD\u7559\u3002\u4E0B\u6B21\u53EF\u4ECE\u65AD\u70B9\u7EE7\u7EED\u3002");
    this.name = "SyncStoppedError";
  }
};

// src/github.ts
var GitHub = class {
  constructor(settings, token, policy, transport, requests = new RequestControl(), check = () => {
  }) {
    this.settings = settings;
    this.token = token;
    this.policy = policy;
    this.transport = transport;
    this.requests = requests;
    this.check = check;
    if (!/^[A-Za-z0-9-]+$/.test(settings.owner) || !/^[A-Za-z0-9_.-]+$/.test(settings.repo)) {
      throw new Error("\u8BF7\u586B\u5199\u6709\u6548\u7684 GitHub \u7528\u6237\u540D / \u7EC4\u7EC7\u540D\u548C\u4ED3\u5E93\u540D\uFF08\u4E0D\u662F\u5B8C\u6574\u7F51\u5740\uFF09\u3002");
    }
    if (!settings.branch.trim() || /[\x00-\x20~^:?*\[\\]/.test(settings.branch) || settings.branch.includes("..") || settings.branch.includes("@{") || settings.branch.split("/").some((part) => !part || part.startsWith(".") || part.endsWith(".") || part.endsWith(".lock"))) {
      throw new Error("\u8BF7\u586B\u5199\u6709\u6548\u7684\u5206\u652F\u540D\uFF0C\u4F8B\u5982 main\u3002");
    }
    if (!token.trim()) throw new Error("\u8BF7\u5148\u5728\u8BBE\u7F6E\u4E2D\u586B\u5199 GitHub Token\u3002");
    this.root = `https://api.github.com/repos/${encodeURIComponent(settings.owner)}/${encodeURIComponent(settings.repo)}`;
  }
  settings;
  token;
  policy;
  transport;
  requests;
  check;
  root;
  async api(method, path, data) {
    this.check();
    await this.requests.before(method);
    this.check();
    let response;
    try {
      response = await this.transport(method, `${this.root}${path}`, {
        Authorization: `Bearer ${this.token}`,
        Accept: "application/vnd.github+json",
        "Content-Type": "application/json",
        "X-GitHub-Api-Version": "2026-03-10",
        "User-Agent": "GitHub-Vault-Sync/1.1.2"
      }, data === void 0 ? void 0 : JSON.stringify(data));
    } catch (error2) {
      if (error2 instanceof SyncStoppedError) throw error2;
      const message = "\u65E0\u6CD5\u8FDE\u63A5 GitHub\uFF1A\u7F51\u7EDC\u8FDE\u63A5\u4E2D\u65AD\u6216\u8BF7\u6C42\u8D85\u65F6\u3002";
      throw new GitHubApiError(
        message,
        `${message}
\u53D1\u751F\u65F6\u95F4\uFF1A${(/* @__PURE__ */ new Date()).toISOString()}
\u8BF7\u6C42\u65B9\u6CD5\uFF1A${method}
\u63A5\u53E3\uFF1A${path || "/"}
\u4E0A\u4F20\u4E0E\u63D0\u4EA4\u7ED3\u679C\u53EF\u80FD\u5C1A\u672A\u786E\u8BA4\uFF1B\u91CD\u8BD5\u524D\u4F1A\u6821\u9A8C\u65AD\u70B9\u548C\u8FDC\u7AEF\u3002`,
        0,
        0,
        true
      );
    }
    if (response.status >= 200 && response.status < 300) return response.json;
    const error = describeApiError(response, method, path, this.token);
    this.requests.hold(error);
    throw error;
  }
  refPath() {
    return this.settings.branch.split("/").map(encodeURIComponent).join("/");
  }
  async head() {
    const result = await this.api("GET", `/git/ref/heads/${this.refPath()}`);
    return result.object.sha;
  }
  async assertHead(expected) {
    if (await this.head() !== expected) throw new Error("\u8FDC\u7A0B\u5206\u652F\u5DF2\u88AB\u5176\u4ED6\u8BBE\u5907\u66F4\u65B0\uFF0C\u5DF2\u5B89\u5168\u505C\u6B62\u3002\u8BF7\u91CD\u65B0\u540C\u6B65\u3002");
  }
  async info() {
    return this.api("GET", "");
  }
  async snapshot(forSelection = false) {
    const head = await this.head();
    const commit = await this.api("GET", `/git/commits/${head}`);
    const result = await this.api("GET", `/git/trees/${commit.tree.sha}?recursive=1`);
    if (result.truncated) throw new Error("\u4ED3\u5E93\u6587\u4EF6\u6811\u88AB GitHub \u622A\u65AD\u3002\u4E3A\u907F\u514D\u6F0F\u540C\u6B65\u6216\u8BEF\u5220\uFF0C\u5DF2\u505C\u6B62\uFF1B\u8BF7\u62C6\u5206\u4ED3\u5E93\u3002");
    const files = /* @__PURE__ */ Object.create(null);
    const sizes = /* @__PURE__ */ Object.create(null);
    for (const entry of result.tree) {
      if (entry.type === "tree" || !this.policy.allows(entry.path)) continue;
      if (entry.type !== "blob" || !["100644", "100755"].includes(entry.mode)) {
        if (forSelection) continue;
        throw new Error(`\u6682\u4E0D\u652F\u6301\u7B26\u53F7\u94FE\u63A5\u6216\u5B50\u6A21\u5757\uFF1A${entry.path}`);
      }
      if (!forSelection && (typeof entry.size !== "number" || entry.size > MAX_FILE_BYTES)) throw new Error(`\u8FDC\u7A0B\u6587\u4EF6\u8D85\u8FC7 50 MiB \u6216\u7F3A\u5C11\u5927\u5C0F\u4FE1\u606F\uFF1A${entry.path}`);
      files[entry.path] = entry.sha;
      sizes[entry.path] = entry.size ?? 0;
    }
    assertCompatiblePaths(Object.keys(files));
    return { head, tree: commit.tree.sha, files, sizes };
  }
  async download(sha) {
    const result = await this.api("GET", `/git/blobs/${sha}`);
    if (result.encoding !== "base64" || result.size > MAX_FILE_BYTES) throw new Error("\u4E0D\u652F\u6301\u7684\u8FDC\u7A0B\u6587\u4EF6\u7F16\u7801\u6216\u5927\u5C0F\u3002");
    const bytes = fromBase64(result.content);
    if (bytes.length !== result.size || gitHash(bytes) !== sha) throw new Error("\u4E0B\u8F7D\u6587\u4EF6\u6821\u9A8C\u5931\u8D25\uFF0C\u5DF2\u505C\u6B62\u540C\u6B65\u3002");
    return bytes;
  }
  async upload(bytes) {
    if (bytes.length > MAX_FILE_BYTES) throw new Error("\u6587\u4EF6\u8D85\u8FC7 50 MiB\uFF0C\u65E0\u6CD5\u540C\u6B65\u3002");
    const result = await this.api("POST", "/git/blobs", { content: toBase64(bytes), encoding: "base64" });
    if (result.sha !== gitHash(bytes)) throw new Error("\u4E0A\u4F20\u6587\u4EF6\u6821\u9A8C\u5931\u8D25\uFF0C\u5DF2\u505C\u6B62\u63D0\u4EA4\u3002");
    return result.sha;
  }
  async verifyBlob(sha, size) {
    try {
      return (await this.download(sha)).length === size;
    } catch (error) {
      if (error instanceof GitHubApiError && error.status === 404) return false;
      throw error;
    }
  }
  async reconcile(state) {
    const head = await this.head();
    if (state.commitSha && head === state.commitSha) return "confirmed";
    if (head === state.baseHead && state.phase !== "confirmed") return "ready";
    if (state.commitSha && state.commitSha !== state.baseHead) {
      const comparison = await this.api("GET", `/compare/${state.commitSha}...${head}?per_page=1`);
      if (comparison.status === "ahead" || comparison.status === "identical") return "confirmed";
    }
    return "moved";
  }
  async commit(snapshot, changes, message, recovery) {
    if (!Object.keys(changes).length) {
      await this.assertHead(snapshot.head);
      return snapshot.head;
    }
    const state = recovery?.state ?? { baseHead: snapshot.head, baseTree: snapshot.tree, changes, message, phase: "prepared" };
    const save = async () => {
      await recovery?.save();
    };
    const outcome = await this.reconcile(state);
    if (outcome === "confirmed") {
      state.phase = "confirmed";
      await save();
      return state.commitSha;
    }
    if (outcome === "moved") throw new Error("\u8FDC\u7A0B\u5206\u652F\u5DF2\u66F4\u65B0\uFF1B\u4E0D\u4F1A\u91CD\u653E\u65E7\u63D0\u4EA4\u3002\u8BF7\u70B9\u51FB\u300C\u5B89\u5168\u91CD\u65B0\u89C4\u5212\u300D\u6838\u5BF9\u672A\u5B8C\u6210\u90E8\u5206\u3002");
    if (!state.treeSha) {
      const tree = await this.api("POST", "/git/trees", {
        base_tree: state.baseTree,
        tree: Object.entries(state.changes).map(([path, sha]) => ({ path, mode: "100644", type: "blob", sha }))
      });
      state.treeSha = tree.sha;
      await save();
    }
    recovery?.check();
    if (!state.commitSha) {
      const commit = await this.api("POST", "/git/commits", {
        message: state.message,
        tree: state.treeSha,
        parents: [state.baseHead]
      });
      state.commitSha = commit.sha;
      await save();
    }
    recovery?.check();
    state.phase = "updating";
    await save();
    try {
      await this.api("PATCH", `/git/refs/heads/${this.refPath()}`, { sha: state.commitSha, force: false });
    } catch (error) {
      if (error instanceof SyncStoppedError) throw error;
      let result = "unknown";
      try {
        result = await this.reconcile(state);
      } catch {
        result = "unknown";
      }
      if (result !== "confirmed") {
        const explanation = result === "ready" ? "\u5DF2\u6838\u5BF9\uFF1A\u5206\u652F\u5C1A\u672A\u66F4\u65B0\uFF0C\u4E0B\u6B21\u590D\u7528\u5DF2\u521B\u5EFA\u7684\u63D0\u4EA4\u3002" : result === "moved" ? "\u8FDC\u7A0B\u5206\u652F\u5DF2\u53D8\u5316\uFF0C\u8BF7\u5B89\u5168\u91CD\u65B0\u89C4\u5212\u3002" : "\u63D0\u4EA4\u7ED3\u679C\u5C1A\u672A\u786E\u8BA4\uFF1B\u4E0B\u6B21\u5148\u6838\u5BF9\u8FDC\u7AEF\uFF0C\u4E0D\u4F1A\u76F2\u76EE\u91CD\u590D\u63D0\u4EA4\u3002";
        const original = error instanceof GitHubApiError ? error.details : error instanceof Error ? error.message : "\u672A\u77E5\u7F51\u7EDC\u9519\u8BEF";
        throw new GitHubApiError(
          explanation,
          `${explanation}
\u5F85\u786E\u8BA4\u63D0\u4EA4\uFF1A${state.commitSha}
${original}`,
          error instanceof GitHubApiError ? error.retryAt : 0,
          error instanceof GitHubApiError ? error.status : 0,
          result !== "moved" && error instanceof GitHubApiError && error.retryable
        );
      }
    }
    state.phase = "confirmed";
    await save();
    return state.commitSha;
  }
};

// src/file-picker.ts
var import_obsidian = require("obsidian");
var FilePickerModal = class extends import_obsidian.Modal {
  constructor(app, settings, paths, loadRemote) {
    super(app);
    this.loadRemote = loadRemote;
    this.rules = Object.assign(/* @__PURE__ */ Object.create(null), settings.selection);
    this.syncScope = settings.syncScope;
    for (const path of [...paths, ...Object.keys(this.rules)]) this.addPath(path);
  }
  loadRemote;
  rules;
  syncScope;
  scopeInput;
  expanded = /* @__PURE__ */ new Set();
  filter = "";
  paths = /* @__PURE__ */ new Set();
  folders = /* @__PURE__ */ new Set();
  closed = false;
  loading = false;
  answer;
  resolve;
  rows;
  selectionSummary;
  checkboxes = /* @__PURE__ */ new Map();
  addPath(path) {
    const normalized = path.endsWith("/") ? path.slice(0, -1) : path;
    assertSafePath(normalized);
    if (path.endsWith("/")) this.folders.add(normalized);
    this.paths.add(normalized);
  }
  ask() {
    return new Promise((resolve) => {
      this.resolve = resolve;
      this.open();
    });
  }
  onOpen() {
    this.contentEl.createEl("h2", { text: "\u9009\u62E9\u540C\u6B65\u6587\u4EF6\u4E0E\u6587\u4EF6\u5939" });
    this.contentEl.createEl("p", { text: "\u52FE\u9009\u6587\u4EF6\u5939\u4F1A\u5305\u542B\u672A\u6765\u65B0\u589E\u6587\u4EF6\uFF1B\u53EF\u53D6\u6D88\u5176\u4E2D\u7684\u4E2A\u522B\u6587\u4EF6\u6216\u5B50\u76EE\u5F55\u3002\u5168\u90E8\u6A21\u5F0F\u4E0B\u53D6\u6D88\u52FE\u9009\u4F1A\u81EA\u52A8\u5207\u6362\u5230\u81EA\u9009\u6A21\u5F0F\u3002\u5B89\u5168\u6392\u9664\u89C4\u5219\u4ECD\u4F18\u5148\uFF0C\u53D6\u6D88\u52FE\u9009\u4E0D\u4F1A\u5220\u9664\u8FDC\u7A0B\u6587\u4EF6\u3002" });
    new import_obsidian.Setting(this.contentEl).setName("\u540C\u6B65\u8303\u56F4").addDropdown((input) => {
      this.scopeInput = input;
      input.addOption("all", "\u5168\u90E8\u5141\u8BB8\u7684\u6587\u4EF6\uFF08\u4FDD\u7559\u5B89\u5168\u6392\u9664\uFF09").addOption("selected", "\u4EC5\u540C\u6B65\u52FE\u9009\u5185\u5BB9").setValue(this.syncScope).onChange((value) => {
        this.syncScope = value;
        this.refreshSelection();
      });
    });
    new import_obsidian.Setting(this.contentEl).setName("\u8F7D\u5165 GitHub \u6587\u4EF6\u5217\u8868").setDesc("\u53EA\u8BFB\u53D6\u76EE\u5F55\u4FE1\u606F\uFF0C\u4E0D\u4F1A\u4E0A\u4F20\u6216\u4E0B\u8F7D\u6587\u4EF6\u5185\u5BB9\u3002").addButton((button) => button.setButtonText("\u8F7D\u5165\u8FDC\u7A0B\u5217\u8868").onClick(async () => {
      if (this.loading) return;
      this.loading = true;
      button.setDisabled(true).setButtonText("\u6B63\u5728\u8BFB\u53D6\u2026");
      try {
        const remote = await this.loadRemote();
        if (!this.closed) {
          for (const path of remote) this.addPath(path);
          this.renderTree();
          new import_obsidian.Notice(`\u5DF2\u8F7D\u5165 ${remote.length} \u4E2A\u8FDC\u7A0B\u6587\u4EF6\u8DEF\u5F84\u3002`);
        }
      } catch (error) {
        if (!this.closed) new import_obsidian.Notice(error instanceof Error ? error.message : "\u8F7D\u5165\u8FDC\u7A0B\u76EE\u5F55\u5931\u8D25", 1e4);
      } finally {
        this.loading = false;
        if (!this.closed) button.setDisabled(false).setButtonText("\u8F7D\u5165\u8FDC\u7A0B\u5217\u8868");
        else this.resolve?.(void 0);
      }
    }));
    new import_obsidian.Setting(this.contentEl).setName("\u641C\u7D22\u8DEF\u5F84").addText((input) => input.setPlaceholder("\u6587\u4EF6\u6216\u6587\u4EF6\u5939\u540D\u79F0").onChange((value) => {
      this.filter = value.toLocaleLowerCase();
      this.renderTree();
    }));
    new import_obsidian.Setting(this.contentEl).setName("\u6279\u91CF\u9009\u62E9").setDesc("\u53EA\u5F71\u54CD\u9009\u62E9\u89C4\u5219\uFF0C\u4E0D\u4FEE\u6539\u4EFB\u4F55\u6587\u4EF6\u3002").addButton((button) => button.setButtonText("\u5168\u9009\u5F53\u524D\u6839\u76EE\u5F55").onClick(() => {
      this.selectAllRoots();
      this.refreshSelection();
    })).addButton((button) => button.setButtonText("\u5168\u90E8\u53D6\u6D88").onClick(() => {
      this.syncScope = "selected";
      this.rules = /* @__PURE__ */ Object.create(null);
      this.refreshSelection();
    }));
    this.rows = this.contentEl.createDiv({ cls: "gvs-file-tree" });
    this.renderTree();
    new import_obsidian.Setting(this.contentEl).addButton((button) => button.setButtonText("\u53D6\u6D88").onClick(() => this.close())).addButton((button) => button.setButtonText("\u4FDD\u5B58\u9009\u62E9").setCta().onClick(() => {
      if (this.loading) {
        new import_obsidian.Notice("\u8BF7\u7B49\u5F85\u8FDC\u7A0B\u76EE\u5F55\u8BFB\u53D6\u5B8C\u6210\uFF0C\u6216\u53D6\u6D88\u672C\u6B21\u9009\u62E9\u3002");
        return;
      }
      this.answer = { scope: this.syncScope, rules: this.rules };
      this.close();
    }));
  }
  selectAllRoots() {
    this.syncScope = "selected";
    this.rules = /* @__PURE__ */ Object.create(null);
    for (const path of this.paths) this.rules[path.split("/")[0]] = true;
  }
  refreshSelection() {
    const treeScroll = this.rows?.scrollTop ?? 0;
    const modalScroll = this.contentEl.scrollTop;
    this.scopeInput?.setValue(this.syncScope);
    if (this.selectionSummary) {
      this.selectionSummary.textContent = this.syncScope === "all" ? "\u5F53\u524D\uFF1A\u5168\u90E8\u540C\u6B65\u3002\u53EF\u76F4\u63A5\u53D6\u6D88\u4EFB\u610F\u6761\u76EE\uFF0C\u5176\u4F59\u5DF2\u663E\u793A\u76EE\u5F55\u4FDD\u6301\u9009\u4E2D\u3002" : `\u5F53\u524D\uFF1A\u4EC5\u540C\u6B65\u52FE\u9009\u5185\u5BB9 \xB7 \u5217\u8868\u5185\u9009\u4E2D ${[...this.paths].filter((path) => isSelected(path, this.rules)).length} / ${this.paths.size} \u4E2A\u8DEF\u5F84`;
    }
    for (const [path, checkbox] of this.checkboxes) {
      const state = selectionState(path, this.rules);
      checkbox.checked = this.syncScope === "all" || state.checked;
      checkbox.indeterminate = this.syncScope === "selected" && state.mixed;
      checkbox.disabled = false;
    }
    if (this.rows) this.rows.scrollTop = treeScroll;
    this.contentEl.scrollTop = modalScroll;
  }
  renderTree() {
    if (!this.rows) return;
    const treeScroll = this.rows.scrollTop;
    const modalScroll = this.contentEl.scrollTop;
    this.rows.empty();
    this.checkboxes.clear();
    this.selectionSummary = this.rows.createEl("p");
    const root = { path: "", children: /* @__PURE__ */ new Map(), file: false };
    for (const path of this.paths) {
      assertSafePath(path);
      let node = root;
      let prefix = "";
      for (const part of path.split("/")) {
        prefix = prefix ? `${prefix}/${part}` : part;
        if (!node.children.has(part)) node.children.set(part, { path: prefix, children: /* @__PURE__ */ new Map(), file: false });
        node = node.children.get(part);
      }
      node.file = true;
    }
    const relevant = (node) => !this.filter || node.path.toLocaleLowerCase().includes(this.filter) || [...node.children.values()].some(relevant);
    const render = (parent, node) => {
      for (const [name, child] of [...node.children].sort(([left], [right]) => left.localeCompare(right))) {
        if (!relevant(child)) continue;
        const folder = child.children.size > 0 || this.folders.has(child.path);
        const wrapper = folder ? parent.createEl("details") : parent.createDiv();
        if (folder) {
          wrapper.open = !!this.filter || this.expanded.has(child.path);
          wrapper.addEventListener("toggle", () => {
            if (this.filter) return;
            if (wrapper.open) this.expanded.add(child.path);
            else this.expanded.delete(child.path);
          });
        }
        const row = folder ? wrapper.createEl("summary") : wrapper;
        const checkbox = row.createEl("input", { type: "checkbox" });
        checkbox.setAttribute("aria-label", child.path);
        this.checkboxes.set(child.path, checkbox);
        checkbox.addEventListener("click", (event) => event.stopPropagation());
        checkbox.addEventListener("change", () => {
          const selected = checkbox.checked;
          if (this.syncScope === "all") this.selectAllRoots();
          this.rules = selectPath(this.rules, child.path, selected);
          this.refreshSelection();
        });
        row.createSpan({ text: `${folder ? "\u{1F4C1} " : ""}${name}`, attr: { title: child.path } });
        if (folder) render(wrapper.createDiv({ cls: "gvs-tree-children" }), child);
      }
    };
    render(this.rows, root);
    this.refreshSelection();
    this.rows.scrollTop = treeScroll;
    this.contentEl.scrollTop = modalScroll;
  }
  onClose() {
    this.closed = true;
    if (!this.loading) this.resolve?.(this.answer);
    this.checkboxes.clear();
    this.contentEl.empty();
  }
};

// src/local.ts
var import_obsidian2 = require("obsidian");
var ObsidianStore = class {
  constructor(app, policy, check = () => {
  }) {
    this.app = app;
    this.policy = policy;
    this.check = check;
    this.adapter = app.vault.adapter;
    if (this.adapter instanceof import_obsidian2.FileSystemAdapter) {
      this.fs = require("node:fs").promises;
      this.basePath = this.adapter.getBasePath();
    }
  }
  app;
  policy;
  check;
  adapter;
  fs;
  basePath;
  async guard(path) {
    this.check();
    assertSafePath(path);
    if (!this.fs || !this.basePath) return;
    let current = this.basePath;
    for (const part of path.split("/")) {
      current += `/${part}`;
      try {
        const stat = await this.fs.lstat(current);
        if (stat.isSymbolicLink()) throw new Error(`\u4E0D\u5141\u8BB8\u540C\u6B65\u7B26\u53F7\u94FE\u63A5\uFF1A${path}\u3002\u8BF7\u79FB\u9664\u94FE\u63A5\u6216\u52A0\u5165\u6392\u9664\u5217\u8868\u3002`);
      } catch (error) {
        if (error.code === "ENOENT") return;
        throw error;
      }
    }
  }
  async listPaths(includeFolders = false) {
    const files = [];
    const folders = [];
    const visit = async (folder) => {
      this.check();
      if (folder) await this.guard(folder);
      const listed = await this.adapter.list(folder);
      for (const path of listed.files) {
        if (!this.policy.allows(path)) continue;
        await this.guard(path);
        files.push(path);
      }
      for (const path of listed.folders) {
        if (this.policy.canDescend(path)) {
          folders.push(`${path}/`);
          await visit(path);
        }
      }
    };
    await visit("");
    assertCompatiblePaths(files);
    return includeFolders ? [...folders, ...files] : files;
  }
  async scan() {
    const files = /* @__PURE__ */ Object.create(null);
    for (const path of await this.listPaths()) {
      this.check();
      const sha = await this.hash(path);
      if (!sha) throw new Error(`\u626B\u63CF\u65F6\u6587\u4EF6\u6D88\u5931\uFF1A${path}\uFF0C\u8BF7\u91CD\u8BD5\u3002`);
      files[path] = sha;
    }
    return files;
  }
  async read(path) {
    await this.guard(path);
    const stat = await this.adapter.stat(path);
    if (!stat || stat.type !== "file") throw new Error(`\u627E\u4E0D\u5230\u6587\u4EF6\uFF1A${path}`);
    if (stat.size > MAX_FILE_BYTES) throw new Error(`\u6587\u4EF6\u8D85\u8FC7 50 MiB\uFF1A${path}\u3002\u8BF7\u5C06\u5176\u79FB\u51FA\u4ED3\u5E93\u6216\u52A0\u5165\u6392\u9664\u5217\u8868\u3002`);
    const bytes = new Uint8Array(await this.adapter.readBinary(path));
    if (bytes.length > MAX_FILE_BYTES) throw new Error(`\u6587\u4EF6\u8D85\u8FC7 50 MiB\uFF1A${path}`);
    return bytes;
  }
  async hash(path) {
    await this.guard(path);
    const stat = await this.adapter.stat(path);
    if (!stat) return void 0;
    if (stat.type !== "file") throw new Error(`\u6587\u4EF6\u8DEF\u5F84\u88AB\u6587\u4EF6\u5939\u5360\u7528\uFF1A${path}`);
    return gitHash(await this.read(path));
  }
  async mkdirParents(path) {
    const parts = path.split("/");
    parts.pop();
    let folder = "";
    for (const part of parts) {
      folder = folder ? `${folder}/${part}` : part;
      await this.guard(folder);
      if (!await this.adapter.exists(folder)) {
        if (this.isInternal(folder)) await this.adapter.mkdir(folder);
        else await this.app.vault.createFolder(folder);
      } else if ((await this.adapter.stat(folder))?.type !== "folder") throw new Error(`\u76EE\u6807\u6587\u4EF6\u5939\u88AB\u6587\u4EF6\u5360\u7528\uFF1A${folder}`);
    }
  }
  buffer(bytes) {
    return Uint8Array.from(bytes).buffer;
  }
  isInternal(path) {
    return path === this.policy.configDir || path.startsWith(`${this.policy.configDir}/`) || path.split("/").some((part) => part.startsWith("."));
  }
  async write(path, bytes) {
    await this.guard(path);
    await this.mkdirParents(path);
    const file = this.app.vault.getAbstractFileByPath(path);
    if (file instanceof import_obsidian2.TFile) await this.app.vault.modifyBinary(file, this.buffer(bytes));
    else if (this.isInternal(path) || await this.adapter.exists(path)) {
      await this.adapter.writeBinary(path, this.buffer(bytes));
    } else {
      await this.app.vault.createBinary(path, this.buffer(bytes));
    }
    if (await this.hash(path) !== gitHash(bytes)) throw new Error(`\u5199\u5165\u540E\u6587\u4EF6\u6821\u9A8C\u5931\u8D25\uFF1A${path}\u3002\u65E7\u7248\u672C\u4F4D\u4E8E\u672C\u673A\u5907\u4EFD\u76EE\u5F55\u3002`);
  }
  async remove(path) {
    await this.guard(path);
    const file = this.app.vault.getAbstractFileByPath(path);
    if (file instanceof import_obsidian2.TFile) await this.app.fileManager.trashFile(file);
    else await this.adapter.remove(path);
  }
  async writePrivate(path, bytes) {
    await this.guard(path);
    await this.mkdirParents(path);
    await this.adapter.writeBinary(path, this.buffer(bytes));
    const saved = new Uint8Array(await this.adapter.readBinary(path));
    if (gitHash(saved) !== gitHash(bytes)) throw new Error("\u672C\u673A\u5907\u4EFD\u6216\u6682\u5B58\u6587\u4EF6\u6821\u9A8C\u5931\u8D25\uFF1B\u5DF2\u505C\u6B62\u3002");
  }
  async backup(path, bytes, runId) {
    await this.writePrivate(`${PRIVATE_DIR}/backups/${runId}/${path}`, bytes);
  }
  async stage(path, bytes, runId) {
    await this.writePrivate(`${PRIVATE_DIR}/staging/${runId}/${path}`, bytes);
  }
  async readStaged(path, runId) {
    return this.read(`${PRIVATE_DIR}/staging/${runId}/${path}`);
  }
  async stagedHash(path, runId) {
    return this.hash(`${PRIVATE_DIR}/staging/${runId}/${path}`);
  }
  async readBackup(path, runId) {
    return this.read(`${PRIVATE_DIR}/backups/${runId}/${path}`);
  }
  async cleanupStage(runId) {
    const path = `${PRIVATE_DIR}/staging/${runId}`;
    await this.guard(path);
    if (await this.adapter.exists(path)) await this.adapter.rmdir(path, true);
  }
};

// src/main.ts
var LABELS = { upload: "\u4E0A\u4F20", download: "\u4E0B\u8F7D", "delete-local": "\u5220\u9664\u672C\u673A", "delete-remote": "\u5220\u9664\u8FDC\u7A0B", conflict: "\u51B2\u7A81\uFF1A\u4FDD\u7559\u526F\u672C" };
var ConfirmSyncModal = class extends import_obsidian3.Modal {
  constructor(app, plan, publicRepo) {
    super(app);
    this.plan = plan;
    this.publicRepo = publicRepo;
  }
  plan;
  publicRepo;
  resolve;
  confirmed = false;
  ask() {
    return new Promise((resolve) => {
      this.resolve = resolve;
      this.open();
    });
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h2", { text: this.plan.mode === "restore" ? "\u4ECE GitHub \u6062\u590D\uFF1A\u9884\u89C8" : "GitHub \u53CC\u5411\u540C\u6B65\uFF1A\u9884\u89C8" });
    if (this.publicRepo) contentEl.createEl("p", { text: "\u8B66\u544A\uFF1A\u8FD9\u662F\u516C\u5F00\u4ED3\u5E93\u3002\u4E0A\u4F20\u5185\u5BB9\u5C06\u5BF9\u6240\u6709\u4EBA\u53EF\u89C1\uFF01\u5EFA\u8BAE\u53D6\u6D88\u5E76\u6539\u7528\u79C1\u6709\u4ED3\u5E93\u3002", cls: "gvs-warning" });
    contentEl.createEl("p", { text: "\u8BF7\u6682\u505C\u7F16\u8F91\u7B14\u8BB0\u540E\u786E\u8BA4\u3002\u53D1\u751F\u51B2\u7A81\u65F6\uFF0C\u539F\u6587\u4EF6\u4F7F\u7528\u8FDC\u7A0B\u7248\u672C\uFF0C\u672C\u673A\u7248\u672C\u53E6\u5B58\u4E3A .conflict-* \u526F\u672C\uFF1B\u5DF2\u6709\u6587\u4EF6\u88AB\u8986\u76D6\u524D\u4F1A\u5907\u4EFD\u3002" });
    const counts = /* @__PURE__ */ new Map();
    for (const action of this.plan.actions) counts.set(LABELS[action.kind], (counts.get(LABELS[action.kind]) ?? 0) + 1);
    contentEl.createEl("p", { text: [...counts].map(([label, count]) => `${label} ${count}`).join(" \xB7 ") });
    if (this.plan.actions.some((action) => action.kind.startsWith("delete"))) {
      contentEl.createEl("p", { text: "\u672C\u6B21\u5305\u542B\u5220\u9664\uFF0C\u8BF7\u4ED4\u7EC6\u68C0\u67E5\u3002\u79BB\u7EBF\u8BBE\u5907\u4E2D\u7684\u65E7\u5185\u5BB9\u53EF\u80FD\u5728\u4EE5\u540E\u91CD\u65B0\u51FA\u73B0\uFF1B\u5220\u9664\u540E\u7684\u5386\u53F2\u7248\u672C\u4ECD\u53EF\u80FD\u4FDD\u5B58\u5728 GitHub \u4E2D\u3002", cls: "gvs-warning" });
    }
    const list = contentEl.createDiv({ cls: "gvs-preview" });
    list.createEl("div", { text: this.plan.actions.map((action) => `${LABELS[action.kind]}  ${action.path}${action.copyPath ? ` \u2192 ${action.copyPath}` : ""}`).join("\n") });
    new import_obsidian3.Setting(contentEl).addButton((button) => button.setButtonText("\u53D6\u6D88").onClick(() => this.close())).addButton((button) => button.setButtonText("\u786E\u8BA4\u6267\u884C").setCta().onClick(() => {
      this.confirmed = true;
      this.close();
    }));
  }
  onClose() {
    this.resolve?.(this.confirmed);
    this.contentEl.empty();
  }
};
var GitHubVaultSync = class extends import_obsidian3.Plugin {
  data;
  busy = false;
  lastDiagnostic = "";
  requests = new RequestControl();
  status;
  timer;
  stopped = false;
  cancelRequested = false;
  activeModal;
  persistence = Promise.resolve();
  async onload() {
    const stored = await this.loadData();
    this.data = {
      settings: { ...defaults(), ...stored?.settings },
      baseline: Object.assign(/* @__PURE__ */ Object.create(null), stored?.baseline ?? {}),
      target: stored?.target ?? "",
      lastSync: stored?.lastSync ?? "",
      transfer: stored?.transfer
    };
    if (!this.data.transfer) this.data.target = migrateTarget(this.data.target, this.data.settings, this.app.vault.configDir);
    this.status = this.addStatusBarItem();
    this.setStatus(this.data.transfer?.plan ? "\u6709\u672A\u5B8C\u6210\u4EFB\u52A1\uFF0C\u8BF7\u624B\u52A8\u7EE7\u7EED" : "\u5C31\u7EEA");
    this.addRibbonIcon("cloud", "GitHub\uFF1A\u9884\u89C8\u5E76\u540C\u6B65", () => {
      void this.run("sync");
    });
    this.addRibbonIcon("square", "GitHub\uFF1A\u505C\u6B62\u5F53\u524D\u540C\u6B65", () => this.stopSync());
    this.addCommand({ id: "sync", name: "\u9884\u89C8\u5E76\u53CC\u5411\u540C\u6B65", callback: () => {
      void this.run("sync");
    } });
    this.addCommand({ id: "restore", name: "\u4ECE GitHub \u6062\u590D\uFF08\u4EC5\u4E0B\u8F7D\uFF09", callback: () => {
      void this.run("restore");
    } });
    this.addCommand({ id: "stop", name: "\u505C\u6B62\u540C\u6B65\u5E76\u4FDD\u7559\u65AD\u70B9", callback: () => this.stopSync() });
    this.addCommand({ id: "resume", name: "\u7EE7\u7EED\u4E0A\u6B21\u540C\u6B65", callback: () => {
      void this.run(this.data.transfer?.plan?.mode ?? "sync");
    } });
    this.addSettingTab(new SyncSettingsTab(this.app, this));
    await this.persist();
    this.app.workspace.onLayoutReady(() => {
      if (!this.stopped) this.configureTimer();
    });
  }
  onunload() {
    this.stopped = true;
    if (this.timer) window.clearInterval(this.timer);
    this.activeModal?.close();
  }
  persist() {
    const snapshot = JSON.parse(JSON.stringify(this.data));
    this.persistence = this.persistence.catch(() => {
    }).then(() => this.saveData(snapshot));
    return this.persistence;
  }
  setStatus(message) {
    this.status?.setText(`GitHub\uFF1A${message}`);
  }
  checkActive() {
    if (this.stopped || this.cancelRequested) throw new SyncStoppedError();
  }
  retry(error, attempt) {
    return this.requests.retry(error, attempt, () => this.checkActive(), (message) => this.setStatus(message));
  }
  stopSync() {
    if (!this.busy) {
      new import_obsidian3.Notice("\u5F53\u524D\u6CA1\u6709\u6B63\u5728\u8FD0\u884C\u7684\u540C\u6B65\u4EFB\u52A1\u3002");
      return;
    }
    this.cancelRequested = true;
    this.data.settings.autoSync = false;
    this.configureTimer();
    this.activeModal?.close();
    this.setStatus("\u6B63\u5728\u505C\u6B62\uFF0C\u7B49\u5F85\u5F53\u524D\u8BF7\u6C42\u7ED3\u675F");
    new import_obsidian3.Notice("\u505C\u6B62\u5DF2\u8BF7\u6C42\uFF1A\u5F53\u524D\u8BF7\u6C42\u8FD4\u56DE\u540E\u4F1A\u4FDD\u7559\u65AD\u70B9\u5E76\u505C\u6B62\uFF1B\u5DF2\u5173\u95ED\u5B9A\u65F6\u540C\u6B65\u3002", 8e3);
    void this.persist().catch((error) => this.report(error));
  }
  client(settings = this.data.settings) {
    const token = this.app.secretStorage.getSecret(settings.secretId) ?? "";
    return new GitHub(settings, token, new PathPolicy(settings, this.app.vault.configDir), async (method, url, headers, body) => {
      this.checkActive();
      const response = await (0, import_obsidian3.requestUrl)({ url, method, headers, body, throw: false });
      let json = {};
      try {
        json = response.json;
      } catch {
        json = {};
      }
      return { status: response.status, json, headers: response.headers, text: response.status >= 400 ? response.text : void 0 };
    }, this.requests, () => this.checkActive());
  }
  configureTimer() {
    if (this.timer) window.clearInterval(this.timer);
    if (!this.data.settings.autoSync || this.stopped) return;
    const minutes = Math.max(5, this.data.settings.intervalMinutes || 10);
    this.timer = window.setInterval(() => {
      void this.run("sync", true);
    }, minutes * 6e4);
    this.registerInterval(this.timer);
  }
  async testConnection() {
    if (this.busy) return;
    this.busy = true;
    this.cancelRequested = false;
    try {
      const client = this.client();
      const info = await client.info();
      const snapshot = await client.snapshot();
      new import_obsidian3.Notice(`\u8FDE\u63A5\u6210\u529F\uFF1A${info.full_name} / ${this.data.settings.branch}
${info.private ? "\u79C1\u6709\u4ED3\u5E93" : "\u8B66\u544A\uFF1A\u516C\u5F00\u4ED3\u5E93"} \xB7 ${Object.keys(snapshot.files).length} \u4E2A\u53EF\u540C\u6B65\u6587\u4EF6`, 8e3);
    } catch (error) {
      this.report(error);
    } finally {
      this.busy = false;
    }
  }
  report(error) {
    if (error instanceof SyncStoppedError || this.cancelRequested) {
      if (error instanceof GitHubApiError) this.lastDiagnostic = error.details;
      this.setStatus(this.data.transfer?.batch?.transaction.phase === "updating" ? "\u5DF2\u505C\u6B62\uFF0C\u4E0B\u6B21\u5148\u6838\u5BF9\u5F85\u786E\u8BA4\u63D0\u4EA4" : "\u5DF2\u505C\u6B62\uFF0C\u65AD\u70B9\u5DF2\u4FDD\u7559");
      new import_obsidian3.Notice(new SyncStoppedError().message, 7e3);
      return;
    }
    const token = this.app.secretStorage.getSecret(this.data.settings.secretId) ?? "";
    const summary = redact(error instanceof Error ? error.message : "\u672A\u77E5\u9519\u8BEF", token);
    this.lastDiagnostic = redact(error instanceof GitHubApiError ? error.details : summary, token);
    const transfer = this.data.transfer;
    if (transfer?.plan) {
      this.lastDiagnostic += `
\u4EFB\u52A1\u65AD\u70B9\uFF1A${transfer.nextIndex}/${transfer.plan.actions.length} \u9879
\u5DF2\u8BB0\u5F55\u4E0A\u4F20\u5BF9\u8C61\uFF1A${Object.keys(transfer.uploaded).length}`;
      if (transfer.batch) this.lastDiagnostic += `
\u672C\u6279\u6B21\uFF1A${transfer.batch.start + 1}\u2013${transfer.batch.start + transfer.batch.count}
\u63D0\u4EA4\u72B6\u6001\uFF1A${transfer.batch.transaction.phase}`;
    }
    this.setStatus(this.requests.coolingDown ? "\u9650\u6D41\u51B7\u5374\u4E2D\uFF0C\u8BF7\u67E5\u770B\u8BCA\u65AD" : "\u672A\u5B8C\u6210\uFF0C\u8BF7\u67E5\u770B\u8BCA\u65AD");
    new import_obsidian3.Notice(`GitHub \u540C\u6B65\u672A\u5B8C\u6210\uFF1A${summary}
\u63D2\u4EF6\u8BBE\u7F6E\u4E2D\u53EF\u67E5\u770B\u300C\u6700\u8FD1\u4E00\u6B21\u8BCA\u65AD\u300D\u3002`, 15e3);
  }
  async run(mode, automatic = false) {
    if (this.busy || this.stopped) {
      if (!automatic) new import_obsidian3.Notice("\u5DF2\u6709\u540C\u6B65\u4EFB\u52A1\u6B63\u5728\u8FDB\u884C\u3002");
      return;
    }
    if (automatic && this.requests.coolingDown) return;
    if (automatic && this.data.transfer?.plan) {
      this.setStatus("\u6709\u672A\u5B8C\u6210\u4EFB\u52A1\uFF0C\u8BF7\u624B\u52A8\u7EE7\u7EED");
      return;
    }
    this.busy = true;
    this.cancelRequested = false;
    try {
      const settings = { ...this.data.settings, selection: { ...this.data.settings.selection } };
      const target = targetKey(settings, this.app.vault.configDir);
      if (this.data.transfer?.plan && this.data.transfer.target !== target) throw new Error("\u540C\u6B65\u8303\u56F4\u5DF2\u6539\u53D8\uFF0C\u8BF7\u8FD8\u539F\u539F\u8BBE\u7F6E\u5E76\u5B89\u5168\u91CD\u65B0\u89C4\u5212\uFF0C\u4E0D\u80FD\u628A\u65E7\u65AD\u70B9\u5E94\u7528\u5230\u65B0\u76EE\u6807\u3002");
      if (automatic && (!this.data.lastSync || this.data.target !== target)) {
        this.setStatus("\u8BF7\u5148\u624B\u52A8\u540C\u6B65\u65B0\u76EE\u6807\u6216\u8303\u56F4");
        return;
      }
      const baseline = this.data.target === target ? this.data.baseline : /* @__PURE__ */ Object.create(null);
      const client = this.client(settings);
      const info = await withRetry(() => client.info(), (error, attempt) => this.retry(error, attempt), () => this.checkActive());
      if (automatic && !info.private) {
        this.setStatus("\u516C\u5F00\u4ED3\u5E93\u9700\u624B\u52A8\u786E\u8BA4");
        return;
      }
      const policy = new PathPolicy(settings, this.app.vault.configDir);
      const store = new ObsidianStore(this.app, policy, () => this.checkActive());
      const previous = this.data.transfer;
      const reusable = previous?.target === target ? previous : previous && !previous.plan && sameRepositoryTarget(previous.target, target) ? { target, uploaded: previous.uploaded, nextIndex: 0 } : void 0;
      const engine = new SyncEngine(store, client, (message) => this.setStatus(message), {
        target,
        state: reusable,
        batchSize: settings.batchSize,
        check: () => this.checkActive(),
        retry: (error, attempt) => this.retry(error, attempt),
        checkpoint: async (state, currentBaseline) => {
          this.data.transfer = state;
          this.data.baseline = currentBaseline;
          this.data.target = target;
          await this.persist();
        }
      });
      const plan = await engine.prepare(baseline, mode, settings.propagateDeletes);
      this.checkActive();
      for (const action of plan.actions) {
        if (action.copyPath && !policy.allows(action.copyPath)) {
          throw new Error(`\u51B2\u7A81\u526F\u672C\u88AB\u6392\u9664\u89C4\u5219\u963B\u6B62\uFF1A${action.copyPath}\u3002\u8BF7\u8C03\u6574\u89C4\u5219\u6216\u5148\u624B\u52A8\u89E3\u51B3\u8BE5\u51B2\u7A81\u3002`);
        }
      }
      if (automatic && plan.actions.some((action) => action.kind.startsWith("delete") || action.kind === "conflict")) {
        this.setStatus("\u6709\u51B2\u7A81\u6216\u5220\u9664\uFF0C\u8BF7\u624B\u52A8\u9884\u89C8");
        return;
      }
      if (!automatic && plan.actions.length) {
        const preview = { ...plan, actions: plan.actions.slice(this.data.transfer?.nextIndex ?? 0) };
        const modal = new ConfirmSyncModal(this.app, preview, !info.private);
        this.activeModal = modal;
        const confirmed = await modal.ask();
        this.activeModal = void 0;
        if (!confirmed) {
          this.setStatus("\u5DF2\u53D6\u6D88");
          return;
        }
      }
      this.checkActive();
      const nextBaseline = await engine.execute(plan, baseline, settings.deviceName);
      this.data.baseline = nextBaseline;
      this.data.target = target;
      this.data.lastSync = (/* @__PURE__ */ new Date()).toISOString();
      await this.persist();
      this.setStatus(`\u5DF2\u540C\u6B65 ${(/* @__PURE__ */ new Date()).toLocaleTimeString()}`);
      if (!automatic) new import_obsidian3.Notice(plan.actions.length ? `\u540C\u6B65\u5B8C\u6210\uFF1A\u5904\u7406 ${plan.actions.length} \u9879\u3002\u82E5\u6062\u590D\u4E86\u8BBE\u7F6E\u6216\u5176\u4ED6\u63D2\u4EF6\uFF0C\u8BF7\u91CD\u542F Obsidian\u3002` : "\u672C\u673A\u4E0E GitHub \u5DF2\u4E00\u81F4\uFF0C\u65E0\u9700\u4FEE\u6539\u3002", 7e3);
    } catch (error) {
      if (!this.stopped) this.report(error);
    } finally {
      this.busy = false;
    }
  }
  async chooseFiles() {
    if (this.busy || this.data.transfer?.plan) {
      new import_obsidian3.Notice("\u8BF7\u5148\u505C\u6B62\u4EFB\u52A1\u5E76\u5B89\u5168\u91CD\u65B0\u89C4\u5212\uFF0C\u518D\u4FEE\u6539\u540C\u6B65\u8303\u56F4\u3002");
      return;
    }
    this.busy = true;
    this.cancelRequested = false;
    try {
      const settings = { ...this.data.settings, syncScope: "all" };
      const store = new ObsidianStore(this.app, new PathPolicy(settings, this.app.vault.configDir), () => this.checkActive());
      const paths = await store.listPaths(true);
      this.checkActive();
      const modal = new FilePickerModal(this.app, this.data.settings, paths, async () => {
        try {
          return Object.keys((await this.client(settings).snapshot(true)).files);
        } catch (error) {
          this.report(error);
          throw error;
        }
      });
      this.activeModal = modal;
      const selection = await modal.ask();
      this.activeModal = void 0;
      if (selection) {
        this.checkActive();
        this.data.settings.syncScope = selection.scope;
        this.data.settings.selection = selection.rules;
        await this.persist();
        new import_obsidian3.Notice("\u9009\u62E9\u5DF2\u4FDD\u5B58\uFF1B\u4E0B\u4E00\u6B21\u8BF7\u624B\u52A8\u9884\u89C8\u540C\u6B65\u3002\u53D6\u6D88\u52FE\u9009\u4E0D\u4F1A\u5220\u9664\u6587\u4EF6\u3002");
      }
    } catch (error) {
      if (!this.stopped) this.report(error);
    } finally {
      this.busy = false;
    }
  }
  async replan() {
    if (this.busy) {
      new import_obsidian3.Notice("\u8BF7\u5148\u505C\u6B62\u5E76\u7B49\u5F85\u5F53\u524D\u4EFB\u52A1\u7ED3\u675F\u3002");
      return;
    }
    if (!this.data.transfer) {
      new import_obsidian3.Notice("\u5F53\u524D\u6CA1\u6709\u672A\u5B8C\u6210\u4EFB\u52A1\u3002");
      return;
    }
    this.busy = true;
    this.cancelRequested = false;
    try {
      const settings = this.data.settings;
      if (this.data.transfer.target !== targetKey(settings, this.app.vault.configDir)) throw new Error("\u8BF7\u5148\u8FD8\u539F\u539F\u4EFB\u52A1\u7684\u4ED3\u5E93\u548C\u9009\u62E9\u8303\u56F4\uFF0C\u518D\u6838\u5BF9\u672A\u786E\u8BA4\u63D0\u4EA4\u3002");
      const engine = new SyncEngine(
        new ObsidianStore(this.app, new PathPolicy(settings, this.app.vault.configDir)),
        this.client(),
        (message) => this.setStatus(message),
        {
          state: this.data.transfer,
          check: () => this.checkActive(),
          checkpoint: async (state, baseline) => {
            this.data.transfer = state;
            this.data.baseline = baseline;
            await this.persist();
          }
        }
      );
      await engine.replan(this.data.baseline);
      new import_obsidian3.Notice("\u5DF2\u6838\u5BF9\u65E7\u6279\u6B21\u3002\u73B0\u5728\u53EF\u4FEE\u6539\u52FE\u9009\u8303\u56F4\uFF0C\u518D\u91CD\u65B0\u9884\u89C8\uFF1B\u5DF2\u4E0A\u4F20\u5BF9\u8C61\u7684\u6821\u9A8C\u7F13\u5B58\u4ECD\u4FDD\u7559\u3002", 9e3);
      this.setStatus("\u53EF\u91CD\u65B0\u9884\u89C8\u672A\u5B8C\u6210\u90E8\u5206");
    } catch (error) {
      this.report(error);
    } finally {
      this.busy = false;
    }
  }
};
var SyncSettingsTab = class extends import_obsidian3.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  plugin;
  display() {
    const { containerEl } = this;
    const settings = this.plugin.data.settings;
    containerEl.empty();
    containerEl.createEl("h2", { text: "GitHub Vault Sync" });
    const transfer = this.plugin.data.transfer;
    const locked = this.plugin.busy || !!transfer?.plan;
    new import_obsidian3.Setting(containerEl).setName("\u4EFB\u52A1\u63A7\u5236").setDesc(transfer?.plan ? `\u5DF2\u4FDD\u5B58 ${transfer.nextIndex}/${transfer.plan.actions.length} \u9879\uFF1B\u4E0A\u4F20\u5BF9\u8C61\u8BB0\u5F55 ${Object.keys(transfer.uploaded).length} \u4E2A\u3002` : "\u53EF\u505C\u6B62\u5F53\u524D\u4EFB\u52A1\uFF1B\u672A\u5B8C\u6210\u7684\u6279\u6B21\u4F1A\u4FDD\u7559\u65AD\u70B9\u3002").addButton((button) => button.setButtonText("\u505C\u6B62\u5F53\u524D\u540C\u6B65").onClick(() => this.plugin.stopSync())).addButton((button) => button.setButtonText("\u7EE7\u7EED\u4E0A\u6B21\u4EFB\u52A1").onClick(() => this.plugin.run(this.plugin.data.transfer?.plan?.mode ?? "sync"))).addButton((button) => button.setButtonText("\u5B89\u5168\u91CD\u65B0\u89C4\u5212").onClick(async () => {
      await this.plugin.replan();
      this.display();
    }));
    new import_obsidian3.Setting(containerEl).setName("\u6587\u4EF6\u4E0E\u6587\u4EF6\u5939\u9009\u62E9").setDesc(settings.syncScope === "all" ? "\u5F53\u524D\u540C\u6B65\u5168\u90E8\u5141\u8BB8\u7684\u6587\u4EF6\u3002\u53EF\u6539\u4E3A\u4EC5\u540C\u6B65\u52FE\u9009\u5185\u5BB9\u3002" : "\u5F53\u524D\u53EA\u540C\u6B65\u52FE\u9009\u5185\u5BB9\u3002\u5B89\u5168\u6392\u9664\u89C4\u5219\u4ECD\u4F18\u5148\u3002").addButton((button) => button.setButtonText("\u9009\u62E9\u6587\u4EF6 / \u6587\u4EF6\u5939").setDisabled(locked).onClick(async () => {
      await this.plugin.chooseFiles();
      this.display();
    }));
    new import_obsidian3.Setting(containerEl).setName("\u6700\u8FD1\u4E00\u6B21\u8BCA\u65AD").setDesc("\u4EC5\u4FDD\u7559\u5728\u672C\u6B21\u5E94\u7528\u4F1A\u8BDD\u4E2D\uFF0C\u4E0D\u5199\u5165\u540C\u6B65\u6587\u4EF6\u3002\u70B9\u51FB\u67E5\u770B\u540E\u53EF\u9009\u4E2D\u590D\u5236\uFF1B\u53D1\u9001\u524D\u8BF7\u68C0\u67E5\uFF0C\u4E0D\u8981\u53D1\u9001 Token\u3002").addButton((button) => button.setButtonText("\u67E5\u770B / \u5237\u65B0\u8BCA\u65AD").onClick(() => this.display()));
    if (this.plugin.lastDiagnostic) {
      const diagnostic = containerEl.createEl("textarea", { cls: "gvs-diagnostic" });
      diagnostic.readOnly = true;
      diagnostic.rows = 10;
      diagnostic.value = this.plugin.lastDiagnostic;
    }
    containerEl.createEl("p", { text: "\u5148\u5728 GitHub \u65B0\u5EFA\u4E13\u7528\u79C1\u6709\u4ED3\u5E93\uFF0C\u52FE\u9009 Add a README\u3002\u521B\u5EFA\u4EC5\u6388\u6743\u6B64\u4ED3\u5E93\u3001Contents: Read and write \u7684 fine-grained Token\u3002\u6BCF\u53F0\u8BBE\u5907\u5355\u72EC\u914D\u7F6E Token\u3002" });
    containerEl.createEl("p", { text: "\u540C\u6B65\u7B14\u8BB0\u3001\u9644\u4EF6\u548C\u5E38\u7528 Obsidian \u8BBE\u7F6E\uFF1B\u4E0D\u4F1A\u4E0A\u4F20\u672C\u63D2\u4EF6\u3001Token\u3001\u63D2\u4EF6 data.json\u3001\u5DE5\u4F5C\u533A\u5E03\u5C40\u3001\u56DE\u6536\u7AD9\u548C\u672C\u673A\u5907\u4EFD\u3002GitHub \u79C1\u6709\u4ED3\u5E93\u4E0D\u7B49\u540C\u4E8E\u7AEF\u5230\u7AEF\u52A0\u5BC6\uFF0C\u8BF7\u52FF\u5B58\u653E\u673A\u5BC6\u51ED\u636E\u3002" });
    const save = async () => {
      await this.plugin.persist();
      this.plugin.configureTimer();
    };
    const text = (name, description, key, placeholder) => {
      new import_obsidian3.Setting(containerEl).setName(name).setDesc(description).addText((input) => input.setPlaceholder(placeholder).setValue(settings[key]).setDisabled(locked).onChange(async (value) => {
        if (this.plugin.busy || this.plugin.data.transfer?.plan) return;
        settings[key] = value.trim();
        await save();
      }));
    };
    text("GitHub \u7528\u6237\u540D / \u7EC4\u7EC7\u540D", "\u4ED3\u5E93\u5730\u5740\u4E2D github.com \u540E\u7684\u7B2C\u4E00\u6BB5\u3002", "owner", "your-name");
    text("\u4ED3\u5E93\u540D", "\u53EA\u586B\u540D\u79F0\uFF0C\u4E0D\u8981\u586B\u5199\u7F51\u5740\u6216 .git \u540E\u7F00\u3002\u8BF7\u4F7F\u7528\u4E13\u7528\u4ED3\u5E93\u3002", "repo", "obsidian-vault");
    text("\u5206\u652F", "\u5FC5\u987B\u662F\u5DF2\u5B58\u5728\u7684\u5206\u652F\uFF1B\u65B0\u4ED3\u5E93\u901A\u5E38\u4E3A main\u3002", "branch", "main");
    text("\u8BBE\u5907\u540D\u79F0", "\u5199\u5165 GitHub \u63D0\u4EA4\u8BF4\u660E\uFF0C\u65B9\u4FBF\u533A\u5206\u8BBE\u5907\u3002", "deviceName", "\u6211\u7684 MacBook");
    new import_obsidian3.Setting(containerEl).setName("GitHub Token").setDesc("\u5199\u5165 Obsidian SecretStorage\uFF0C\u4E0D\u5199\u5165\u63D2\u4EF6 data.json\uFF0C\u4E0D\u663E\u793A\u5DF2\u4FDD\u5B58\u7684 Token\u3002\u6E05\u7A7A\u8F93\u5165\u4E0D\u4F1A\u5220\u9664\u5DF2\u6709 Token\u3002").addText((input) => {
      input.inputEl.type = "password";
      input.inputEl.autocomplete = "off";
      input.setPlaceholder(this.app.secretStorage.getSecret(settings.secretId) ? "\u5DF2\u4FDD\u5B58\uFF08\u8F93\u5165\u65B0\u503C\u53EF\u66FF\u6362\uFF09" : "github_pat_...").setDisabled(this.plugin.busy);
      input.inputEl.addEventListener("change", () => {
        const token = input.getValue().trim();
        if (token) {
          this.app.secretStorage.setSecret(settings.secretId, token);
          input.setValue("").setPlaceholder("\u5DF2\u4FDD\u5B58");
          new import_obsidian3.Notice("Token \u5DF2\u4FDD\u5B58\u5728\u672C\u673A SecretStorage\u3002");
        }
      });
    }).addButton((button) => button.setButtonText("\u6E05\u9664 Token").setDisabled(this.plugin.busy).onClick(() => {
      this.app.secretStorage.setSecret(settings.secretId, "");
      this.display();
    }));
    new import_obsidian3.Setting(containerEl).setName("\u6D4B\u8BD5\u8FDE\u63A5").setDesc("\u9A8C\u8BC1 Token\u3001\u4ED3\u5E93\u548C\u5206\u652F\u80FD\u5426\u8BFB\u53D6\uFF1B\u5B9E\u9645\u5199\u5165\u6743\u9650\u5728\u63D0\u4EA4\u65F6\u9A8C\u8BC1\u3002").addButton((button) => button.setButtonText("\u6D4B\u8BD5\u8FDE\u63A5").setDisabled(this.plugin.busy).onClick(() => this.plugin.testConnection()));
    const toggle = (name, description, key) => {
      new import_obsidian3.Setting(containerEl).setName(name).setDesc(description).addToggle((input) => input.setValue(settings[key]).setDisabled(key === "autoSync" ? this.plugin.busy : locked).onChange(async (value) => {
        if (this.plugin.busy || key !== "autoSync" && this.plugin.data.transfer?.plan) return;
        settings[key] = value;
        await save();
      }));
    };
    toggle("\u540C\u6B65\u5E38\u7528 Obsidian \u8BBE\u7F6E", "\u5305\u62EC\u5916\u89C2\u3001\u5FEB\u6377\u952E\u3001\u4E66\u7B7E\u3001\u65E5\u8BB0\u3001\u6A21\u677F\u3001\u56FE\u8C31\u3001\u4E3B\u9898\u548C CSS \u7247\u6BB5\uFF1B\u5176\u4ED6\u914D\u7F6E\u4E0D\u4E0A\u4F20\u3002", "includeConfig");
    toggle("\u540C\u6B65\u5176\u4ED6\u63D2\u4EF6\u4EE3\u7801\uFF08\u8C28\u614E\u5F00\u542F\uFF09", "\u5305\u542B\u5176\u4ED6\u63D2\u4EF6 main.js / manifest.json / styles.css \u548C\u542F\u7528\u5217\u8868\uFF0C\u4F46\u4E0D\u5305\u542B\u5176 data.json\u3002\u8FDC\u7A0B\u4EE3\u7801\u53EF\u5728\u91CD\u542F\u540E\u6267\u884C\uFF0C\u53EA\u540C\u6B65\u4F60\u4FE1\u4EFB\u7684\u4ED3\u5E93\u3002", "includePluginCode");
    toggle("\u4F20\u64AD\u5220\u9664\uFF08\u9ED8\u8BA4\u5173\u95ED\uFF09", "\u4EC5\u5BF9\u5DF2\u6709\u540C\u6B65\u57FA\u7EBF\u7684\u6587\u4EF6\u751F\u6548\uFF1B\u81EA\u52A8\u540C\u6B65\u9047\u5230\u5220\u9664\u4F1A\u6682\u505C\u5E76\u8981\u6C42\u624B\u52A8\u786E\u8BA4\u3002\u5173\u95ED\u65F6\u4F1A\u4ECE\u4ECD\u5B58\u5728\u7684\u4E00\u7AEF\u8865\u56DE\u6587\u4EF6\u3002", "propagateDeletes");
    new import_obsidian3.Setting(containerEl).setName("\u989D\u5916\u6392\u9664\u89C4\u5219").setDesc("\u6BCF\u884C\u4E00\u6761\uFF0C\u76F8\u5BF9\u4ED3\u5E93\u6839\u76EE\u5F55\u3002\u76EE\u5F55\u7528 folder/\uFF1B* \u5339\u914D\u4EFB\u610F\u5B57\u7B26\u3002\u4E0D\u652F\u6301 .gitignore \u7684 !\u3001? \u6216\u590D\u6742\u8BED\u6CD5\u3002\u5404\u8BBE\u5907\u5EFA\u8BAE\u4FDD\u6301\u4E00\u81F4\u3002").addTextArea((input) => input.setValue(settings.exclusions).setPlaceholder("private/\n*.tmp").setDisabled(locked).onChange(async (value) => {
      if (this.plugin.busy || this.plugin.data.transfer?.plan) return;
      settings.exclusions = value;
      await save();
    }));
    new import_obsidian3.Setting(containerEl).setName("\u6BCF\u6279\u6587\u4EF6\u6570").setDesc("\u9ED8\u8BA4 20\uFF0C\u8303\u56F4 1\u2013100\u3002\u8FD9\u662F\u4FDD\u5B58\u8FDB\u5EA6\u7684\u95F4\u9694\uFF0C\u4E0D\u662F\u4F20\u8F93\u4E0A\u9650\uFF1B\u4E00\u6279\u5B8C\u6210\u540E\u81EA\u52A8\u7EE7\u7EED\uFF0C\u76F4\u5230\u5168\u90E8\u5B8C\u6210\u3002\u4E34\u65F6\u6545\u969C\u6700\u591A\u81EA\u52A8\u91CD\u8BD5 3 \u6B21\uFF0C\u7B49\u5F85\u65F6\u53EF\u505C\u6B62\u3002").addText((input) => input.setValue(String(settings.batchSize)).setDisabled(locked).onChange(async (value) => {
      if (this.plugin.busy || this.plugin.data.transfer?.plan) return;
      const count = Number(value);
      if (Number.isInteger(count) && count >= 1 && count <= 100) {
        settings.batchSize = count;
        await save();
      }
    }));
    toggle("\u5B9A\u65F6\u81EA\u52A8\u540C\u6B65", "\u9ED8\u8BA4\u5173\u95ED\uFF0C\u5FC5\u987B\u5148\u624B\u52A8\u540C\u6B65\u4E00\u6B21\u3002\u4EC5\u5728 Obsidian \u6253\u5F00\u65F6\u8FD0\u884C\uFF1B\u516C\u5F00\u4ED3\u5E93\u3001\u51B2\u7A81\u548C\u5220\u9664\u9700\u8981\u624B\u52A8\u786E\u8BA4\u3002", "autoSync");
    new import_obsidian3.Setting(containerEl).setName("\u540C\u6B65\u95F4\u9694\uFF08\u5206\u949F\uFF09").setDesc("\u6700\u5C11 5 \u5206\u949F\u3002\u5927\u91CF\u9644\u4EF6\u4F1A\u589E\u52A0 API \u8BF7\u6C42\u6570\u548C\u672C\u673A\u626B\u63CF\u5F00\u9500\u3002").addText((input) => input.setValue(String(settings.intervalMinutes)).setDisabled(this.plugin.busy).onChange(async (value) => {
      const minutes = Number(value);
      if (Number.isFinite(minutes) && minutes >= 5 && minutes <= 1440) {
        settings.intervalMinutes = minutes;
        await save();
      }
    }));
    new import_obsidian3.Setting(containerEl).setName("\u540C\u6B65\u4E0E\u6062\u590D").setDesc("\u65B0\u8BBE\u5907\u5EFA\u8BAE\u521B\u5EFA\u7A7A Vault\uFF0C\u7136\u540E\u5148\u70B9\u300C\u4EC5\u4E0B\u8F7D\u6062\u590D\u300D\u3002\u6062\u590D\u4E0D\u4F1A\u63D0\u4EA4\u4EFB\u4F55\u5185\u5BB9\u5230 GitHub\u3002").addButton((button) => button.setButtonText("\u9884\u89C8\u5E76\u53CC\u5411\u540C\u6B65").setCta().setDisabled(this.plugin.busy).onClick(() => this.plugin.run("sync"))).addButton((button) => button.setButtonText("\u4EC5\u4E0B\u8F7D\u6062\u590D").setDisabled(this.plugin.busy).onClick(() => this.plugin.run("restore")));
    containerEl.createEl("p", { text: `\u4E0A\u6B21\u6210\u529F\uFF1A${this.plugin.data.lastSync ? new Date(this.plugin.data.lastSync).toLocaleString() : "\u5C1A\u672A\u540C\u6B65"}` });
  }
};
/*! Bundled license information:

@noble/hashes/esm/utils.js:
  (*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) *)
*/
